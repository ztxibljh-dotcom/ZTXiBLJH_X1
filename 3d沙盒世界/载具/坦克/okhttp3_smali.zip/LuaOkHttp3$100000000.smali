.class LLuaOkHttp3$100000000;
.super Ljava/lang/Object;
.source "LuaOkHttp3.java"

# interfaces
.implements Lokhttp3/Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LLuaOkHttp3;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000000"
.end annotation


# instance fields
.field private final synthetic val$callback:Lokhttp3/Callback;

.field private final synthetic val$outputFile:Ljava/io/File;


# direct methods
.method constructor <init>(Lokhttp3/Callback;Ljava/io/File;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LLuaOkHttp3$100000000;->val$callback:Lokhttp3/Callback;

    iput-object p2, p0, LLuaOkHttp3$100000000;->val$outputFile:Ljava/io/File;

    return-void
.end method


# virtual methods
.method public onFailure(Lokhttp3/Call;Ljava/io/IOException;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lokhttp3/Call;",
            "Ljava/io/IOException;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 79
    iget-object v0, p0, LLuaOkHttp3$100000000;->val$callback:Lokhttp3/Callback;

    invoke-interface {v0, p1, p2}, Lokhttp3/Callback;->onFailure(Lokhttp3/Call;Ljava/io/IOException;)V

    return-void
.end method

.method public onResponse(Lokhttp3/Call;Lokhttp3/Response;)V
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lokhttp3/Call;",
            "Lokhttp3/Response;",
            ")V^",
            "Ljava/io/IOException;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 84
    invoke-virtual {p2}, Lokhttp3/Response;->isSuccessful()Z

    move-result v0

    if-nez v0, :cond_24

    .line 85
    iget-object v0, p0, LLuaOkHttp3$100000000;->val$callback:Lokhttp3/Callback;

    new-instance v1, Ljava/io/IOException;

    new-instance v2, Ljava/lang/StringBuffer;

    invoke-direct {v2}, Ljava/lang/StringBuffer;-><init>()V

    const-string v3, "Unexpected code "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v2

    invoke-virtual {v2, p2}, Ljava/lang/StringBuffer;->append(Ljava/lang/Object;)Ljava/lang/StringBuffer;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {v1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    invoke-interface {v0, p1, v1}, Lokhttp3/Callback;->onFailure(Lokhttp3/Call;Ljava/io/IOException;)V

    .line 86
    return-void

    .line 88
    :cond_24
    const/4 v0, 0x0

    move-object v1, v0

    check-cast v1, Ljava/io/InputStream;

    .line 89
    move-object v1, v0

    check-cast v1, Ljava/io/FileOutputStream;

    .line 91
    :try_start_2b
    invoke-virtual {p2}, Lokhttp3/Response;->body()Lokhttp3/ResponseBody;

    move-result-object v1

    invoke-virtual {v1}, Lokhttp3/ResponseBody;->byteStream()Ljava/io/InputStream;

    move-result-object v1
    :try_end_33
    .catch Ljava/io/IOException; {:try_start_2b .. :try_end_33} :catch_63
    .catchall {:try_start_2b .. :try_end_33} :catchall_60

    .line 92
    :try_start_33
    new-instance v2, Ljava/io/FileOutputStream;

    iget-object v3, p0, LLuaOkHttp3$100000000;->val$outputFile:Ljava/io/File;

    invoke-direct {v2, v3}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    :try_end_3a
    .catch Ljava/io/IOException; {:try_start_33 .. :try_end_3a} :catch_5c
    .catchall {:try_start_33 .. :try_end_3a} :catchall_58

    .line 93
    const/16 v0, 0x1000

    :try_start_3c
    new-array v0, v0, [B

    .line 94
    nop

    .line 95
    :goto_3f
    invoke-virtual {v1, v0}, Ljava/io/InputStream;->read([B)I

    move-result v3

    const/4 v4, -0x1

    if-ne v3, v4, :cond_4f

    .line 98
    invoke-virtual {v2}, Ljava/io/FileOutputStream;->flush()V

    .line 99
    iget-object v0, p0, LLuaOkHttp3$100000000;->val$callback:Lokhttp3/Callback;

    invoke-interface {v0, p1, p2}, Lokhttp3/Callback;->onResponse(Lokhttp3/Call;Lokhttp3/Response;)V

    goto :goto_6b

    .line 96
    :cond_4f
    const/4 v4, 0x0

    invoke-virtual {v2, v0, v4, v3}, Ljava/io/FileOutputStream;->write([BII)V
    :try_end_53
    .catch Ljava/io/IOException; {:try_start_3c .. :try_end_53} :catch_56
    .catchall {:try_start_3c .. :try_end_53} :catchall_54

    goto :goto_3f

    .line 101
    :catchall_54
    move-exception p1

    goto :goto_5a

    .line 99
    :catch_56
    move-exception p2

    goto :goto_5e

    .line 101
    :catchall_58
    move-exception p1

    move-object v2, v0

    :goto_5a
    move-object v0, v1

    goto :goto_77

    .line 99
    :catch_5c
    move-exception p2

    move-object v2, v0

    :goto_5e
    move-object v0, v1

    goto :goto_65

    .line 101
    :catchall_60
    move-exception p1

    move-object v2, v0

    goto :goto_77

    .line 99
    :catch_63
    move-exception p2

    move-object v2, v0

    .line 101
    :goto_65
    :try_start_65
    iget-object v1, p0, LLuaOkHttp3$100000000;->val$callback:Lokhttp3/Callback;

    invoke-interface {v1, p1, p2}, Lokhttp3/Callback;->onFailure(Lokhttp3/Call;Ljava/io/IOException;)V
    :try_end_6a
    .catchall {:try_start_65 .. :try_end_6a} :catchall_76

    move-object v1, v0

    .line 103
    :goto_6b
    if-eqz v1, :cond_70

    invoke-virtual {v1}, Ljava/io/InputStream;->close()V

    .line 104
    :cond_70
    if-eqz v2, :cond_75

    invoke-virtual {v2}, Ljava/io/FileOutputStream;->close()V

    :cond_75
    return-void

    .line 101
    :catchall_76
    move-exception p1

    .line 103
    :goto_77
    if-eqz v0, :cond_7c

    invoke-virtual {v0}, Ljava/io/InputStream;->close()V

    .line 104
    :cond_7c
    if-eqz v2, :cond_81

    invoke-virtual {v2}, Ljava/io/FileOutputStream;->close()V

    :cond_81
    throw p1
.end method
