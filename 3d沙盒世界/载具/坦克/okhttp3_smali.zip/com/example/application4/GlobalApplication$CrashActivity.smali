.class public final Lcom/example/application4/GlobalApplication$CrashActivity;
.super Landroid/app/Activity;
.source "GlobalApplication.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/example/application4/GlobalApplication;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x39
    name = "CrashActivity"
.end annotation


# instance fields
.field private mLog:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 332
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method

.method private static dp2px(F)I
    .registers 2

    .line 307
    invoke-static {}, Landroid/content/res/Resources;->getSystem()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    .line 308
    mul-float p0, p0, v0

    const/high16 v0, 0x3f000000  # 0.5f

    add-float/2addr p0, v0

    float-to-int p0, p0

    return p0
.end method

.method private restart()V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 296
    invoke-virtual {p0}, Lcom/example/application4/GlobalApplication$CrashActivity;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    invoke-virtual {p0}, Lcom/example/application4/GlobalApplication$CrashActivity;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    .line 297
    if-eqz v0, :cond_16

    .line 298
    const/high16 v1, 0x10000000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 299
    invoke-virtual {p0, v0}, Lcom/example/application4/GlobalApplication$CrashActivity;->startActivity(Landroid/content/Intent;)V

    .line 301
    :cond_16
    invoke-virtual {p0}, Lcom/example/application4/GlobalApplication$CrashActivity;->finish()V

    .line 302
    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v0

    invoke-static {v0}, Landroid/os/Process;->killProcess(I)V

    .line 303
    const/4 v0, 0x0

    invoke-static {v0}, Ljava/lang/System;->exit(I)V

    return-void
.end method


# virtual methods
.method public onBackPressed()V
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 331
    invoke-direct {p0}, Lcom/example/application4/GlobalApplication$CrashActivity;->restart()V

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/os/Bundle;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 269
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 271
    const p1, 0x1030128

    invoke-virtual {p0, p1}, Lcom/example/application4/GlobalApplication$CrashActivity;->setTheme(I)V

    .line 272
    const-string p1, "App Crash"

    invoke-virtual {p0, p1}, Lcom/example/application4/GlobalApplication$CrashActivity;->setTitle(Ljava/lang/CharSequence;)V

    .line 274
    invoke-virtual {p0}, Lcom/example/application4/GlobalApplication$CrashActivity;->getIntent()Landroid/content/Intent;

    move-result-object p1

    const-string v0, "android.intent.extra.TEXT"

    invoke-virtual {p1, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/example/application4/GlobalApplication$CrashActivity;->mLog:Ljava/lang/String;

    .line 276
    new-instance p1, Landroid/widget/ScrollView;

    invoke-direct {p1, p0}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    .line 277
    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Landroid/widget/ScrollView;->setFillViewport(Z)V

    .line 279
    new-instance v1, Landroid/widget/HorizontalScrollView;

    invoke-direct {v1, p0}, Landroid/widget/HorizontalScrollView;-><init>(Landroid/content/Context;)V

    .line 281
    new-instance v2, Landroid/widget/TextView;

    invoke-direct {v2, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 282
    const/16 v3, 0x10

    int-to-float v3, v3

    invoke-static {v3}, Lcom/example/application4/GlobalApplication$CrashActivity;->dp2px(F)I

    move-result v3

    .line 283
    invoke-virtual {v2, v3, v3, v3, v3}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 284
    iget-object v3, p0, Lcom/example/application4/GlobalApplication$CrashActivity;->mLog:Ljava/lang/String;

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 285
    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setTextIsSelectable(Z)V

    .line 286
    sget-object v3, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 287
    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setLinksClickable(Z)V

    .line 289
    invoke-virtual {v1, v2}, Landroid/widget/HorizontalScrollView;->addView(Landroid/view/View;)V

    .line 290
    const/4 v0, -0x1

    invoke-virtual {p1, v1, v0, v0}, Landroid/widget/ScrollView;->addView(Landroid/view/View;II)V

    .line 292
    invoke-virtual {p0, p1}, Lcom/example/application4/GlobalApplication$CrashActivity;->setContentView(Landroid/view/View;)V

    return-void
.end method

.method public onCreateOptionsMenu(Landroid/view/Menu;)Z
    .registers 5
    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 313
    const v0, 0x1020021

    const v1, 0x1040001

    const/4 v2, 0x0

    invoke-interface {p1, v2, v0, v2, v1}, Landroid/view/Menu;->add(IIII)Landroid/view/MenuItem;

    move-result-object v0

    const/4 v1, 0x1

    invoke-interface {v0, v1}, Landroid/view/MenuItem;->setShowAsAction(I)V

    .line 315
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreateOptionsMenu(Landroid/view/Menu;)Z

    move-result p1

    return p1
.end method

.method public onOptionsItemSelected(Landroid/view/MenuItem;)Z
    .registers 4
    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 320
    invoke-interface {p1}, Landroid/view/MenuItem;->getItemId()I

    move-result v0

    packed-switch v0, :pswitch_data_24

    .line 326
    invoke-super {p0, p1}, Landroid/app/Activity;->onOptionsItemSelected(Landroid/view/MenuItem;)Z

    move-result p1

    return p1

    .line 322
    :pswitch_c  #0x1020021
    const-string p1, "clipboard"

    invoke-virtual {p0, p1}, Lcom/example/application4/GlobalApplication$CrashActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/content/ClipboardManager;

    .line 323
    invoke-virtual {p0}, Lcom/example/application4/GlobalApplication$CrashActivity;->getPackageName()Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lcom/example/application4/GlobalApplication$CrashActivity;->mLog:Ljava/lang/String;

    invoke-static {v0, v1}, Landroid/content/ClipData;->newPlainText(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Landroid/content/ClipData;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/content/ClipboardManager;->setPrimaryClip(Landroid/content/ClipData;)V

    .line 324
    const/4 p1, 0x1

    return p1

    nop

    :pswitch_data_24
    .packed-switch 0x1020021
        :pswitch_c  #01020021
    .end packed-switch
.end method
