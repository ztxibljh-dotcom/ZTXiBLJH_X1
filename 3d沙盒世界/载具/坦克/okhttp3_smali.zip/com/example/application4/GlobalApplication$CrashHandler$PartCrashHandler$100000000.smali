.class Lcom/example/application4/GlobalApplication$CrashHandler$PartCrashHandler$100000000;
.super Ljava/lang/Object;
.source "GlobalApplication.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/example/application4/GlobalApplication$CrashHandler$PartCrashHandler;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000000"
.end annotation


# instance fields
.field private final this$0:Lcom/example/application4/GlobalApplication$CrashHandler$PartCrashHandler;

.field private final synthetic val$e:Ljava/lang/Throwable;


# direct methods
.method constructor <init>(Lcom/example/application4/GlobalApplication$CrashHandler$PartCrashHandler;Ljava/lang/Throwable;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/application4/GlobalApplication$CrashHandler$PartCrashHandler$100000000;->this$0:Lcom/example/application4/GlobalApplication$CrashHandler$PartCrashHandler;

    iput-object p2, p0, Lcom/example/application4/GlobalApplication$CrashHandler$PartCrashHandler$100000000;->val$e:Ljava/lang/Throwable;

    return-void
.end method

.method static access$0(Lcom/example/application4/GlobalApplication$CrashHandler$PartCrashHandler$100000000;)Lcom/example/application4/GlobalApplication$CrashHandler$PartCrashHandler;
    .registers 1

    iget-object p0, p0, Lcom/example/application4/GlobalApplication$CrashHandler$PartCrashHandler$100000000;->this$0:Lcom/example/application4/GlobalApplication$CrashHandler$PartCrashHandler;

    return-object p0
.end method


# virtual methods
.method public run()V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 154
    iget-object v0, p0, Lcom/example/application4/GlobalApplication$CrashHandler$PartCrashHandler$100000000;->this$0:Lcom/example/application4/GlobalApplication$CrashHandler$PartCrashHandler;

    invoke-static {v0}, Lcom/example/application4/GlobalApplication$CrashHandler$PartCrashHandler;->access$L1000003(Lcom/example/application4/GlobalApplication$CrashHandler$PartCrashHandler;)Landroid/content/Context;

    move-result-object v0

    iget-object v1, p0, Lcom/example/application4/GlobalApplication$CrashHandler$PartCrashHandler$100000000;->val$e:Ljava/lang/Throwable;

    invoke-virtual {v1}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x1

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return-void
.end method
