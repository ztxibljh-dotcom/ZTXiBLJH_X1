.class Lcom/example/application4/GlobalApplication$CrashHandler$PartCrashHandler;
.super Ljava/lang/Object;
.source "GlobalApplication.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/example/application4/GlobalApplication$CrashHandler;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2a
    name = "PartCrashHandler"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/example/application4/GlobalApplication$CrashHandler$PartCrashHandler$100000000;
    }
.end annotation


# instance fields
.field public isRunning:Ljava/util/concurrent/atomic/AtomicBoolean;

.field private final mContext:Landroid/content/Context;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 4

    .line 138
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    iput-object v0, p0, Lcom/example/application4/GlobalApplication$CrashHandler$PartCrashHandler;->isRunning:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 139
    iput-object p1, p0, Lcom/example/application4/GlobalApplication$CrashHandler$PartCrashHandler;->mContext:Landroid/content/Context;

    return-void
.end method

.method static synthetic access$L1000003(Lcom/example/application4/GlobalApplication$CrashHandler$PartCrashHandler;)Landroid/content/Context;
    .registers 1

    iget-object p0, p0, Lcom/example/application4/GlobalApplication$CrashHandler$PartCrashHandler;->mContext:Landroid/content/Context;

    return-object p0
.end method


# virtual methods
.method public run()V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 144
    :goto_0
    iget-object v0, p0, Lcom/example/application4/GlobalApplication$CrashHandler$PartCrashHandler;->isRunning:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    if-nez v0, :cond_9

    return-void

    .line 146
    :cond_9
    :try_start_9
    invoke-static {}, Landroid/os/Looper;->loop()V
    :try_end_c
    .catchall {:try_start_9 .. :try_end_c} :catchall_d

    goto :goto_0

    :catchall_d
    move-exception v0

    .line 148
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    .line 149
    iget-object v1, p0, Lcom/example/application4/GlobalApplication$CrashHandler$PartCrashHandler;->isRunning:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v1

    if-eqz v1, :cond_26

    .line 150
    invoke-static {}, Lcom/example/application4/GlobalApplication;->access$L1000000()Landroid/os/Handler;

    move-result-object v1

    new-instance v2, Lcom/example/application4/GlobalApplication$CrashHandler$PartCrashHandler$100000000;

    invoke-direct {v2, p0, v0}, Lcom/example/application4/GlobalApplication$CrashHandler$PartCrashHandler$100000000;-><init>(Lcom/example/application4/GlobalApplication$CrashHandler$PartCrashHandler;Ljava/lang/Throwable;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 161
    goto :goto_0

    .line 158
    :cond_26
    instance-of v1, v0, Ljava/lang/RuntimeException;

    if-eqz v1, :cond_2d

    .line 159
    check-cast v0, Ljava/lang/RuntimeException;

    throw v0

    .line 161
    :cond_2d
    new-instance v1, Ljava/lang/RuntimeException;

    invoke-direct {v1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    throw v1
.end method
