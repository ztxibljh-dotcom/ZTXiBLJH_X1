.class public Lcom/example/application4/GlobalApplication$CrashHandler;
.super Ljava/lang/Object;
.source "GlobalApplication.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/example/application4/GlobalApplication;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x29
    name = "CrashHandler"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/example/application4/GlobalApplication$CrashHandler$UncaughtExceptionHandlerImpl;,
        Lcom/example/application4/GlobalApplication$CrashHandler$PartCrashHandler;
    }
.end annotation


# static fields
.field public static final DEFAULT_UNCAUGHT_EXCEPTION_HANDLER:Ljava/lang/Thread$UncaughtExceptionHandler;

.field private static sInstance:Lcom/example/application4/GlobalApplication$CrashHandler;


# instance fields
.field private mPartCrashHandler:Lcom/example/application4/GlobalApplication$CrashHandler$PartCrashHandler;


# direct methods
.method static final constructor <clinit>()V
    .registers 1

    invoke-static {}, Ljava/lang/Thread;->getDefaultUncaughtExceptionHandler()Ljava/lang/Thread$UncaughtExceptionHandler;

    move-result-object v0

    sput-object v0, Lcom/example/application4/GlobalApplication$CrashHandler;->DEFAULT_UNCAUGHT_EXCEPTION_HANDLER:Ljava/lang/Thread$UncaughtExceptionHandler;

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    .line 260
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static getInstance()Lcom/example/application4/GlobalApplication$CrashHandler;
    .registers 1

    .line 101
    sget-object v0, Lcom/example/application4/GlobalApplication$CrashHandler;->sInstance:Lcom/example/application4/GlobalApplication$CrashHandler;

    if-nez v0, :cond_b

    .line 102
    new-instance v0, Lcom/example/application4/GlobalApplication$CrashHandler;

    invoke-direct {v0}, Lcom/example/application4/GlobalApplication$CrashHandler;-><init>()V

    sput-object v0, Lcom/example/application4/GlobalApplication$CrashHandler;->sInstance:Lcom/example/application4/GlobalApplication$CrashHandler;

    .line 104
    :cond_b
    sget-object v0, Lcom/example/application4/GlobalApplication$CrashHandler;->sInstance:Lcom/example/application4/GlobalApplication$CrashHandler;

    return-object v0
.end method


# virtual methods
.method public registerGlobal(Landroid/content/Context;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")V"
        }
    .end annotation

    .line 108
    const/4 v0, 0x0

    move-object v1, v0

    check-cast v1, Ljava/lang/String;

    invoke-virtual {p0, p1, v0}, Lcom/example/application4/GlobalApplication$CrashHandler;->registerGlobal(Landroid/content/Context;Ljava/lang/String;)V

    return-void
.end method

.method public registerGlobal(Landroid/content/Context;Ljava/lang/String;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 112
    new-instance v0, Lcom/example/application4/GlobalApplication$CrashHandler$UncaughtExceptionHandlerImpl;

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    invoke-direct {v0, p1, p2}, Lcom/example/application4/GlobalApplication$CrashHandler$UncaughtExceptionHandlerImpl;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    invoke-static {v0}, Ljava/lang/Thread;->setDefaultUncaughtExceptionHandler(Ljava/lang/Thread$UncaughtExceptionHandler;)V

    return-void
.end method

.method public registerPart(Landroid/content/Context;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")V"
        }
    .end annotation

    .line 120
    invoke-virtual {p0, p1}, Lcom/example/application4/GlobalApplication$CrashHandler;->unregisterPart(Landroid/content/Context;)V

    .line 121
    new-instance v0, Lcom/example/application4/GlobalApplication$CrashHandler$PartCrashHandler;

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    invoke-direct {v0, p1}, Lcom/example/application4/GlobalApplication$CrashHandler$PartCrashHandler;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lcom/example/application4/GlobalApplication$CrashHandler;->mPartCrashHandler:Lcom/example/application4/GlobalApplication$CrashHandler$PartCrashHandler;

    .line 122
    invoke-static {}, Lcom/example/application4/GlobalApplication;->access$L1000000()Landroid/os/Handler;

    move-result-object p1

    iget-object v0, p0, Lcom/example/application4/GlobalApplication$CrashHandler;->mPartCrashHandler:Lcom/example/application4/GlobalApplication$CrashHandler$PartCrashHandler;

    invoke-virtual {p1, v0}, Landroid/os/Handler;->postAtFrontOfQueue(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public unregister()V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 116
    sget-object v0, Lcom/example/application4/GlobalApplication$CrashHandler;->DEFAULT_UNCAUGHT_EXCEPTION_HANDLER:Ljava/lang/Thread$UncaughtExceptionHandler;

    invoke-static {v0}, Ljava/lang/Thread;->setDefaultUncaughtExceptionHandler(Ljava/lang/Thread$UncaughtExceptionHandler;)V

    return-void
.end method

.method public unregisterPart(Landroid/content/Context;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")V"
        }
    .end annotation

    .line 126
    iget-object p1, p0, Lcom/example/application4/GlobalApplication$CrashHandler;->mPartCrashHandler:Lcom/example/application4/GlobalApplication$CrashHandler$PartCrashHandler;

    if-eqz p1, :cond_10

    .line 127
    iget-object p1, p1, Lcom/example/application4/GlobalApplication$CrashHandler$PartCrashHandler;->isRunning:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    .line 128
    const/4 p1, 0x0

    move-object v0, p1

    check-cast v0, Lcom/example/application4/GlobalApplication$CrashHandler$PartCrashHandler;

    iput-object p1, p0, Lcom/example/application4/GlobalApplication$CrashHandler;->mPartCrashHandler:Lcom/example/application4/GlobalApplication$CrashHandler$PartCrashHandler;

    :cond_10
    return-void
.end method
