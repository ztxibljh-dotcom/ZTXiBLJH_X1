.class public Lcom/example/application4/GlobalApplication;
.super Landroid/app/Application;
.source "GlobalApplication.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/example/application4/GlobalApplication$CrashHandler;,
        Lcom/example/application4/GlobalApplication$CrashActivity;
    }
.end annotation


# static fields
.field private static MAIN_HANDLER:Landroid/os/Handler;


# direct methods
.method static final constructor <clinit>()V
    .registers 2

    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    sput-object v0, Lcom/example/application4/GlobalApplication;->MAIN_HANDLER:Landroid/os/Handler;

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    .line 333
    invoke-direct {p0}, Landroid/app/Application;-><init>()V

    return-void
.end method

.method static synthetic access$L1000000()Landroid/os/Handler;
    .registers 1

    sget-object v0, Lcom/example/application4/GlobalApplication;->MAIN_HANDLER:Landroid/os/Handler;

    return-object v0
.end method

.method static synthetic access$S1000000(Landroid/os/Handler;)V
    .registers 1

    sput-object p0, Lcom/example/application4/GlobalApplication;->MAIN_HANDLER:Landroid/os/Handler;

    return-void
.end method

.method public static varargs closeIO([Ljava/io/Closeable;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([",
            "Ljava/io/Closeable;",
            ")V"
        }
    .end annotation

    .line 85
    const/4 v0, 0x0

    .line 87
    :goto_1
    array-length v1, p0

    if-lt v0, v1, :cond_5

    return-void

    .line 85
    :cond_5
    aget-object v1, p0, v0

    .line 87
    if-eqz v1, :cond_e

    :try_start_9
    invoke-interface {v1}, Ljava/io/Closeable;->close()V
    :try_end_c
    .catch Ljava/io/IOException; {:try_start_9 .. :try_end_c} :catch_d

    goto :goto_e

    :catch_d
    move-exception v1

    :cond_e
    :goto_e
    add-int/lit8 v0, v0, 0x1

    goto :goto_1
.end method

.method public static toString(Ljava/io/InputStream;)Ljava/lang/String;
    .registers 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 75
    new-instance v0, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    .line 76
    invoke-static {p0, v0}, Lcom/example/application4/GlobalApplication;->write(Ljava/io/InputStream;Ljava/io/OutputStream;)V

    .line 78
    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    :try_start_b
    const-string v4, "UTF-8"

    invoke-virtual {v0, v4}, Ljava/io/ByteArrayOutputStream;->toString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 80
    new-array v5, v3, [Ljava/io/Closeable;

    aput-object p0, v5, v2

    aput-object v0, v5, v1

    invoke-static {v5}, Lcom/example/application4/GlobalApplication;->closeIO([Ljava/io/Closeable;)V
    :try_end_1a
    .catchall {:try_start_b .. :try_end_1a} :catchall_1b

    return-object v4

    :catchall_1b
    move-exception v4

    new-array v3, v3, [Ljava/io/Closeable;

    aput-object p0, v3, v2

    aput-object v0, v3, v1

    invoke-static {v3}, Lcom/example/application4/GlobalApplication;->closeIO([Ljava/io/Closeable;)V

    throw v4
.end method

.method public static write(Ljava/io/File;[B)V
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/io/File;",
            "[B)V^",
            "Ljava/io/IOException;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 62
    invoke-virtual {p0}, Ljava/io/File;->getParentFile()Ljava/io/File;

    move-result-object v0

    .line 63
    if-eqz v0, :cond_f

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v1

    if-nez v1, :cond_f

    invoke-virtual {v0}, Ljava/io/File;->mkdirs()Z

    .line 65
    :cond_f
    new-instance v0, Ljava/io/ByteArrayInputStream;

    invoke-direct {v0, p1}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    .line 66
    new-instance p1, Ljava/io/FileOutputStream;

    invoke-direct {p1, p0}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    .line 68
    const/4 p0, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    :try_start_1c
    invoke-static {v0, p1}, Lcom/example/application4/GlobalApplication;->write(Ljava/io/InputStream;Ljava/io/OutputStream;)V
    :try_end_1f
    .catchall {:try_start_1c .. :try_end_1f} :catchall_29

    .line 70
    new-array v2, v2, [Ljava/io/Closeable;

    aput-object v0, v2, v1

    aput-object p1, v2, p0

    invoke-static {v2}, Lcom/example/application4/GlobalApplication;->closeIO([Ljava/io/Closeable;)V

    return-void

    .line 68
    :catchall_29
    move-exception v3

    .line 70
    new-array v2, v2, [Ljava/io/Closeable;

    aput-object v0, v2, v1

    aput-object p1, v2, p0

    invoke-static {v2}, Lcom/example/application4/GlobalApplication;->closeIO([Ljava/io/Closeable;)V

    throw v3
.end method

.method public static write(Ljava/io/InputStream;Ljava/io/OutputStream;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/io/InputStream;",
            "Ljava/io/OutputStream;",
            ")V^",
            "Ljava/io/IOException;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 54
    const/16 v0, 0x2000

    new-array v0, v0, [B

    .line 55
    nop

    .line 56
    :goto_5
    invoke-virtual {p0, v0}, Ljava/io/InputStream;->read([B)I

    move-result v1

    const/4 v2, -0x1

    if-ne v1, v2, :cond_d

    return-void

    .line 57
    :cond_d
    const/4 v2, 0x0

    invoke-virtual {p1, v0, v2, v1}, Ljava/io/OutputStream;->write([BII)V

    goto :goto_5
.end method


# virtual methods
.method public onCreate()V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 48
    invoke-super {p0}, Landroid/app/Application;->onCreate()V

    .line 49
    invoke-static {}, Lcom/example/application4/GlobalApplication$CrashHandler;->getInstance()Lcom/example/application4/GlobalApplication$CrashHandler;

    move-result-object v0

    invoke-virtual {v0, p0}, Lcom/example/application4/GlobalApplication$CrashHandler;->registerGlobal(Landroid/content/Context;)V

    .line 50
    invoke-static {}, Lcom/example/application4/GlobalApplication$CrashHandler;->getInstance()Lcom/example/application4/GlobalApplication$CrashHandler;

    move-result-object v0

    invoke-virtual {v0, p0}, Lcom/example/application4/GlobalApplication$CrashHandler;->registerPart(Landroid/content/Context;)V

    return-void
.end method
