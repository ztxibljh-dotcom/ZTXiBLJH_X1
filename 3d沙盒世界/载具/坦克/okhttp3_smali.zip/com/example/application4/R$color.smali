.class public final Lcom/example/application4/R$color;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/example/application4/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x39
    name = "color"
.end annotation


# static fields
.field public static final colorAccent:I = 0x7f040002

.field public static final colorPrimary:I = 0x7f040000

.field public static final colorPrimaryDark:I = 0x7f040001


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 16
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
