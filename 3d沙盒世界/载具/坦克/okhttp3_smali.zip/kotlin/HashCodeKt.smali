.class public final Lkotlin/HashCodeKt;
.super Ljava/lang/Object;
.source "HashCode.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    bv = {
        0x1,
        0x0,
        0x3
    }
    d1 = {
        "\u0000\f\n\u0000\n\u0002\u0010\b\n\u0002\u0010\u0000\n\u0000\u001a\u000f\u0010\u0000\u001a\u00020\u0001*\u0004\u0018\u00010\u0002H\u0087\b¨\u0006\u0003"
    }
    d2 = {
        "hashCode",
        "",
        "",
        "kotlin-stdlib"
    }
    k = 0x2
    mv = {
        0x1,
        0x4,
        0x0
    }
.end annotation


# direct methods
.method private static final hashCode(Ljava/lang/Object;)I
    .registers 3
    .param p0, "$this$hashCode"  # Ljava/lang/Object;

    const/4 v0, 0x0

    .line 18
    .local v0, "$i$f$hashCode":I
    if-eqz p0, :cond_8

    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    move-result v1

    goto :goto_9

    :cond_8
    const/4 v1, 0x0

    :goto_9
    return v1
.end method
