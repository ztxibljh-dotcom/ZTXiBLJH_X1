.class public final Lkotlin/StandardKt;
.super Lkotlin/StandardKt__SynchronizedKt;


# annotations
.annotation runtime Lkotlin/Metadata;
    bv = {
        0x1,
        0x0,
        0x3
    }
    d1 = {
        "kotlin/StandardKt__StandardKt",
        "kotlin/StandardKt__SynchronizedKt"
    }
    k = 0x4
    mv = {
        0x1,
        0x4,
        0x0
    }
    xi = 0x1
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Lkotlin/StandardKt__SynchronizedKt;-><init>()V

    return-void
.end method
