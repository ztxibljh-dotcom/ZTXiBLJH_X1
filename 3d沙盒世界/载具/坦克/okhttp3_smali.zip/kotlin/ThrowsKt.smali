.class public final Lkotlin/ThrowsKt;
.super Ljava/lang/Object;
.source "Throws.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    bv = {
        0x1,
        0x0,
        0x3
    }
    d1 = {
        "\u0000\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003*\u001a\b\u0007\u0010\u0000\"\u00020\u00012\u00020\u0001B\f\b\u0002\u0012\b\b\u0003\u0012\u0004\b\b(\u0004¨\u0006\u0005"
    }
    d2 = {
        "Throws",
        "Lkotlin/jvm/Throws;",
        "Lkotlin/SinceKotlin;",
        "version",
        "1.4",
        "kotlin-stdlib"
    }
    k = 0x2
    mv = {
        0x1,
        0x4,
        0x0
    }
.end annotation


# direct methods
.method public static synthetic Throws$annotations()V
    .registers 0

    return-void
.end method
