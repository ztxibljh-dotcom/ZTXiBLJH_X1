.class public final Lkotlin/UByte;
.super Ljava/lang/Object;
.source "UByte.kt"

# interfaces
.implements Ljava/lang/Comparable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lkotlin/UByte$Companion;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/lang/Comparable<",
        "Lkotlin/UByte;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    bv = {
        0x1,
        0x0,
        0x3
    }
    d1 = {
        "\u0000n\n\u0002\u0018\u0002\n\u0002\u0010\u000f\n\u0000\n\u0002\u0010\u0005\n\u0002\b\t\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0010\u000b\n\u0002\u0010\u0000\n\u0002\b\u0012\n\u0002\u0018\u0002\n\u0002\b\u000f\n\u0002\u0010\u0006\n\u0002\b\u0003\n\u0002\u0010\u0007\n\u0002\b\u0006\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0010\n\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u000e\b\u0087@\u0018\u0000 f2\b\u0012\u0004\u0012\u00020\u00000\u0001:\u0001fB\u0014\b\u0001\u0012\u0006\u0010\u0002\u001a\u00020\u0003ø\u0001\u0000¢\u0006\u0004\b\u0004\u0010\u0005J\u001b\u0010\b\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\u0000H\u0087\fø\u0001\u0000¢\u0006\u0004\b\n\u0010\u000bJ\u001b\u0010\f\u001a\u00020\r2\u0006\u0010\t\u001a\u00020\u0000H\u0097\nø\u0001\u0000¢\u0006\u0004\b\u000e\u0010\u000fJ\u001b\u0010\f\u001a\u00020\r2\u0006\u0010\t\u001a\u00020\u0010H\u0087\nø\u0001\u0000¢\u0006\u0004\b\u0011\u0010\u0012J\u001b\u0010\f\u001a\u00020\r2\u0006\u0010\t\u001a\u00020\u0013H\u0087\nø\u0001\u0000¢\u0006\u0004\b\u0014\u0010\u0015J\u001b\u0010\f\u001a\u00020\r2\u0006\u0010\t\u001a\u00020\u0016H\u0087\nø\u0001\u0000¢\u0006\u0004\b\u0017\u0010\u0018J\u0016\u0010\u0019\u001a\u00020\u0000H\u0087\nø\u0001\u0000ø\u0001\u0001¢\u0006\u0004\b\u001a\u0010\u0005J\u001b\u0010\u001b\u001a\u00020\u00102\u0006\u0010\t\u001a\u00020\u0000H\u0087\nø\u0001\u0000¢\u0006\u0004\b\u001c\u0010\u000fJ\u001b\u0010\u001b\u001a\u00020\u00102\u0006\u0010\t\u001a\u00020\u0010H\u0087\nø\u0001\u0000¢\u0006\u0004\b\u001d\u0010\u0012J\u001b\u0010\u001b\u001a\u00020\u00132\u0006\u0010\t\u001a\u00020\u0013H\u0087\nø\u0001\u0000¢\u0006\u0004\b\u001e\u0010\u001fJ\u001b\u0010\u001b\u001a\u00020\u00102\u0006\u0010\t\u001a\u00020\u0016H\u0087\nø\u0001\u0000¢\u0006\u0004\b \u0010\u0018J\u0013\u0010!\u001a\u00020\"2\b\u0010\t\u001a\u0004\u0018\u00010#HÖ\u0003J\t\u0010$\u001a\u00020\rHÖ\u0001J\u0016\u0010%\u001a\u00020\u0000H\u0087\nø\u0001\u0000ø\u0001\u0001¢\u0006\u0004\b&\u0010\u0005J\u0016\u0010\'\u001a\u00020\u0000H\u0087\bø\u0001\u0000ø\u0001\u0001¢\u0006\u0004\b(\u0010\u0005J\u001b\u0010)\u001a\u00020\u00102\u0006\u0010\t\u001a\u00020\u0000H\u0087\nø\u0001\u0000¢\u0006\u0004\b*\u0010\u000fJ\u001b\u0010)\u001a\u00020\u00102\u0006\u0010\t\u001a\u00020\u0010H\u0087\nø\u0001\u0000¢\u0006\u0004\b+\u0010\u0012J\u001b\u0010)\u001a\u00020\u00132\u0006\u0010\t\u001a\u00020\u0013H\u0087\nø\u0001\u0000¢\u0006\u0004\b,\u0010\u001fJ\u001b\u0010)\u001a\u00020\u00102\u0006\u0010\t\u001a\u00020\u0016H\u0087\nø\u0001\u0000¢\u0006\u0004\b-\u0010\u0018J\u001b\u0010.\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\u0000H\u0087\fø\u0001\u0000¢\u0006\u0004\b/\u0010\u000bJ\u001b\u00100\u001a\u00020\u00102\u0006\u0010\t\u001a\u00020\u0000H\u0087\nø\u0001\u0000¢\u0006\u0004\b1\u0010\u000fJ\u001b\u00100\u001a\u00020\u00102\u0006\u0010\t\u001a\u00020\u0010H\u0087\nø\u0001\u0000¢\u0006\u0004\b2\u0010\u0012J\u001b\u00100\u001a\u00020\u00132\u0006\u0010\t\u001a\u00020\u0013H\u0087\nø\u0001\u0000¢\u0006\u0004\b3\u0010\u001fJ\u001b\u00100\u001a\u00020\u00102\u0006\u0010\t\u001a\u00020\u0016H\u0087\nø\u0001\u0000¢\u0006\u0004\b4\u0010\u0018J\u001b\u00105\u001a\u0002062\u0006\u0010\t\u001a\u00020\u0000H\u0087\nø\u0001\u0000¢\u0006\u0004\b7\u00108J\u001b\u00109\u001a\u00020\u00102\u0006\u0010\t\u001a\u00020\u0000H\u0087\nø\u0001\u0000¢\u0006\u0004\b:\u0010\u000fJ\u001b\u00109\u001a\u00020\u00102\u0006\u0010\t\u001a\u00020\u0010H\u0087\nø\u0001\u0000¢\u0006\u0004\b;\u0010\u0012J\u001b\u00109\u001a\u00020\u00132\u0006\u0010\t\u001a\u00020\u0013H\u0087\nø\u0001\u0000¢\u0006\u0004\b<\u0010\u001fJ\u001b\u00109\u001a\u00020\u00102\u0006\u0010\t\u001a\u00020\u0016H\u0087\nø\u0001\u0000¢\u0006\u0004\b=\u0010\u0018J\u001b\u0010>\u001a\u00020\u00102\u0006\u0010\t\u001a\u00020\u0000H\u0087\nø\u0001\u0000¢\u0006\u0004\b?\u0010\u000fJ\u001b\u0010>\u001a\u00020\u00102\u0006\u0010\t\u001a\u00020\u0010H\u0087\nø\u0001\u0000¢\u0006\u0004\b@\u0010\u0012J\u001b\u0010>\u001a\u00020\u00132\u0006\u0010\t\u001a\u00020\u0013H\u0087\nø\u0001\u0000¢\u0006\u0004\bA\u0010\u001fJ\u001b\u0010>\u001a\u00020\u00102\u0006\u0010\t\u001a\u00020\u0016H\u0087\nø\u0001\u0000¢\u0006\u0004\bB\u0010\u0018J\u0010\u0010C\u001a\u00020\u0003H\u0087\b¢\u0006\u0004\bD\u0010\u0005J\u0010\u0010E\u001a\u00020FH\u0087\b¢\u0006\u0004\bG\u0010HJ\u0010\u0010I\u001a\u00020JH\u0087\b¢\u0006\u0004\bK\u0010LJ\u0010\u0010M\u001a\u00020\rH\u0087\b¢\u0006\u0004\bN\u0010OJ\u0010\u0010P\u001a\u00020QH\u0087\b¢\u0006\u0004\bR\u0010SJ\u0010\u0010T\u001a\u00020UH\u0087\b¢\u0006\u0004\bV\u0010WJ\u000f\u0010X\u001a\u00020YH\u0016¢\u0006\u0004\bZ\u0010[J\u0016\u0010\\\u001a\u00020\u0000H\u0087\bø\u0001\u0000ø\u0001\u0001¢\u0006\u0004\b]\u0010\u0005J\u0016\u0010^\u001a\u00020\u0010H\u0087\bø\u0001\u0000ø\u0001\u0001¢\u0006\u0004\b_\u0010OJ\u0016\u0010`\u001a\u00020\u0013H\u0087\bø\u0001\u0000ø\u0001\u0001¢\u0006\u0004\ba\u0010SJ\u0016\u0010b\u001a\u00020\u0016H\u0087\bø\u0001\u0000ø\u0001\u0001¢\u0006\u0004\bc\u0010WJ\u001b\u0010d\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\u0000H\u0087\fø\u0001\u0000¢\u0006\u0004\be\u0010\u000bR\u0016\u0010\u0002\u001a\u00020\u00038\u0000X\u0081\u0004¢\u0006\b\n\u0000\u0012\u0004\b\u0006\u0010\u0007ø\u0001\u0000\u0082\u0002\b\n\u0002\b\u0019\n\u0002\b!¨\u0006g"
    }
    d2 = {
        "Lkotlin/UByte;",
        "",
        "data",
        "",
        "constructor-impl",
        "(B)B",
        "getData$annotations",
        "()V",
        "and",
        "other",
        "and-7apg3OU",
        "(BB)B",
        "compareTo",
        "",
        "compareTo-7apg3OU",
        "(BB)I",
        "Lkotlin/UInt;",
        "compareTo-WZ4Q5Ns",
        "(BI)I",
        "Lkotlin/ULong;",
        "compareTo-VKZWuLQ",
        "(BJ)I",
        "Lkotlin/UShort;",
        "compareTo-xj2QHRw",
        "(BS)I",
        "dec",
        "dec-w2LRezQ",
        "div",
        "div-7apg3OU",
        "div-WZ4Q5Ns",
        "div-VKZWuLQ",
        "(BJ)J",
        "div-xj2QHRw",
        "equals",
        "",
        "",
        "hashCode",
        "inc",
        "inc-w2LRezQ",
        "inv",
        "inv-w2LRezQ",
        "minus",
        "minus-7apg3OU",
        "minus-WZ4Q5Ns",
        "minus-VKZWuLQ",
        "minus-xj2QHRw",
        "or",
        "or-7apg3OU",
        "plus",
        "plus-7apg3OU",
        "plus-WZ4Q5Ns",
        "plus-VKZWuLQ",
        "plus-xj2QHRw",
        "rangeTo",
        "Lkotlin/ranges/UIntRange;",
        "rangeTo-7apg3OU",
        "(BB)Lkotlin/ranges/UIntRange;",
        "rem",
        "rem-7apg3OU",
        "rem-WZ4Q5Ns",
        "rem-VKZWuLQ",
        "rem-xj2QHRw",
        "times",
        "times-7apg3OU",
        "times-WZ4Q5Ns",
        "times-VKZWuLQ",
        "times-xj2QHRw",
        "toByte",
        "toByte-impl",
        "toDouble",
        "",
        "toDouble-impl",
        "(B)D",
        "toFloat",
        "",
        "toFloat-impl",
        "(B)F",
        "toInt",
        "toInt-impl",
        "(B)I",
        "toLong",
        "",
        "toLong-impl",
        "(B)J",
        "toShort",
        "",
        "toShort-impl",
        "(B)S",
        "toString",
        "",
        "toString-impl",
        "(B)Ljava/lang/String;",
        "toUByte",
        "toUByte-w2LRezQ",
        "toUInt",
        "toUInt-pVg5ArA",
        "toULong",
        "toULong-s-VKNKU",
        "toUShort",
        "toUShort-Mh2AYeg",
        "xor",
        "xor-7apg3OU",
        "Companion",
        "kotlin-stdlib"
    }
    k = 0x1
    mv = {
        0x1,
        0x4,
        0x0
    }
.end annotation


# static fields
.field public static final Companion:Lkotlin/UByte$Companion;

.field public static final MAX_VALUE:B = -0x1t

.field public static final MIN_VALUE:B = 0x0t

.field public static final SIZE_BITS:I = 0x8

.field public static final SIZE_BYTES:I = 0x1


# instance fields
.field private final data:B


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lkotlin/UByte$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lkotlin/UByte$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lkotlin/UByte;->Companion:Lkotlin/UByte$Companion;

    return-void
.end method

.method private synthetic constructor <init>(B)V
    .registers 2
    .param p1, "data"  # B

    .line 15
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-byte p1, p0, Lkotlin/UByte;->data:B

    return-void
.end method

.method private static final and-7apg3OU(BB)B
    .registers 4
    .param p0, "$this"  # B
    .param p1, "other"  # B

    const/4 v0, 0x0

    .line 150
    .local v0, "$i$f$and-7apg3OU":I
    and-int v1, p0, p1

    int-to-byte v1, v1

    invoke-static {v1}, Lkotlin/UByte;->constructor-impl(B)B

    move-result v1

    return v1
.end method

.method public static final synthetic box-impl(B)Lkotlin/UByte;
    .registers 2

    new-instance v0, Lkotlin/UByte;

    invoke-direct {v0, p0}, Lkotlin/UByte;-><init>(B)V

    return-object v0
.end method

.method private compareTo-7apg3OU(B)I
    .registers 3

    .line 1
    iget-byte v0, p0, Lkotlin/UByte;->data:B

    invoke-static {v0, p1}, Lkotlin/UByte;->compareTo-7apg3OU(BB)I

    move-result p1

    return p1
.end method

.method private static compareTo-7apg3OU(BB)I
    .registers 5
    .param p0, "$this"  # B
    .param p1, "other"  # B

    const/4 v0, 0x0

    .line 46
    .local v0, "$i$f$compareTo-7apg3OU":I
    and-int/lit16 v1, p0, 0xff

    and-int/lit16 v2, p1, 0xff

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->compare(II)I

    move-result v1

    return v1
.end method

.method private static final compareTo-VKZWuLQ(BJ)I
    .registers 8
    .param p0, "$this"  # B
    .param p1, "other"  # J

    const/4 v0, 0x0

    .line 70
    .local v0, "$i$f$compareTo-VKZWuLQ":I
    int-to-long v1, p0

    const-wide/16 v3, 0xff

    and-long/2addr v1, v3

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    invoke-static {v1, v2, p1, p2}, Lkotlin/UnsignedKt;->ulongCompare(JJ)I

    move-result v1

    return v1
.end method

.method private static final compareTo-WZ4Q5Ns(BI)I
    .registers 4
    .param p0, "$this"  # B
    .param p1, "other"  # I

    const/4 v0, 0x0

    .line 62
    .local v0, "$i$f$compareTo-WZ4Q5Ns":I
    and-int/lit16 v1, p0, 0xff

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    invoke-static {v1, p1}, Lkotlin/UnsignedKt;->uintCompare(II)I

    move-result v1

    return v1
.end method

.method private static final compareTo-xj2QHRw(BS)I
    .registers 5
    .param p0, "$this"  # B
    .param p1, "other"  # S

    const/4 v0, 0x0

    .line 54
    .local v0, "$i$f$compareTo-xj2QHRw":I
    and-int/lit16 v1, p0, 0xff

    const v2, 0xffff

    and-int/2addr v2, p1

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->compare(II)I

    move-result v1

    return v1
.end method

.method public static constructor-impl(B)B
    .registers 1
    .param p0, "data"  # B

    .line 15
    return p0
.end method

.method private static final dec-w2LRezQ(B)B
    .registers 3
    .param p0, "$this"  # B

    const/4 v0, 0x0

    .line 142
    .local v0, "$i$f$dec-w2LRezQ":I
    add-int/lit8 v1, p0, -0x1

    int-to-byte v1, v1

    invoke-static {v1}, Lkotlin/UByte;->constructor-impl(B)B

    move-result v1

    return v1
.end method

.method private static final div-7apg3OU(BB)I
    .registers 5
    .param p0, "$this"  # B
    .param p1, "other"  # B

    const/4 v0, 0x0

    .line 113
    .local v0, "$i$f$div-7apg3OU":I
    and-int/lit16 v1, p0, 0xff

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    and-int/lit16 v2, p1, 0xff

    invoke-static {v2}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v2

    invoke-static {v1, v2}, Lkotlin/UnsignedKt;->uintDivide-J1ME1BU(II)I

    move-result v1

    return v1
.end method

.method private static final div-VKZWuLQ(BJ)J
    .registers 8
    .param p0, "$this"  # B
    .param p1, "other"  # J

    const/4 v0, 0x0

    .line 122
    .local v0, "$i$f$div-VKZWuLQ":I
    int-to-long v1, p0

    const-wide/16 v3, 0xff

    and-long/2addr v1, v3

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    invoke-static {v1, v2, p1, p2}, Lkotlin/UnsignedKt;->ulongDivide-eb3DHEI(JJ)J

    move-result-wide v1

    return-wide v1
.end method

.method private static final div-WZ4Q5Ns(BI)I
    .registers 4
    .param p0, "$this"  # B
    .param p1, "other"  # I

    const/4 v0, 0x0

    .line 119
    .local v0, "$i$f$div-WZ4Q5Ns":I
    and-int/lit16 v1, p0, 0xff

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    invoke-static {v1, p1}, Lkotlin/UnsignedKt;->uintDivide-J1ME1BU(II)I

    move-result v1

    return v1
.end method

.method private static final div-xj2QHRw(BS)I
    .registers 5
    .param p0, "$this"  # B
    .param p1, "other"  # S

    const/4 v0, 0x0

    .line 116
    .local v0, "$i$f$div-xj2QHRw":I
    and-int/lit16 v1, p0, 0xff

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    const v2, 0xffff

    and-int/2addr v2, p1

    invoke-static {v2}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v2

    invoke-static {v1, v2}, Lkotlin/UnsignedKt;->uintDivide-J1ME1BU(II)I

    move-result v1

    return v1
.end method

.method public static equals-impl(BLjava/lang/Object;)Z
    .registers 3

    instance-of v0, p1, Lkotlin/UByte;

    if-eqz v0, :cond_e

    check-cast p1, Lkotlin/UByte;

    invoke-virtual {p1}, Lkotlin/UByte;->unbox-impl()B

    move-result p1

    if-ne p0, p1, :cond_e

    const/4 p0, 0x1

    return p0

    :cond_e
    const/4 p0, 0x0

    return p0
.end method

.method public static final equals-impl0(BB)Z
    .registers 3

    if-ne p0, p1, :cond_4

    const/4 v0, 0x1

    goto :goto_5

    :cond_4
    const/4 v0, 0x0

    :goto_5
    return v0
.end method

.method public static synthetic getData$annotations()V
    .registers 0

    return-void
.end method

.method public static hashCode-impl(B)I
    .registers 1

    return p0
.end method

.method private static final inc-w2LRezQ(B)B
    .registers 3
    .param p0, "$this"  # B

    const/4 v0, 0x0

    .line 139
    .local v0, "$i$f$inc-w2LRezQ":I
    add-int/lit8 v1, p0, 0x1

    int-to-byte v1, v1

    invoke-static {v1}, Lkotlin/UByte;->constructor-impl(B)B

    move-result v1

    return v1
.end method

.method private static final inv-w2LRezQ(B)B
    .registers 3
    .param p0, "$this"  # B

    const/4 v0, 0x0

    .line 159
    .local v0, "$i$f$inv-w2LRezQ":I
    not-int v1, p0

    int-to-byte v1, v1

    invoke-static {v1}, Lkotlin/UByte;->constructor-impl(B)B

    move-result v1

    return v1
.end method

.method private static final minus-7apg3OU(BB)I
    .registers 5
    .param p0, "$this"  # B
    .param p1, "other"  # B

    const/4 v0, 0x0

    .line 87
    .local v0, "$i$f$minus-7apg3OU":I
    and-int/lit16 v1, p0, 0xff

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    and-int/lit16 v2, p1, 0xff

    invoke-static {v2}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v2

    sub-int/2addr v1, v2

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    return v1
.end method

.method private static final minus-VKZWuLQ(BJ)J
    .registers 8
    .param p0, "$this"  # B
    .param p1, "other"  # J

    const/4 v0, 0x0

    .line 96
    .local v0, "$i$f$minus-VKZWuLQ":I
    int-to-long v1, p0

    const-wide/16 v3, 0xff

    and-long/2addr v1, v3

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    sub-long/2addr v1, p1

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    return-wide v1
.end method

.method private static final minus-WZ4Q5Ns(BI)I
    .registers 4
    .param p0, "$this"  # B
    .param p1, "other"  # I

    const/4 v0, 0x0

    .line 93
    .local v0, "$i$f$minus-WZ4Q5Ns":I
    and-int/lit16 v1, p0, 0xff

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    sub-int/2addr v1, p1

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    return v1
.end method

.method private static final minus-xj2QHRw(BS)I
    .registers 5
    .param p0, "$this"  # B
    .param p1, "other"  # S

    const/4 v0, 0x0

    .line 90
    .local v0, "$i$f$minus-xj2QHRw":I
    and-int/lit16 v1, p0, 0xff

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    const v2, 0xffff

    and-int/2addr v2, p1

    invoke-static {v2}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v2

    sub-int/2addr v1, v2

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    return v1
.end method

.method private static final or-7apg3OU(BB)B
    .registers 4
    .param p0, "$this"  # B
    .param p1, "other"  # B

    const/4 v0, 0x0

    .line 153
    .local v0, "$i$f$or-7apg3OU":I
    or-int v1, p0, p1

    int-to-byte v1, v1

    invoke-static {v1}, Lkotlin/UByte;->constructor-impl(B)B

    move-result v1

    return v1
.end method

.method private static final plus-7apg3OU(BB)I
    .registers 5
    .param p0, "$this"  # B
    .param p1, "other"  # B

    const/4 v0, 0x0

    .line 74
    .local v0, "$i$f$plus-7apg3OU":I
    and-int/lit16 v1, p0, 0xff

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    and-int/lit16 v2, p1, 0xff

    invoke-static {v2}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v2

    add-int/2addr v1, v2

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    return v1
.end method

.method private static final plus-VKZWuLQ(BJ)J
    .registers 8
    .param p0, "$this"  # B
    .param p1, "other"  # J

    const/4 v0, 0x0

    .line 83
    .local v0, "$i$f$plus-VKZWuLQ":I
    int-to-long v1, p0

    const-wide/16 v3, 0xff

    and-long/2addr v1, v3

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    add-long/2addr v1, p1

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    return-wide v1
.end method

.method private static final plus-WZ4Q5Ns(BI)I
    .registers 4
    .param p0, "$this"  # B
    .param p1, "other"  # I

    const/4 v0, 0x0

    .line 80
    .local v0, "$i$f$plus-WZ4Q5Ns":I
    and-int/lit16 v1, p0, 0xff

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    add-int/2addr v1, p1

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    return v1
.end method

.method private static final plus-xj2QHRw(BS)I
    .registers 5
    .param p0, "$this"  # B
    .param p1, "other"  # S

    const/4 v0, 0x0

    .line 77
    .local v0, "$i$f$plus-xj2QHRw":I
    and-int/lit16 v1, p0, 0xff

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    const v2, 0xffff

    and-int/2addr v2, p1

    invoke-static {v2}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v2

    add-int/2addr v1, v2

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    return v1
.end method

.method private static final rangeTo-7apg3OU(BB)Lkotlin/ranges/UIntRange;
    .registers 7
    .param p0, "$this"  # B
    .param p1, "other"  # B

    const/4 v0, 0x0

    .line 146
    .local v0, "$i$f$rangeTo-7apg3OU":I
    new-instance v1, Lkotlin/ranges/UIntRange;

    and-int/lit16 v2, p0, 0xff

    invoke-static {v2}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v2

    and-int/lit16 v3, p1, 0xff

    invoke-static {v3}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v3

    const/4 v4, 0x0

    invoke-direct {v1, v2, v3, v4}, Lkotlin/ranges/UIntRange;-><init>(IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    return-object v1
.end method

.method private static final rem-7apg3OU(BB)I
    .registers 5
    .param p0, "$this"  # B
    .param p1, "other"  # B

    const/4 v0, 0x0

    .line 126
    .local v0, "$i$f$rem-7apg3OU":I
    and-int/lit16 v1, p0, 0xff

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    and-int/lit16 v2, p1, 0xff

    invoke-static {v2}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v2

    invoke-static {v1, v2}, Lkotlin/UnsignedKt;->uintRemainder-J1ME1BU(II)I

    move-result v1

    return v1
.end method

.method private static final rem-VKZWuLQ(BJ)J
    .registers 8
    .param p0, "$this"  # B
    .param p1, "other"  # J

    const/4 v0, 0x0

    .line 135
    .local v0, "$i$f$rem-VKZWuLQ":I
    int-to-long v1, p0

    const-wide/16 v3, 0xff

    and-long/2addr v1, v3

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    invoke-static {v1, v2, p1, p2}, Lkotlin/UnsignedKt;->ulongRemainder-eb3DHEI(JJ)J

    move-result-wide v1

    return-wide v1
.end method

.method private static final rem-WZ4Q5Ns(BI)I
    .registers 4
    .param p0, "$this"  # B
    .param p1, "other"  # I

    const/4 v0, 0x0

    .line 132
    .local v0, "$i$f$rem-WZ4Q5Ns":I
    and-int/lit16 v1, p0, 0xff

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    invoke-static {v1, p1}, Lkotlin/UnsignedKt;->uintRemainder-J1ME1BU(II)I

    move-result v1

    return v1
.end method

.method private static final rem-xj2QHRw(BS)I
    .registers 5
    .param p0, "$this"  # B
    .param p1, "other"  # S

    const/4 v0, 0x0

    .line 129
    .local v0, "$i$f$rem-xj2QHRw":I
    and-int/lit16 v1, p0, 0xff

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    const v2, 0xffff

    and-int/2addr v2, p1

    invoke-static {v2}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v2

    invoke-static {v1, v2}, Lkotlin/UnsignedKt;->uintRemainder-J1ME1BU(II)I

    move-result v1

    return v1
.end method

.method private static final times-7apg3OU(BB)I
    .registers 5
    .param p0, "$this"  # B
    .param p1, "other"  # B

    const/4 v0, 0x0

    .line 100
    .local v0, "$i$f$times-7apg3OU":I
    and-int/lit16 v1, p0, 0xff

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    and-int/lit16 v2, p1, 0xff

    invoke-static {v2}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v2

    mul-int v1, v1, v2

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    return v1
.end method

.method private static final times-VKZWuLQ(BJ)J
    .registers 8
    .param p0, "$this"  # B
    .param p1, "other"  # J

    const/4 v0, 0x0

    .line 109
    .local v0, "$i$f$times-VKZWuLQ":I
    int-to-long v1, p0

    const-wide/16 v3, 0xff

    and-long/2addr v1, v3

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    mul-long v1, v1, p1

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    return-wide v1
.end method

.method private static final times-WZ4Q5Ns(BI)I
    .registers 4
    .param p0, "$this"  # B
    .param p1, "other"  # I

    const/4 v0, 0x0

    .line 106
    .local v0, "$i$f$times-WZ4Q5Ns":I
    and-int/lit16 v1, p0, 0xff

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    mul-int v1, v1, p1

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    return v1
.end method

.method private static final times-xj2QHRw(BS)I
    .registers 5
    .param p0, "$this"  # B
    .param p1, "other"  # S

    const/4 v0, 0x0

    .line 103
    .local v0, "$i$f$times-xj2QHRw":I
    and-int/lit16 v1, p0, 0xff

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    const v2, 0xffff

    and-int/2addr v2, p1

    invoke-static {v2}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v2

    mul-int v1, v1, v2

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    return v1
.end method

.method private static final toByte-impl(B)B
    .registers 2
    .param p0, "$this"  # B

    const/4 v0, 0x0

    .line 170
    .local v0, "$i$f$toByte":I
    return p0
.end method

.method private static final toDouble-impl(B)D
    .registers 4
    .param p0, "$this"  # B

    const/4 v0, 0x0

    .line 249
    .local v0, "$i$f$toDouble":I
    and-int/lit16 v1, p0, 0xff

    int-to-double v1, v1

    return-wide v1
.end method

.method private static final toFloat-impl(B)F
    .registers 3
    .param p0, "$this"  # B

    const/4 v0, 0x0

    .line 242
    .local v0, "$i$f$toFloat":I
    and-int/lit16 v1, p0, 0xff

    int-to-float v1, v1

    return v1
.end method

.method private static final toInt-impl(B)I
    .registers 3
    .param p0, "$this"  # B

    const/4 v0, 0x0

    .line 190
    .local v0, "$i$f$toInt":I
    and-int/lit16 v1, p0, 0xff

    return v1
.end method

.method private static final toLong-impl(B)J
    .registers 6
    .param p0, "$this"  # B

    const/4 v0, 0x0

    .line 200
    .local v0, "$i$f$toLong":I
    int-to-long v1, p0

    const-wide/16 v3, 0xff

    and-long/2addr v1, v3

    return-wide v1
.end method

.method private static final toShort-impl(B)S
    .registers 3
    .param p0, "$this"  # B

    const/4 v0, 0x0

    .line 180
    .local v0, "$i$f$toShort":I
    int-to-short v1, p0

    and-int/lit16 v1, v1, 0xff

    int-to-short v1, v1

    return v1
.end method

.method public static toString-impl(B)Ljava/lang/String;
    .registers 2
    .param p0, "$this"  # B

    .line 251
    and-int/lit16 v0, p0, 0xff

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static final toUByte-w2LRezQ(B)B
    .registers 2
    .param p0, "$this"  # B

    const/4 v0, 0x0

    .line 204
    .local v0, "$i$f$toUByte-w2LRezQ":I
    return p0
.end method

.method private static final toUInt-pVg5ArA(B)I
    .registers 3
    .param p0, "$this"  # B

    const/4 v0, 0x0

    .line 224
    .local v0, "$i$f$toUInt-pVg5ArA":I
    and-int/lit16 v1, p0, 0xff

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    return v1
.end method

.method private static final toULong-s-VKNKU(B)J
    .registers 6
    .param p0, "$this"  # B

    const/4 v0, 0x0

    .line 234
    .local v0, "$i$f$toULong-s-VKNKU":I
    int-to-long v1, p0

    const-wide/16 v3, 0xff

    and-long/2addr v1, v3

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    return-wide v1
.end method

.method private static final toUShort-Mh2AYeg(B)S
    .registers 3
    .param p0, "$this"  # B

    const/4 v0, 0x0

    .line 214
    .local v0, "$i$f$toUShort-Mh2AYeg":I
    int-to-short v1, p0

    and-int/lit16 v1, v1, 0xff

    int-to-short v1, v1

    invoke-static {v1}, Lkotlin/UShort;->constructor-impl(S)S

    move-result v1

    return v1
.end method

.method private static final xor-7apg3OU(BB)B
    .registers 4
    .param p0, "$this"  # B
    .param p1, "other"  # B

    const/4 v0, 0x0

    .line 156
    .local v0, "$i$f$xor-7apg3OU":I
    xor-int v1, p0, p1

    int-to-byte v1, v1

    invoke-static {v1}, Lkotlin/UByte;->constructor-impl(B)B

    move-result v1

    return v1
.end method


# virtual methods
.method public bridge synthetic compareTo(Ljava/lang/Object;)I
    .registers 2

    .line 15
    check-cast p1, Lkotlin/UByte;

    invoke-virtual {p1}, Lkotlin/UByte;->unbox-impl()B

    move-result p1

    invoke-direct {p0, p1}, Lkotlin/UByte;->compareTo-7apg3OU(B)I

    move-result p1

    return p1
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 3

    .line 1
    iget-byte v0, p0, Lkotlin/UByte;->data:B

    invoke-static {v0, p1}, Lkotlin/UByte;->equals-impl(BLjava/lang/Object;)Z

    move-result p1

    return p1
.end method

.method public hashCode()I
    .registers 2

    .line 1
    iget-byte v0, p0, Lkotlin/UByte;->data:B

    invoke-static {v0}, Lkotlin/UByte;->hashCode-impl(B)I

    move-result v0

    return v0
.end method

.method public toString()Ljava/lang/String;
    .registers 2

    .line 1
    iget-byte v0, p0, Lkotlin/UByte;->data:B

    invoke-static {v0}, Lkotlin/UByte;->toString-impl(B)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final synthetic unbox-impl()B
    .registers 2

    iget-byte v0, p0, Lkotlin/UByte;->data:B

    return v0
.end method
