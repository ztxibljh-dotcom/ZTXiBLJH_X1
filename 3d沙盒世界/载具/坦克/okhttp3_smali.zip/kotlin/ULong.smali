.class public final Lkotlin/ULong;
.super Ljava/lang/Object;
.source "ULong.kt"

# interfaces
.implements Ljava/lang/Comparable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lkotlin/ULong$Companion;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/lang/Comparable<",
        "Lkotlin/ULong;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    bv = {
        0x1,
        0x0,
        0x3
    }
    d1 = {
        "\u0000j\n\u0002\u0018\u0002\n\u0002\u0010\u000f\n\u0000\n\u0002\u0010\t\n\u0002\b\t\n\u0002\u0010\b\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\r\n\u0002\u0010\u000b\n\u0002\u0010\u0000\n\u0002\b\u0012\n\u0002\u0018\u0002\n\u0002\b\u0012\n\u0002\u0010\u0005\n\u0002\b\u0003\n\u0002\u0010\u0006\n\u0002\b\u0003\n\u0002\u0010\u0007\n\u0002\b\b\n\u0002\u0010\n\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u000e\b\u0087@\u0018\u0000 m2\b\u0012\u0004\u0012\u00020\u00000\u0001:\u0001mB\u0014\b\u0001\u0012\u0006\u0010\u0002\u001a\u00020\u0003ø\u0001\u0000¢\u0006\u0004\b\u0004\u0010\u0005J\u001b\u0010\b\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\u0000H\u0087\fø\u0001\u0000¢\u0006\u0004\b\n\u0010\u000bJ\u001b\u0010\f\u001a\u00020\r2\u0006\u0010\t\u001a\u00020\u000eH\u0087\nø\u0001\u0000¢\u0006\u0004\b\u000f\u0010\u0010J\u001b\u0010\f\u001a\u00020\r2\u0006\u0010\t\u001a\u00020\u0011H\u0087\nø\u0001\u0000¢\u0006\u0004\b\u0012\u0010\u0013J\u001b\u0010\f\u001a\u00020\r2\u0006\u0010\t\u001a\u00020\u0000H\u0097\nø\u0001\u0000¢\u0006\u0004\b\u0014\u0010\u0015J\u001b\u0010\f\u001a\u00020\r2\u0006\u0010\t\u001a\u00020\u0016H\u0087\nø\u0001\u0000¢\u0006\u0004\b\u0017\u0010\u0018J\u0016\u0010\u0019\u001a\u00020\u0000H\u0087\nø\u0001\u0000ø\u0001\u0001¢\u0006\u0004\b\u001a\u0010\u0005J\u001b\u0010\u001b\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\u000eH\u0087\nø\u0001\u0000¢\u0006\u0004\b\u001c\u0010\u001dJ\u001b\u0010\u001b\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\u0011H\u0087\nø\u0001\u0000¢\u0006\u0004\b\u001e\u0010\u001fJ\u001b\u0010\u001b\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\u0000H\u0087\nø\u0001\u0000¢\u0006\u0004\b \u0010\u000bJ\u001b\u0010\u001b\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\u0016H\u0087\nø\u0001\u0000¢\u0006\u0004\b!\u0010\"J\u0013\u0010#\u001a\u00020$2\b\u0010\t\u001a\u0004\u0018\u00010%HÖ\u0003J\t\u0010&\u001a\u00020\rHÖ\u0001J\u0016\u0010\'\u001a\u00020\u0000H\u0087\nø\u0001\u0000ø\u0001\u0001¢\u0006\u0004\b(\u0010\u0005J\u0016\u0010)\u001a\u00020\u0000H\u0087\bø\u0001\u0000ø\u0001\u0001¢\u0006\u0004\b*\u0010\u0005J\u001b\u0010+\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\u000eH\u0087\nø\u0001\u0000¢\u0006\u0004\b,\u0010\u001dJ\u001b\u0010+\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\u0011H\u0087\nø\u0001\u0000¢\u0006\u0004\b-\u0010\u001fJ\u001b\u0010+\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\u0000H\u0087\nø\u0001\u0000¢\u0006\u0004\b.\u0010\u000bJ\u001b\u0010+\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\u0016H\u0087\nø\u0001\u0000¢\u0006\u0004\b/\u0010\"J\u001b\u00100\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\u0000H\u0087\fø\u0001\u0000¢\u0006\u0004\b1\u0010\u000bJ\u001b\u00102\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\u000eH\u0087\nø\u0001\u0000¢\u0006\u0004\b3\u0010\u001dJ\u001b\u00102\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\u0011H\u0087\nø\u0001\u0000¢\u0006\u0004\b4\u0010\u001fJ\u001b\u00102\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\u0000H\u0087\nø\u0001\u0000¢\u0006\u0004\b5\u0010\u000bJ\u001b\u00102\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\u0016H\u0087\nø\u0001\u0000¢\u0006\u0004\b6\u0010\"J\u001b\u00107\u001a\u0002082\u0006\u0010\t\u001a\u00020\u0000H\u0087\nø\u0001\u0000¢\u0006\u0004\b9\u0010:J\u001b\u0010;\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\u000eH\u0087\nø\u0001\u0000¢\u0006\u0004\b<\u0010\u001dJ\u001b\u0010;\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\u0011H\u0087\nø\u0001\u0000¢\u0006\u0004\b=\u0010\u001fJ\u001b\u0010;\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\u0000H\u0087\nø\u0001\u0000¢\u0006\u0004\b>\u0010\u000bJ\u001b\u0010;\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\u0016H\u0087\nø\u0001\u0000¢\u0006\u0004\b?\u0010\"J\u001e\u0010@\u001a\u00020\u00002\u0006\u0010A\u001a\u00020\rH\u0087\fø\u0001\u0000ø\u0001\u0001¢\u0006\u0004\bB\u0010\u001fJ\u001e\u0010C\u001a\u00020\u00002\u0006\u0010A\u001a\u00020\rH\u0087\fø\u0001\u0000ø\u0001\u0001¢\u0006\u0004\bD\u0010\u001fJ\u001b\u0010E\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\u000eH\u0087\nø\u0001\u0000¢\u0006\u0004\bF\u0010\u001dJ\u001b\u0010E\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\u0011H\u0087\nø\u0001\u0000¢\u0006\u0004\bG\u0010\u001fJ\u001b\u0010E\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\u0000H\u0087\nø\u0001\u0000¢\u0006\u0004\bH\u0010\u000bJ\u001b\u0010E\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\u0016H\u0087\nø\u0001\u0000¢\u0006\u0004\bI\u0010\"J\u0010\u0010J\u001a\u00020KH\u0087\b¢\u0006\u0004\bL\u0010MJ\u0010\u0010N\u001a\u00020OH\u0087\b¢\u0006\u0004\bP\u0010QJ\u0010\u0010R\u001a\u00020SH\u0087\b¢\u0006\u0004\bT\u0010UJ\u0010\u0010V\u001a\u00020\rH\u0087\b¢\u0006\u0004\bW\u0010XJ\u0010\u0010Y\u001a\u00020\u0003H\u0087\b¢\u0006\u0004\bZ\u0010\u0005J\u0010\u0010[\u001a\u00020\\H\u0087\b¢\u0006\u0004\b]\u0010^J\u000f\u0010_\u001a\u00020`H\u0016¢\u0006\u0004\ba\u0010bJ\u0016\u0010c\u001a\u00020\u000eH\u0087\bø\u0001\u0000ø\u0001\u0001¢\u0006\u0004\bd\u0010MJ\u0016\u0010e\u001a\u00020\u0011H\u0087\bø\u0001\u0000ø\u0001\u0001¢\u0006\u0004\bf\u0010XJ\u0016\u0010g\u001a\u00020\u0000H\u0087\bø\u0001\u0000ø\u0001\u0001¢\u0006\u0004\bh\u0010\u0005J\u0016\u0010i\u001a\u00020\u0016H\u0087\bø\u0001\u0000ø\u0001\u0001¢\u0006\u0004\bj\u0010^J\u001b\u0010k\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\u0000H\u0087\fø\u0001\u0000¢\u0006\u0004\bl\u0010\u000bR\u0016\u0010\u0002\u001a\u00020\u00038\u0000X\u0081\u0004¢\u0006\b\n\u0000\u0012\u0004\b\u0006\u0010\u0007ø\u0001\u0000\u0082\u0002\b\n\u0002\b\u0019\n\u0002\b!¨\u0006n"
    }
    d2 = {
        "Lkotlin/ULong;",
        "",
        "data",
        "",
        "constructor-impl",
        "(J)J",
        "getData$annotations",
        "()V",
        "and",
        "other",
        "and-VKZWuLQ",
        "(JJ)J",
        "compareTo",
        "",
        "Lkotlin/UByte;",
        "compareTo-7apg3OU",
        "(JB)I",
        "Lkotlin/UInt;",
        "compareTo-WZ4Q5Ns",
        "(JI)I",
        "compareTo-VKZWuLQ",
        "(JJ)I",
        "Lkotlin/UShort;",
        "compareTo-xj2QHRw",
        "(JS)I",
        "dec",
        "dec-s-VKNKU",
        "div",
        "div-7apg3OU",
        "(JB)J",
        "div-WZ4Q5Ns",
        "(JI)J",
        "div-VKZWuLQ",
        "div-xj2QHRw",
        "(JS)J",
        "equals",
        "",
        "",
        "hashCode",
        "inc",
        "inc-s-VKNKU",
        "inv",
        "inv-s-VKNKU",
        "minus",
        "minus-7apg3OU",
        "minus-WZ4Q5Ns",
        "minus-VKZWuLQ",
        "minus-xj2QHRw",
        "or",
        "or-VKZWuLQ",
        "plus",
        "plus-7apg3OU",
        "plus-WZ4Q5Ns",
        "plus-VKZWuLQ",
        "plus-xj2QHRw",
        "rangeTo",
        "Lkotlin/ranges/ULongRange;",
        "rangeTo-VKZWuLQ",
        "(JJ)Lkotlin/ranges/ULongRange;",
        "rem",
        "rem-7apg3OU",
        "rem-WZ4Q5Ns",
        "rem-VKZWuLQ",
        "rem-xj2QHRw",
        "shl",
        "bitCount",
        "shl-s-VKNKU",
        "shr",
        "shr-s-VKNKU",
        "times",
        "times-7apg3OU",
        "times-WZ4Q5Ns",
        "times-VKZWuLQ",
        "times-xj2QHRw",
        "toByte",
        "",
        "toByte-impl",
        "(J)B",
        "toDouble",
        "",
        "toDouble-impl",
        "(J)D",
        "toFloat",
        "",
        "toFloat-impl",
        "(J)F",
        "toInt",
        "toInt-impl",
        "(J)I",
        "toLong",
        "toLong-impl",
        "toShort",
        "",
        "toShort-impl",
        "(J)S",
        "toString",
        "",
        "toString-impl",
        "(J)Ljava/lang/String;",
        "toUByte",
        "toUByte-w2LRezQ",
        "toUInt",
        "toUInt-pVg5ArA",
        "toULong",
        "toULong-s-VKNKU",
        "toUShort",
        "toUShort-Mh2AYeg",
        "xor",
        "xor-VKZWuLQ",
        "Companion",
        "kotlin-stdlib"
    }
    k = 0x1
    mv = {
        0x1,
        0x4,
        0x0
    }
.end annotation


# static fields
.field public static final Companion:Lkotlin/ULong$Companion;

.field public static final MAX_VALUE:J = -0x1L

.field public static final MIN_VALUE:J = 0x0L

.field public static final SIZE_BITS:I = 0x40

.field public static final SIZE_BYTES:I = 0x8


# instance fields
.field private final data:J


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lkotlin/ULong$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lkotlin/ULong$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lkotlin/ULong;->Companion:Lkotlin/ULong$Companion;

    return-void
.end method

.method private synthetic constructor <init>(J)V
    .registers 3
    .param p1, "data"  # J

    .line 15
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-wide p1, p0, Lkotlin/ULong;->data:J

    return-void
.end method

.method private static final and-VKZWuLQ(JJ)J
    .registers 7
    .param p0, "$this"  # J
    .param p2, "other"  # J

    const/4 v0, 0x0

    .line 156
    .local v0, "$i$f$and-VKZWuLQ":I
    and-long v1, p0, p2

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    return-wide v1
.end method

.method public static final synthetic box-impl(J)Lkotlin/ULong;
    .registers 3

    new-instance v0, Lkotlin/ULong;

    invoke-direct {v0, p0, p1}, Lkotlin/ULong;-><init>(J)V

    return-object v0
.end method

.method private static final compareTo-7apg3OU(JB)I
    .registers 8
    .param p0, "$this"  # J
    .param p2, "other"  # B

    const/4 v0, 0x0

    .line 45
    .local v0, "$i$f$compareTo-7apg3OU":I
    int-to-long v1, p2

    const-wide/16 v3, 0xff

    and-long/2addr v1, v3

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    invoke-static {p0, p1, v1, v2}, Lkotlin/UnsignedKt;->ulongCompare(JJ)I

    move-result v1

    return v1
.end method

.method private compareTo-VKZWuLQ(J)I
    .registers 5

    .line 1
    iget-wide v0, p0, Lkotlin/ULong;->data:J

    invoke-static {v0, v1, p1, p2}, Lkotlin/ULong;->compareTo-VKZWuLQ(JJ)I

    move-result p1

    return p1
.end method

.method private static compareTo-VKZWuLQ(JJ)I
    .registers 6
    .param p0, "$this"  # J
    .param p2, "other"  # J

    const/4 v0, 0x0

    .line 70
    .local v0, "$i$f$compareTo-VKZWuLQ":I
    invoke-static {p0, p1, p2, p3}, Lkotlin/UnsignedKt;->ulongCompare(JJ)I

    move-result v1

    return v1
.end method

.method private static final compareTo-WZ4Q5Ns(JI)I
    .registers 8
    .param p0, "$this"  # J
    .param p2, "other"  # I

    const/4 v0, 0x0

    .line 61
    .local v0, "$i$f$compareTo-WZ4Q5Ns":I
    int-to-long v1, p2

    const-wide v3, 0xffffffffL

    and-long/2addr v1, v3

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    invoke-static {p0, p1, v1, v2}, Lkotlin/UnsignedKt;->ulongCompare(JJ)I

    move-result v1

    return v1
.end method

.method private static final compareTo-xj2QHRw(JS)I
    .registers 8
    .param p0, "$this"  # J
    .param p2, "other"  # S

    const/4 v0, 0x0

    .line 53
    .local v0, "$i$f$compareTo-xj2QHRw":I
    int-to-long v1, p2

    const-wide/32 v3, 0xffff

    and-long/2addr v1, v3

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    invoke-static {p0, p1, v1, v2}, Lkotlin/UnsignedKt;->ulongCompare(JJ)I

    move-result v1

    return v1
.end method

.method public static constructor-impl(J)J
    .registers 2
    .param p0, "data"  # J

    .line 15
    return-wide p0
.end method

.method private static final dec-s-VKNKU(J)J
    .registers 5
    .param p0, "$this"  # J

    const/4 v0, 0x0

    .line 142
    .local v0, "$i$f$dec-s-VKNKU":I
    const-wide/16 v1, -0x1

    add-long/2addr v1, p0

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    return-wide v1
.end method

.method private static final div-7apg3OU(JB)J
    .registers 8
    .param p0, "$this"  # J
    .param p2, "other"  # B

    const/4 v0, 0x0

    .line 113
    .local v0, "$i$f$div-7apg3OU":I
    int-to-long v1, p2

    const-wide/16 v3, 0xff

    and-long/2addr v1, v3

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    invoke-static {p0, p1, v1, v2}, Lkotlin/UnsignedKt;->ulongDivide-eb3DHEI(JJ)J

    move-result-wide v1

    return-wide v1
.end method

.method private static final div-VKZWuLQ(JJ)J
    .registers 7
    .param p0, "$this"  # J
    .param p2, "other"  # J

    const/4 v0, 0x0

    .line 122
    .local v0, "$i$f$div-VKZWuLQ":I
    invoke-static {p0, p1, p2, p3}, Lkotlin/UnsignedKt;->ulongDivide-eb3DHEI(JJ)J

    move-result-wide v1

    return-wide v1
.end method

.method private static final div-WZ4Q5Ns(JI)J
    .registers 8
    .param p0, "$this"  # J
    .param p2, "other"  # I

    const/4 v0, 0x0

    .line 119
    .local v0, "$i$f$div-WZ4Q5Ns":I
    int-to-long v1, p2

    const-wide v3, 0xffffffffL

    and-long/2addr v1, v3

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    invoke-static {p0, p1, v1, v2}, Lkotlin/UnsignedKt;->ulongDivide-eb3DHEI(JJ)J

    move-result-wide v1

    return-wide v1
.end method

.method private static final div-xj2QHRw(JS)J
    .registers 8
    .param p0, "$this"  # J
    .param p2, "other"  # S

    const/4 v0, 0x0

    .line 116
    .local v0, "$i$f$div-xj2QHRw":I
    int-to-long v1, p2

    const-wide/32 v3, 0xffff

    and-long/2addr v1, v3

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    invoke-static {p0, p1, v1, v2}, Lkotlin/UnsignedKt;->ulongDivide-eb3DHEI(JJ)J

    move-result-wide v1

    return-wide v1
.end method

.method public static equals-impl(JLjava/lang/Object;)Z
    .registers 5

    instance-of v0, p2, Lkotlin/ULong;

    if-eqz v0, :cond_10

    check-cast p2, Lkotlin/ULong;

    invoke-virtual {p2}, Lkotlin/ULong;->unbox-impl()J

    move-result-wide v0

    cmp-long p2, p0, v0

    if-nez p2, :cond_10

    const/4 p0, 0x1

    return p0

    :cond_10
    const/4 p0, 0x0

    return p0
.end method

.method public static final equals-impl0(JJ)Z
    .registers 5

    cmp-long v0, p0, p2

    if-nez v0, :cond_6

    const/4 v0, 0x1

    goto :goto_7

    :cond_6
    const/4 v0, 0x0

    :goto_7
    return v0
.end method

.method public static synthetic getData$annotations()V
    .registers 0

    return-void
.end method

.method public static hashCode-impl(J)I
    .registers 4

    const/16 v0, 0x20

    ushr-long v0, p0, v0

    xor-long/2addr p0, v0

    long-to-int p1, p0

    return p1
.end method

.method private static final inc-s-VKNKU(J)J
    .registers 5
    .param p0, "$this"  # J

    const/4 v0, 0x0

    .line 139
    .local v0, "$i$f$inc-s-VKNKU":I
    const-wide/16 v1, 0x1

    add-long/2addr v1, p0

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    return-wide v1
.end method

.method private static final inv-s-VKNKU(J)J
    .registers 5
    .param p0, "$this"  # J

    const/4 v0, 0x0

    .line 165
    .local v0, "$i$f$inv-s-VKNKU":I
    not-long v1, p0

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    return-wide v1
.end method

.method private static final minus-7apg3OU(JB)J
    .registers 8
    .param p0, "$this"  # J
    .param p2, "other"  # B

    const/4 v0, 0x0

    .line 87
    .local v0, "$i$f$minus-7apg3OU":I
    int-to-long v1, p2

    const-wide/16 v3, 0xff

    and-long/2addr v1, v3

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    sub-long v1, p0, v1

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    return-wide v1
.end method

.method private static final minus-VKZWuLQ(JJ)J
    .registers 7
    .param p0, "$this"  # J
    .param p2, "other"  # J

    const/4 v0, 0x0

    .line 96
    .local v0, "$i$f$minus-VKZWuLQ":I
    sub-long v1, p0, p2

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    return-wide v1
.end method

.method private static final minus-WZ4Q5Ns(JI)J
    .registers 8
    .param p0, "$this"  # J
    .param p2, "other"  # I

    const/4 v0, 0x0

    .line 93
    .local v0, "$i$f$minus-WZ4Q5Ns":I
    int-to-long v1, p2

    const-wide v3, 0xffffffffL

    and-long/2addr v1, v3

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    sub-long v1, p0, v1

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    return-wide v1
.end method

.method private static final minus-xj2QHRw(JS)J
    .registers 8
    .param p0, "$this"  # J
    .param p2, "other"  # S

    const/4 v0, 0x0

    .line 90
    .local v0, "$i$f$minus-xj2QHRw":I
    int-to-long v1, p2

    const-wide/32 v3, 0xffff

    and-long/2addr v1, v3

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    sub-long v1, p0, v1

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    return-wide v1
.end method

.method private static final or-VKZWuLQ(JJ)J
    .registers 7
    .param p0, "$this"  # J
    .param p2, "other"  # J

    const/4 v0, 0x0

    .line 159
    .local v0, "$i$f$or-VKZWuLQ":I
    or-long v1, p0, p2

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    return-wide v1
.end method

.method private static final plus-7apg3OU(JB)J
    .registers 8
    .param p0, "$this"  # J
    .param p2, "other"  # B

    const/4 v0, 0x0

    .line 74
    .local v0, "$i$f$plus-7apg3OU":I
    int-to-long v1, p2

    const-wide/16 v3, 0xff

    and-long/2addr v1, v3

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    add-long/2addr v1, p0

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    return-wide v1
.end method

.method private static final plus-VKZWuLQ(JJ)J
    .registers 7
    .param p0, "$this"  # J
    .param p2, "other"  # J

    const/4 v0, 0x0

    .line 83
    .local v0, "$i$f$plus-VKZWuLQ":I
    add-long v1, p0, p2

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    return-wide v1
.end method

.method private static final plus-WZ4Q5Ns(JI)J
    .registers 8
    .param p0, "$this"  # J
    .param p2, "other"  # I

    const/4 v0, 0x0

    .line 80
    .local v0, "$i$f$plus-WZ4Q5Ns":I
    int-to-long v1, p2

    const-wide v3, 0xffffffffL

    and-long/2addr v1, v3

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    add-long/2addr v1, p0

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    return-wide v1
.end method

.method private static final plus-xj2QHRw(JS)J
    .registers 8
    .param p0, "$this"  # J
    .param p2, "other"  # S

    const/4 v0, 0x0

    .line 77
    .local v0, "$i$f$plus-xj2QHRw":I
    int-to-long v1, p2

    const-wide/32 v3, 0xffff

    and-long/2addr v1, v3

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    add-long/2addr v1, p0

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    return-wide v1
.end method

.method private static final rangeTo-VKZWuLQ(JJ)Lkotlin/ranges/ULongRange;
    .registers 12
    .param p0, "$this"  # J
    .param p2, "other"  # J

    const/4 v0, 0x0

    .line 146
    .local v0, "$i$f$rangeTo-VKZWuLQ":I
    new-instance v7, Lkotlin/ranges/ULongRange;

    const/4 v6, 0x0

    move-object v1, v7

    move-wide v2, p0

    move-wide v4, p2

    invoke-direct/range {v1 .. v6}, Lkotlin/ranges/ULongRange;-><init>(JJLkotlin/jvm/internal/DefaultConstructorMarker;)V

    return-object v7
.end method

.method private static final rem-7apg3OU(JB)J
    .registers 8
    .param p0, "$this"  # J
    .param p2, "other"  # B

    const/4 v0, 0x0

    .line 126
    .local v0, "$i$f$rem-7apg3OU":I
    int-to-long v1, p2

    const-wide/16 v3, 0xff

    and-long/2addr v1, v3

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    invoke-static {p0, p1, v1, v2}, Lkotlin/UnsignedKt;->ulongRemainder-eb3DHEI(JJ)J

    move-result-wide v1

    return-wide v1
.end method

.method private static final rem-VKZWuLQ(JJ)J
    .registers 7
    .param p0, "$this"  # J
    .param p2, "other"  # J

    const/4 v0, 0x0

    .line 135
    .local v0, "$i$f$rem-VKZWuLQ":I
    invoke-static {p0, p1, p2, p3}, Lkotlin/UnsignedKt;->ulongRemainder-eb3DHEI(JJ)J

    move-result-wide v1

    return-wide v1
.end method

.method private static final rem-WZ4Q5Ns(JI)J
    .registers 8
    .param p0, "$this"  # J
    .param p2, "other"  # I

    const/4 v0, 0x0

    .line 132
    .local v0, "$i$f$rem-WZ4Q5Ns":I
    int-to-long v1, p2

    const-wide v3, 0xffffffffL

    and-long/2addr v1, v3

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    invoke-static {p0, p1, v1, v2}, Lkotlin/UnsignedKt;->ulongRemainder-eb3DHEI(JJ)J

    move-result-wide v1

    return-wide v1
.end method

.method private static final rem-xj2QHRw(JS)J
    .registers 8
    .param p0, "$this"  # J
    .param p2, "other"  # S

    const/4 v0, 0x0

    .line 129
    .local v0, "$i$f$rem-xj2QHRw":I
    int-to-long v1, p2

    const-wide/32 v3, 0xffff

    and-long/2addr v1, v3

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    invoke-static {p0, p1, v1, v2}, Lkotlin/UnsignedKt;->ulongRemainder-eb3DHEI(JJ)J

    move-result-wide v1

    return-wide v1
.end method

.method private static final shl-s-VKNKU(JI)J
    .registers 6
    .param p0, "$this"  # J
    .param p2, "bitCount"  # I

    const/4 v0, 0x0

    .line 150
    .local v0, "$i$f$shl-s-VKNKU":I
    shl-long v1, p0, p2

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    return-wide v1
.end method

.method private static final shr-s-VKNKU(JI)J
    .registers 6
    .param p0, "$this"  # J
    .param p2, "bitCount"  # I

    const/4 v0, 0x0

    .line 153
    .local v0, "$i$f$shr-s-VKNKU":I
    ushr-long v1, p0, p2

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    return-wide v1
.end method

.method private static final times-7apg3OU(JB)J
    .registers 8
    .param p0, "$this"  # J
    .param p2, "other"  # B

    const/4 v0, 0x0

    .line 100
    .local v0, "$i$f$times-7apg3OU":I
    int-to-long v1, p2

    const-wide/16 v3, 0xff

    and-long/2addr v1, v3

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    mul-long v1, v1, p0

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    return-wide v1
.end method

.method private static final times-VKZWuLQ(JJ)J
    .registers 7
    .param p0, "$this"  # J
    .param p2, "other"  # J

    const/4 v0, 0x0

    .line 109
    .local v0, "$i$f$times-VKZWuLQ":I
    mul-long v1, p0, p2

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    return-wide v1
.end method

.method private static final times-WZ4Q5Ns(JI)J
    .registers 8
    .param p0, "$this"  # J
    .param p2, "other"  # I

    const/4 v0, 0x0

    .line 106
    .local v0, "$i$f$times-WZ4Q5Ns":I
    int-to-long v1, p2

    const-wide v3, 0xffffffffL

    and-long/2addr v1, v3

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    mul-long v1, v1, p0

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    return-wide v1
.end method

.method private static final times-xj2QHRw(JS)J
    .registers 8
    .param p0, "$this"  # J
    .param p2, "other"  # S

    const/4 v0, 0x0

    .line 103
    .local v0, "$i$f$times-xj2QHRw":I
    int-to-long v1, p2

    const-wide/32 v3, 0xffff

    and-long/2addr v1, v3

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    mul-long v1, v1, p0

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    return-wide v1
.end method

.method private static final toByte-impl(J)B
    .registers 4
    .param p0, "$this"  # J

    const/4 v0, 0x0

    .line 177
    .local v0, "$i$f$toByte":I
    long-to-int v1, p0

    int-to-byte v1, v1

    return v1
.end method

.method private static final toDouble-impl(J)D
    .registers 5
    .param p0, "$this"  # J

    const/4 v0, 0x0

    .line 262
    .local v0, "$i$f$toDouble":I
    invoke-static {p0, p1}, Lkotlin/UnsignedKt;->ulongToDouble(J)D

    move-result-wide v1

    return-wide v1
.end method

.method private static final toFloat-impl(J)F
    .registers 5
    .param p0, "$this"  # J

    const/4 v0, 0x0

    .line 253
    .local v0, "$i$f$toFloat":I
    invoke-static {p0, p1}, Lkotlin/UnsignedKt;->ulongToDouble(J)D

    move-result-wide v1

    double-to-float v1, v1

    return v1
.end method

.method private static final toInt-impl(J)I
    .registers 4
    .param p0, "$this"  # J

    const/4 v0, 0x0

    .line 199
    .local v0, "$i$f$toInt":I
    long-to-int v1, p0

    return v1
.end method

.method private static final toLong-impl(J)J
    .registers 3
    .param p0, "$this"  # J

    const/4 v0, 0x0

    .line 209
    .local v0, "$i$f$toLong":I
    return-wide p0
.end method

.method private static final toShort-impl(J)S
    .registers 4
    .param p0, "$this"  # J

    const/4 v0, 0x0

    .line 188
    .local v0, "$i$f$toShort":I
    long-to-int v1, p0

    int-to-short v1, v1

    return v1
.end method

.method public static toString-impl(J)Ljava/lang/String;
    .registers 3
    .param p0, "$this"  # J

    .line 264
    invoke-static {p0, p1}, Lkotlin/UnsignedKt;->ulongToString(J)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static final toUByte-w2LRezQ(J)B
    .registers 4
    .param p0, "$this"  # J

    const/4 v0, 0x0

    .line 220
    .local v0, "$i$f$toUByte-w2LRezQ":I
    long-to-int v1, p0

    int-to-byte v1, v1

    invoke-static {v1}, Lkotlin/UByte;->constructor-impl(B)B

    move-result v1

    return v1
.end method

.method private static final toUInt-pVg5ArA(J)I
    .registers 4
    .param p0, "$this"  # J

    const/4 v0, 0x0

    .line 240
    .local v0, "$i$f$toUInt-pVg5ArA":I
    long-to-int v1, p0

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    return v1
.end method

.method private static final toULong-s-VKNKU(J)J
    .registers 3
    .param p0, "$this"  # J

    const/4 v0, 0x0

    .line 243
    .local v0, "$i$f$toULong-s-VKNKU":I
    return-wide p0
.end method

.method private static final toUShort-Mh2AYeg(J)S
    .registers 4
    .param p0, "$this"  # J

    const/4 v0, 0x0

    .line 230
    .local v0, "$i$f$toUShort-Mh2AYeg":I
    long-to-int v1, p0

    int-to-short v1, v1

    invoke-static {v1}, Lkotlin/UShort;->constructor-impl(S)S

    move-result v1

    return v1
.end method

.method private static final xor-VKZWuLQ(JJ)J
    .registers 7
    .param p0, "$this"  # J
    .param p2, "other"  # J

    const/4 v0, 0x0

    .line 162
    .local v0, "$i$f$xor-VKZWuLQ":I
    xor-long v1, p0, p2

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    return-wide v1
.end method


# virtual methods
.method public bridge synthetic compareTo(Ljava/lang/Object;)I
    .registers 4

    .line 15
    check-cast p1, Lkotlin/ULong;

    invoke-virtual {p1}, Lkotlin/ULong;->unbox-impl()J

    move-result-wide v0

    invoke-direct {p0, v0, v1}, Lkotlin/ULong;->compareTo-VKZWuLQ(J)I

    move-result p1

    return p1
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 4

    .line 1
    iget-wide v0, p0, Lkotlin/ULong;->data:J

    invoke-static {v0, v1, p1}, Lkotlin/ULong;->equals-impl(JLjava/lang/Object;)Z

    move-result p1

    return p1
.end method

.method public hashCode()I
    .registers 3

    .line 1
    iget-wide v0, p0, Lkotlin/ULong;->data:J

    invoke-static {v0, v1}, Lkotlin/ULong;->hashCode-impl(J)I

    move-result v0

    return v0
.end method

.method public toString()Ljava/lang/String;
    .registers 3

    .line 1
    iget-wide v0, p0, Lkotlin/ULong;->data:J

    invoke-static {v0, v1}, Lkotlin/ULong;->toString-impl(J)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final synthetic unbox-impl()J
    .registers 3

    iget-wide v0, p0, Lkotlin/ULong;->data:J

    return-wide v0
.end method
