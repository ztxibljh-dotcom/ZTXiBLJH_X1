.class public final Lkotlin/UShort;
.super Ljava/lang/Object;
.source "UShort.kt"

# interfaces
.implements Ljava/lang/Comparable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lkotlin/UShort$Companion;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/lang/Comparable<",
        "Lkotlin/UShort;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    bv = {
        0x1,
        0x0,
        0x3
    }
    d1 = {
        "\u0000j\n\u0002\u0018\u0002\n\u0002\u0010\u000f\n\u0000\n\u0002\u0010\n\n\u0002\b\t\n\u0002\u0010\b\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\r\n\u0002\u0010\u000b\n\u0002\u0010\u0000\n\u0002\b\u0012\n\u0002\u0018\u0002\n\u0002\b\r\n\u0002\u0010\u0005\n\u0002\b\u0003\n\u0002\u0010\u0006\n\u0002\b\u0003\n\u0002\u0010\u0007\n\u0002\b\u0006\n\u0002\u0010\t\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0002\b\u000e\b\u0087@\u0018\u0000 f2\b\u0012\u0004\u0012\u00020\u00000\u0001:\u0001fB\u0014\b\u0001\u0012\u0006\u0010\u0002\u001a\u00020\u0003ø\u0001\u0000¢\u0006\u0004\b\u0004\u0010\u0005J\u001b\u0010\b\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\u0000H\u0087\fø\u0001\u0000¢\u0006\u0004\b\n\u0010\u000bJ\u001b\u0010\f\u001a\u00020\r2\u0006\u0010\t\u001a\u00020\u000eH\u0087\nø\u0001\u0000¢\u0006\u0004\b\u000f\u0010\u0010J\u001b\u0010\f\u001a\u00020\r2\u0006\u0010\t\u001a\u00020\u0011H\u0087\nø\u0001\u0000¢\u0006\u0004\b\u0012\u0010\u0013J\u001b\u0010\f\u001a\u00020\r2\u0006\u0010\t\u001a\u00020\u0014H\u0087\nø\u0001\u0000¢\u0006\u0004\b\u0015\u0010\u0016J\u001b\u0010\f\u001a\u00020\r2\u0006\u0010\t\u001a\u00020\u0000H\u0097\nø\u0001\u0000¢\u0006\u0004\b\u0017\u0010\u0018J\u0016\u0010\u0019\u001a\u00020\u0000H\u0087\nø\u0001\u0000ø\u0001\u0001¢\u0006\u0004\b\u001a\u0010\u0005J\u001b\u0010\u001b\u001a\u00020\u00112\u0006\u0010\t\u001a\u00020\u000eH\u0087\nø\u0001\u0000¢\u0006\u0004\b\u001c\u0010\u0010J\u001b\u0010\u001b\u001a\u00020\u00112\u0006\u0010\t\u001a\u00020\u0011H\u0087\nø\u0001\u0000¢\u0006\u0004\b\u001d\u0010\u0013J\u001b\u0010\u001b\u001a\u00020\u00142\u0006\u0010\t\u001a\u00020\u0014H\u0087\nø\u0001\u0000¢\u0006\u0004\b\u001e\u0010\u001fJ\u001b\u0010\u001b\u001a\u00020\u00112\u0006\u0010\t\u001a\u00020\u0000H\u0087\nø\u0001\u0000¢\u0006\u0004\b \u0010\u0018J\u0013\u0010!\u001a\u00020\"2\b\u0010\t\u001a\u0004\u0018\u00010#HÖ\u0003J\t\u0010$\u001a\u00020\rHÖ\u0001J\u0016\u0010%\u001a\u00020\u0000H\u0087\nø\u0001\u0000ø\u0001\u0001¢\u0006\u0004\b&\u0010\u0005J\u0016\u0010\'\u001a\u00020\u0000H\u0087\bø\u0001\u0000ø\u0001\u0001¢\u0006\u0004\b(\u0010\u0005J\u001b\u0010)\u001a\u00020\u00112\u0006\u0010\t\u001a\u00020\u000eH\u0087\nø\u0001\u0000¢\u0006\u0004\b*\u0010\u0010J\u001b\u0010)\u001a\u00020\u00112\u0006\u0010\t\u001a\u00020\u0011H\u0087\nø\u0001\u0000¢\u0006\u0004\b+\u0010\u0013J\u001b\u0010)\u001a\u00020\u00142\u0006\u0010\t\u001a\u00020\u0014H\u0087\nø\u0001\u0000¢\u0006\u0004\b,\u0010\u001fJ\u001b\u0010)\u001a\u00020\u00112\u0006\u0010\t\u001a\u00020\u0000H\u0087\nø\u0001\u0000¢\u0006\u0004\b-\u0010\u0018J\u001b\u0010.\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\u0000H\u0087\fø\u0001\u0000¢\u0006\u0004\b/\u0010\u000bJ\u001b\u00100\u001a\u00020\u00112\u0006\u0010\t\u001a\u00020\u000eH\u0087\nø\u0001\u0000¢\u0006\u0004\b1\u0010\u0010J\u001b\u00100\u001a\u00020\u00112\u0006\u0010\t\u001a\u00020\u0011H\u0087\nø\u0001\u0000¢\u0006\u0004\b2\u0010\u0013J\u001b\u00100\u001a\u00020\u00142\u0006\u0010\t\u001a\u00020\u0014H\u0087\nø\u0001\u0000¢\u0006\u0004\b3\u0010\u001fJ\u001b\u00100\u001a\u00020\u00112\u0006\u0010\t\u001a\u00020\u0000H\u0087\nø\u0001\u0000¢\u0006\u0004\b4\u0010\u0018J\u001b\u00105\u001a\u0002062\u0006\u0010\t\u001a\u00020\u0000H\u0087\nø\u0001\u0000¢\u0006\u0004\b7\u00108J\u001b\u00109\u001a\u00020\u00112\u0006\u0010\t\u001a\u00020\u000eH\u0087\nø\u0001\u0000¢\u0006\u0004\b:\u0010\u0010J\u001b\u00109\u001a\u00020\u00112\u0006\u0010\t\u001a\u00020\u0011H\u0087\nø\u0001\u0000¢\u0006\u0004\b;\u0010\u0013J\u001b\u00109\u001a\u00020\u00142\u0006\u0010\t\u001a\u00020\u0014H\u0087\nø\u0001\u0000¢\u0006\u0004\b<\u0010\u001fJ\u001b\u00109\u001a\u00020\u00112\u0006\u0010\t\u001a\u00020\u0000H\u0087\nø\u0001\u0000¢\u0006\u0004\b=\u0010\u0018J\u001b\u0010>\u001a\u00020\u00112\u0006\u0010\t\u001a\u00020\u000eH\u0087\nø\u0001\u0000¢\u0006\u0004\b?\u0010\u0010J\u001b\u0010>\u001a\u00020\u00112\u0006\u0010\t\u001a\u00020\u0011H\u0087\nø\u0001\u0000¢\u0006\u0004\b@\u0010\u0013J\u001b\u0010>\u001a\u00020\u00142\u0006\u0010\t\u001a\u00020\u0014H\u0087\nø\u0001\u0000¢\u0006\u0004\bA\u0010\u001fJ\u001b\u0010>\u001a\u00020\u00112\u0006\u0010\t\u001a\u00020\u0000H\u0087\nø\u0001\u0000¢\u0006\u0004\bB\u0010\u0018J\u0010\u0010C\u001a\u00020DH\u0087\b¢\u0006\u0004\bE\u0010FJ\u0010\u0010G\u001a\u00020HH\u0087\b¢\u0006\u0004\bI\u0010JJ\u0010\u0010K\u001a\u00020LH\u0087\b¢\u0006\u0004\bM\u0010NJ\u0010\u0010O\u001a\u00020\rH\u0087\b¢\u0006\u0004\bP\u0010QJ\u0010\u0010R\u001a\u00020SH\u0087\b¢\u0006\u0004\bT\u0010UJ\u0010\u0010V\u001a\u00020\u0003H\u0087\b¢\u0006\u0004\bW\u0010\u0005J\u000f\u0010X\u001a\u00020YH\u0016¢\u0006\u0004\bZ\u0010[J\u0016\u0010\\\u001a\u00020\u000eH\u0087\bø\u0001\u0000ø\u0001\u0001¢\u0006\u0004\b]\u0010FJ\u0016\u0010^\u001a\u00020\u0011H\u0087\bø\u0001\u0000ø\u0001\u0001¢\u0006\u0004\b_\u0010QJ\u0016\u0010`\u001a\u00020\u0014H\u0087\bø\u0001\u0000ø\u0001\u0001¢\u0006\u0004\ba\u0010UJ\u0016\u0010b\u001a\u00020\u0000H\u0087\bø\u0001\u0000ø\u0001\u0001¢\u0006\u0004\bc\u0010\u0005J\u001b\u0010d\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\u0000H\u0087\fø\u0001\u0000¢\u0006\u0004\be\u0010\u000bR\u0016\u0010\u0002\u001a\u00020\u00038\u0000X\u0081\u0004¢\u0006\b\n\u0000\u0012\u0004\b\u0006\u0010\u0007ø\u0001\u0000\u0082\u0002\b\n\u0002\b\u0019\n\u0002\b!¨\u0006g"
    }
    d2 = {
        "Lkotlin/UShort;",
        "",
        "data",
        "",
        "constructor-impl",
        "(S)S",
        "getData$annotations",
        "()V",
        "and",
        "other",
        "and-xj2QHRw",
        "(SS)S",
        "compareTo",
        "",
        "Lkotlin/UByte;",
        "compareTo-7apg3OU",
        "(SB)I",
        "Lkotlin/UInt;",
        "compareTo-WZ4Q5Ns",
        "(SI)I",
        "Lkotlin/ULong;",
        "compareTo-VKZWuLQ",
        "(SJ)I",
        "compareTo-xj2QHRw",
        "(SS)I",
        "dec",
        "dec-Mh2AYeg",
        "div",
        "div-7apg3OU",
        "div-WZ4Q5Ns",
        "div-VKZWuLQ",
        "(SJ)J",
        "div-xj2QHRw",
        "equals",
        "",
        "",
        "hashCode",
        "inc",
        "inc-Mh2AYeg",
        "inv",
        "inv-Mh2AYeg",
        "minus",
        "minus-7apg3OU",
        "minus-WZ4Q5Ns",
        "minus-VKZWuLQ",
        "minus-xj2QHRw",
        "or",
        "or-xj2QHRw",
        "plus",
        "plus-7apg3OU",
        "plus-WZ4Q5Ns",
        "plus-VKZWuLQ",
        "plus-xj2QHRw",
        "rangeTo",
        "Lkotlin/ranges/UIntRange;",
        "rangeTo-xj2QHRw",
        "(SS)Lkotlin/ranges/UIntRange;",
        "rem",
        "rem-7apg3OU",
        "rem-WZ4Q5Ns",
        "rem-VKZWuLQ",
        "rem-xj2QHRw",
        "times",
        "times-7apg3OU",
        "times-WZ4Q5Ns",
        "times-VKZWuLQ",
        "times-xj2QHRw",
        "toByte",
        "",
        "toByte-impl",
        "(S)B",
        "toDouble",
        "",
        "toDouble-impl",
        "(S)D",
        "toFloat",
        "",
        "toFloat-impl",
        "(S)F",
        "toInt",
        "toInt-impl",
        "(S)I",
        "toLong",
        "",
        "toLong-impl",
        "(S)J",
        "toShort",
        "toShort-impl",
        "toString",
        "",
        "toString-impl",
        "(S)Ljava/lang/String;",
        "toUByte",
        "toUByte-w2LRezQ",
        "toUInt",
        "toUInt-pVg5ArA",
        "toULong",
        "toULong-s-VKNKU",
        "toUShort",
        "toUShort-Mh2AYeg",
        "xor",
        "xor-xj2QHRw",
        "Companion",
        "kotlin-stdlib"
    }
    k = 0x1
    mv = {
        0x1,
        0x4,
        0x0
    }
.end annotation


# static fields
.field public static final Companion:Lkotlin/UShort$Companion;

.field public static final MAX_VALUE:S = -0x1s

.field public static final MIN_VALUE:S = 0x0s

.field public static final SIZE_BITS:I = 0x10

.field public static final SIZE_BYTES:I = 0x2


# instance fields
.field private final data:S


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lkotlin/UShort$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lkotlin/UShort$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lkotlin/UShort;->Companion:Lkotlin/UShort$Companion;

    return-void
.end method

.method private synthetic constructor <init>(S)V
    .registers 2
    .param p1, "data"  # S

    .line 15
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-short p1, p0, Lkotlin/UShort;->data:S

    return-void
.end method

.method private static final and-xj2QHRw(SS)S
    .registers 4
    .param p0, "$this"  # S
    .param p1, "other"  # S

    const/4 v0, 0x0

    .line 150
    .local v0, "$i$f$and-xj2QHRw":I
    and-int v1, p0, p1

    int-to-short v1, v1

    invoke-static {v1}, Lkotlin/UShort;->constructor-impl(S)S

    move-result v1

    return v1
.end method

.method public static final synthetic box-impl(S)Lkotlin/UShort;
    .registers 2

    new-instance v0, Lkotlin/UShort;

    invoke-direct {v0, p0}, Lkotlin/UShort;-><init>(S)V

    return-object v0
.end method

.method private static final compareTo-7apg3OU(SB)I
    .registers 5
    .param p0, "$this"  # S
    .param p1, "other"  # B

    const/4 v0, 0x0

    .line 45
    .local v0, "$i$f$compareTo-7apg3OU":I
    const v1, 0xffff

    and-int/2addr v1, p0

    and-int/lit16 v2, p1, 0xff

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->compare(II)I

    move-result v1

    return v1
.end method

.method private static final compareTo-VKZWuLQ(SJ)I
    .registers 8
    .param p0, "$this"  # S
    .param p1, "other"  # J

    const/4 v0, 0x0

    .line 70
    .local v0, "$i$f$compareTo-VKZWuLQ":I
    int-to-long v1, p0

    const-wide/32 v3, 0xffff

    and-long/2addr v1, v3

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    invoke-static {v1, v2, p1, p2}, Lkotlin/UnsignedKt;->ulongCompare(JJ)I

    move-result v1

    return v1
.end method

.method private static final compareTo-WZ4Q5Ns(SI)I
    .registers 4
    .param p0, "$this"  # S
    .param p1, "other"  # I

    const/4 v0, 0x0

    .line 62
    .local v0, "$i$f$compareTo-WZ4Q5Ns":I
    const v1, 0xffff

    and-int/2addr v1, p0

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    invoke-static {v1, p1}, Lkotlin/UnsignedKt;->uintCompare(II)I

    move-result v1

    return v1
.end method

.method private compareTo-xj2QHRw(S)I
    .registers 3

    .line 1
    iget-short v0, p0, Lkotlin/UShort;->data:S

    invoke-static {v0, p1}, Lkotlin/UShort;->compareTo-xj2QHRw(SS)I

    move-result p1

    return p1
.end method

.method private static compareTo-xj2QHRw(SS)I
    .registers 5
    .param p0, "$this"  # S
    .param p1, "other"  # S

    const/4 v0, 0x0

    .line 54
    .local v0, "$i$f$compareTo-xj2QHRw":I
    const v1, 0xffff

    and-int v2, p0, v1

    and-int/2addr v1, p1

    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->compare(II)I

    move-result v1

    return v1
.end method

.method public static constructor-impl(S)S
    .registers 1
    .param p0, "data"  # S

    .line 15
    return p0
.end method

.method private static final dec-Mh2AYeg(S)S
    .registers 3
    .param p0, "$this"  # S

    const/4 v0, 0x0

    .line 142
    .local v0, "$i$f$dec-Mh2AYeg":I
    add-int/lit8 v1, p0, -0x1

    int-to-short v1, v1

    invoke-static {v1}, Lkotlin/UShort;->constructor-impl(S)S

    move-result v1

    return v1
.end method

.method private static final div-7apg3OU(SB)I
    .registers 5
    .param p0, "$this"  # S
    .param p1, "other"  # B

    const/4 v0, 0x0

    .line 113
    .local v0, "$i$f$div-7apg3OU":I
    const v1, 0xffff

    and-int/2addr v1, p0

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    and-int/lit16 v2, p1, 0xff

    invoke-static {v2}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v2

    invoke-static {v1, v2}, Lkotlin/UnsignedKt;->uintDivide-J1ME1BU(II)I

    move-result v1

    return v1
.end method

.method private static final div-VKZWuLQ(SJ)J
    .registers 8
    .param p0, "$this"  # S
    .param p1, "other"  # J

    const/4 v0, 0x0

    .line 122
    .local v0, "$i$f$div-VKZWuLQ":I
    int-to-long v1, p0

    const-wide/32 v3, 0xffff

    and-long/2addr v1, v3

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    invoke-static {v1, v2, p1, p2}, Lkotlin/UnsignedKt;->ulongDivide-eb3DHEI(JJ)J

    move-result-wide v1

    return-wide v1
.end method

.method private static final div-WZ4Q5Ns(SI)I
    .registers 4
    .param p0, "$this"  # S
    .param p1, "other"  # I

    const/4 v0, 0x0

    .line 119
    .local v0, "$i$f$div-WZ4Q5Ns":I
    const v1, 0xffff

    and-int/2addr v1, p0

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    invoke-static {v1, p1}, Lkotlin/UnsignedKt;->uintDivide-J1ME1BU(II)I

    move-result v1

    return v1
.end method

.method private static final div-xj2QHRw(SS)I
    .registers 5
    .param p0, "$this"  # S
    .param p1, "other"  # S

    const/4 v0, 0x0

    .line 116
    .local v0, "$i$f$div-xj2QHRw":I
    const v1, 0xffff

    and-int v2, p0, v1

    invoke-static {v2}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v2

    and-int/2addr v1, p1

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    invoke-static {v2, v1}, Lkotlin/UnsignedKt;->uintDivide-J1ME1BU(II)I

    move-result v1

    return v1
.end method

.method public static equals-impl(SLjava/lang/Object;)Z
    .registers 3

    instance-of v0, p1, Lkotlin/UShort;

    if-eqz v0, :cond_e

    check-cast p1, Lkotlin/UShort;

    invoke-virtual {p1}, Lkotlin/UShort;->unbox-impl()S

    move-result p1

    if-ne p0, p1, :cond_e

    const/4 p0, 0x1

    return p0

    :cond_e
    const/4 p0, 0x0

    return p0
.end method

.method public static final equals-impl0(SS)Z
    .registers 3

    if-ne p0, p1, :cond_4

    const/4 v0, 0x1

    goto :goto_5

    :cond_4
    const/4 v0, 0x0

    :goto_5
    return v0
.end method

.method public static synthetic getData$annotations()V
    .registers 0

    return-void
.end method

.method public static hashCode-impl(S)I
    .registers 1

    return p0
.end method

.method private static final inc-Mh2AYeg(S)S
    .registers 3
    .param p0, "$this"  # S

    const/4 v0, 0x0

    .line 139
    .local v0, "$i$f$inc-Mh2AYeg":I
    add-int/lit8 v1, p0, 0x1

    int-to-short v1, v1

    invoke-static {v1}, Lkotlin/UShort;->constructor-impl(S)S

    move-result v1

    return v1
.end method

.method private static final inv-Mh2AYeg(S)S
    .registers 3
    .param p0, "$this"  # S

    const/4 v0, 0x0

    .line 159
    .local v0, "$i$f$inv-Mh2AYeg":I
    not-int v1, p0

    int-to-short v1, v1

    invoke-static {v1}, Lkotlin/UShort;->constructor-impl(S)S

    move-result v1

    return v1
.end method

.method private static final minus-7apg3OU(SB)I
    .registers 5
    .param p0, "$this"  # S
    .param p1, "other"  # B

    const/4 v0, 0x0

    .line 87
    .local v0, "$i$f$minus-7apg3OU":I
    const v1, 0xffff

    and-int/2addr v1, p0

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    and-int/lit16 v2, p1, 0xff

    invoke-static {v2}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v2

    sub-int/2addr v1, v2

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    return v1
.end method

.method private static final minus-VKZWuLQ(SJ)J
    .registers 8
    .param p0, "$this"  # S
    .param p1, "other"  # J

    const/4 v0, 0x0

    .line 96
    .local v0, "$i$f$minus-VKZWuLQ":I
    int-to-long v1, p0

    const-wide/32 v3, 0xffff

    and-long/2addr v1, v3

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    sub-long/2addr v1, p1

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    return-wide v1
.end method

.method private static final minus-WZ4Q5Ns(SI)I
    .registers 4
    .param p0, "$this"  # S
    .param p1, "other"  # I

    const/4 v0, 0x0

    .line 93
    .local v0, "$i$f$minus-WZ4Q5Ns":I
    const v1, 0xffff

    and-int/2addr v1, p0

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    sub-int/2addr v1, p1

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    return v1
.end method

.method private static final minus-xj2QHRw(SS)I
    .registers 5
    .param p0, "$this"  # S
    .param p1, "other"  # S

    const/4 v0, 0x0

    .line 90
    .local v0, "$i$f$minus-xj2QHRw":I
    const v1, 0xffff

    and-int v2, p0, v1

    invoke-static {v2}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v2

    and-int/2addr v1, p1

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    sub-int/2addr v2, v1

    invoke-static {v2}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    return v1
.end method

.method private static final or-xj2QHRw(SS)S
    .registers 4
    .param p0, "$this"  # S
    .param p1, "other"  # S

    const/4 v0, 0x0

    .line 153
    .local v0, "$i$f$or-xj2QHRw":I
    or-int v1, p0, p1

    int-to-short v1, v1

    invoke-static {v1}, Lkotlin/UShort;->constructor-impl(S)S

    move-result v1

    return v1
.end method

.method private static final plus-7apg3OU(SB)I
    .registers 5
    .param p0, "$this"  # S
    .param p1, "other"  # B

    const/4 v0, 0x0

    .line 74
    .local v0, "$i$f$plus-7apg3OU":I
    const v1, 0xffff

    and-int/2addr v1, p0

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    and-int/lit16 v2, p1, 0xff

    invoke-static {v2}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v2

    add-int/2addr v1, v2

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    return v1
.end method

.method private static final plus-VKZWuLQ(SJ)J
    .registers 8
    .param p0, "$this"  # S
    .param p1, "other"  # J

    const/4 v0, 0x0

    .line 83
    .local v0, "$i$f$plus-VKZWuLQ":I
    int-to-long v1, p0

    const-wide/32 v3, 0xffff

    and-long/2addr v1, v3

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    add-long/2addr v1, p1

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    return-wide v1
.end method

.method private static final plus-WZ4Q5Ns(SI)I
    .registers 4
    .param p0, "$this"  # S
    .param p1, "other"  # I

    const/4 v0, 0x0

    .line 80
    .local v0, "$i$f$plus-WZ4Q5Ns":I
    const v1, 0xffff

    and-int/2addr v1, p0

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    add-int/2addr v1, p1

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    return v1
.end method

.method private static final plus-xj2QHRw(SS)I
    .registers 5
    .param p0, "$this"  # S
    .param p1, "other"  # S

    const/4 v0, 0x0

    .line 77
    .local v0, "$i$f$plus-xj2QHRw":I
    const v1, 0xffff

    and-int v2, p0, v1

    invoke-static {v2}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v2

    and-int/2addr v1, p1

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    add-int/2addr v2, v1

    invoke-static {v2}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    return v1
.end method

.method private static final rangeTo-xj2QHRw(SS)Lkotlin/ranges/UIntRange;
    .registers 7
    .param p0, "$this"  # S
    .param p1, "other"  # S

    const/4 v0, 0x0

    .line 146
    .local v0, "$i$f$rangeTo-xj2QHRw":I
    new-instance v1, Lkotlin/ranges/UIntRange;

    const v2, 0xffff

    and-int v3, p0, v2

    invoke-static {v3}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v3

    and-int/2addr v2, p1

    invoke-static {v2}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v2

    const/4 v4, 0x0

    invoke-direct {v1, v3, v2, v4}, Lkotlin/ranges/UIntRange;-><init>(IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    return-object v1
.end method

.method private static final rem-7apg3OU(SB)I
    .registers 5
    .param p0, "$this"  # S
    .param p1, "other"  # B

    const/4 v0, 0x0

    .line 126
    .local v0, "$i$f$rem-7apg3OU":I
    const v1, 0xffff

    and-int/2addr v1, p0

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    and-int/lit16 v2, p1, 0xff

    invoke-static {v2}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v2

    invoke-static {v1, v2}, Lkotlin/UnsignedKt;->uintRemainder-J1ME1BU(II)I

    move-result v1

    return v1
.end method

.method private static final rem-VKZWuLQ(SJ)J
    .registers 8
    .param p0, "$this"  # S
    .param p1, "other"  # J

    const/4 v0, 0x0

    .line 135
    .local v0, "$i$f$rem-VKZWuLQ":I
    int-to-long v1, p0

    const-wide/32 v3, 0xffff

    and-long/2addr v1, v3

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    invoke-static {v1, v2, p1, p2}, Lkotlin/UnsignedKt;->ulongRemainder-eb3DHEI(JJ)J

    move-result-wide v1

    return-wide v1
.end method

.method private static final rem-WZ4Q5Ns(SI)I
    .registers 4
    .param p0, "$this"  # S
    .param p1, "other"  # I

    const/4 v0, 0x0

    .line 132
    .local v0, "$i$f$rem-WZ4Q5Ns":I
    const v1, 0xffff

    and-int/2addr v1, p0

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    invoke-static {v1, p1}, Lkotlin/UnsignedKt;->uintRemainder-J1ME1BU(II)I

    move-result v1

    return v1
.end method

.method private static final rem-xj2QHRw(SS)I
    .registers 5
    .param p0, "$this"  # S
    .param p1, "other"  # S

    const/4 v0, 0x0

    .line 129
    .local v0, "$i$f$rem-xj2QHRw":I
    const v1, 0xffff

    and-int v2, p0, v1

    invoke-static {v2}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v2

    and-int/2addr v1, p1

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    invoke-static {v2, v1}, Lkotlin/UnsignedKt;->uintRemainder-J1ME1BU(II)I

    move-result v1

    return v1
.end method

.method private static final times-7apg3OU(SB)I
    .registers 5
    .param p0, "$this"  # S
    .param p1, "other"  # B

    const/4 v0, 0x0

    .line 100
    .local v0, "$i$f$times-7apg3OU":I
    const v1, 0xffff

    and-int/2addr v1, p0

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    and-int/lit16 v2, p1, 0xff

    invoke-static {v2}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v2

    mul-int v1, v1, v2

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    return v1
.end method

.method private static final times-VKZWuLQ(SJ)J
    .registers 8
    .param p0, "$this"  # S
    .param p1, "other"  # J

    const/4 v0, 0x0

    .line 109
    .local v0, "$i$f$times-VKZWuLQ":I
    int-to-long v1, p0

    const-wide/32 v3, 0xffff

    and-long/2addr v1, v3

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    mul-long v1, v1, p1

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    return-wide v1
.end method

.method private static final times-WZ4Q5Ns(SI)I
    .registers 4
    .param p0, "$this"  # S
    .param p1, "other"  # I

    const/4 v0, 0x0

    .line 106
    .local v0, "$i$f$times-WZ4Q5Ns":I
    const v1, 0xffff

    and-int/2addr v1, p0

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    mul-int v1, v1, p1

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    return v1
.end method

.method private static final times-xj2QHRw(SS)I
    .registers 5
    .param p0, "$this"  # S
    .param p1, "other"  # S

    const/4 v0, 0x0

    .line 103
    .local v0, "$i$f$times-xj2QHRw":I
    const v1, 0xffff

    and-int v2, p0, v1

    invoke-static {v2}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v2

    and-int/2addr v1, p1

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    mul-int v2, v2, v1

    invoke-static {v2}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    return v1
.end method

.method private static final toByte-impl(S)B
    .registers 3
    .param p0, "$this"  # S

    const/4 v0, 0x0

    .line 171
    .local v0, "$i$f$toByte":I
    int-to-byte v1, p0

    return v1
.end method

.method private static final toDouble-impl(S)D
    .registers 4
    .param p0, "$this"  # S

    const/4 v0, 0x0

    .line 250
    .local v0, "$i$f$toDouble":I
    const v1, 0xffff

    and-int/2addr v1, p0

    int-to-double v1, v1

    return-wide v1
.end method

.method private static final toFloat-impl(S)F
    .registers 3
    .param p0, "$this"  # S

    const/4 v0, 0x0

    .line 243
    .local v0, "$i$f$toFloat":I
    const v1, 0xffff

    and-int/2addr v1, p0

    int-to-float v1, v1

    return v1
.end method

.method private static final toInt-impl(S)I
    .registers 3
    .param p0, "$this"  # S

    const/4 v0, 0x0

    .line 191
    .local v0, "$i$f$toInt":I
    const v1, 0xffff

    and-int/2addr v1, p0

    return v1
.end method

.method private static final toLong-impl(S)J
    .registers 6
    .param p0, "$this"  # S

    const/4 v0, 0x0

    .line 201
    .local v0, "$i$f$toLong":I
    int-to-long v1, p0

    const-wide/32 v3, 0xffff

    and-long/2addr v1, v3

    return-wide v1
.end method

.method private static final toShort-impl(S)S
    .registers 2
    .param p0, "$this"  # S

    const/4 v0, 0x0

    .line 181
    .local v0, "$i$f$toShort":I
    return p0
.end method

.method public static toString-impl(S)Ljava/lang/String;
    .registers 2
    .param p0, "$this"  # S

    .line 252
    const v0, 0xffff

    and-int/2addr v0, p0

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static final toUByte-w2LRezQ(S)B
    .registers 3
    .param p0, "$this"  # S

    const/4 v0, 0x0

    .line 212
    .local v0, "$i$f$toUByte-w2LRezQ":I
    int-to-byte v1, p0

    invoke-static {v1}, Lkotlin/UByte;->constructor-impl(B)B

    move-result v1

    return v1
.end method

.method private static final toUInt-pVg5ArA(S)I
    .registers 3
    .param p0, "$this"  # S

    const/4 v0, 0x0

    .line 225
    .local v0, "$i$f$toUInt-pVg5ArA":I
    const v1, 0xffff

    and-int/2addr v1, p0

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    return v1
.end method

.method private static final toULong-s-VKNKU(S)J
    .registers 6
    .param p0, "$this"  # S

    const/4 v0, 0x0

    .line 235
    .local v0, "$i$f$toULong-s-VKNKU":I
    int-to-long v1, p0

    const-wide/32 v3, 0xffff

    and-long/2addr v1, v3

    invoke-static {v1, v2}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v1

    return-wide v1
.end method

.method private static final toUShort-Mh2AYeg(S)S
    .registers 2
    .param p0, "$this"  # S

    const/4 v0, 0x0

    .line 215
    .local v0, "$i$f$toUShort-Mh2AYeg":I
    return p0
.end method

.method private static final xor-xj2QHRw(SS)S
    .registers 4
    .param p0, "$this"  # S
    .param p1, "other"  # S

    const/4 v0, 0x0

    .line 156
    .local v0, "$i$f$xor-xj2QHRw":I
    xor-int v1, p0, p1

    int-to-short v1, v1

    invoke-static {v1}, Lkotlin/UShort;->constructor-impl(S)S

    move-result v1

    return v1
.end method


# virtual methods
.method public bridge synthetic compareTo(Ljava/lang/Object;)I
    .registers 2

    .line 15
    check-cast p1, Lkotlin/UShort;

    invoke-virtual {p1}, Lkotlin/UShort;->unbox-impl()S

    move-result p1

    invoke-direct {p0, p1}, Lkotlin/UShort;->compareTo-xj2QHRw(S)I

    move-result p1

    return p1
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 3

    .line 1
    iget-short v0, p0, Lkotlin/UShort;->data:S

    invoke-static {v0, p1}, Lkotlin/UShort;->equals-impl(SLjava/lang/Object;)Z

    move-result p1

    return p1
.end method

.method public hashCode()I
    .registers 2

    .line 1
    iget-short v0, p0, Lkotlin/UShort;->data:S

    invoke-static {v0}, Lkotlin/UShort;->hashCode-impl(S)I

    move-result v0

    return v0
.end method

.method public toString()Ljava/lang/String;
    .registers 2

    .line 1
    iget-short v0, p0, Lkotlin/UShort;->data:S

    invoke-static {v0}, Lkotlin/UShort;->toString-impl(S)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final synthetic unbox-impl()S
    .registers 2

    iget-short v0, p0, Lkotlin/UShort;->data:S

    return v0
.end method
