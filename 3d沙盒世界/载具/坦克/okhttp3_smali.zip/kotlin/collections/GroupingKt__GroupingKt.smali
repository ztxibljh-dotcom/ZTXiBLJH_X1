.class Lkotlin/collections/GroupingKt__GroupingKt;
.super Lkotlin/collections/GroupingKt__GroupingJVMKt;
.source "Grouping.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nGrouping.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Grouping.kt\nkotlin/collections/GroupingKt__GroupingKt\n*L\n1#1,291:1\n80#1,6:292\n53#1:298\n80#1,6:299\n80#1,6:305\n53#1:311\n80#1,6:312\n80#1,6:318\n53#1:324\n80#1,6:325\n80#1,6:331\n188#1,2:337\n80#1,6:339\n*E\n*S KotlinDebug\n*F\n+ 1 Grouping.kt\nkotlin/collections/GroupingKt__GroupingKt\n*L\n53#1,6:292\n112#1:298\n112#1,6:299\n143#1,6:305\n164#1:311\n164#1,6:312\n189#1,6:318\n211#1:324\n211#1,6:325\n239#1,6:331\n257#1,2:337\n257#1,6:339\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    bv = {
        0x1,
        0x0,
        0x3
    }
    d1 = {
        "\u0000@\n\u0000\n\u0002\u0010$\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010%\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\n\u001a\u009e\u0001\u0010\u0000\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0001\"\u0004\b\u0000\u0010\u0004\"\u0004\b\u0001\u0010\u0002\"\u0004\b\u0002\u0010\u0003*\u000e\u0012\u0004\u0012\u0002H\u0004\u0012\u0004\u0012\u0002H\u00020\u00052b\u0010\u0006\u001a^\u0012\u0013\u0012\u0011H\u0002¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\n\u0012\u0015\u0012\u0013\u0018\u0001H\u0003¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\u000b\u0012\u0013\u0012\u0011H\u0004¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\f\u0012\u0013\u0012\u00110\r¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\u000e\u0012\u0004\u0012\u0002H\u00030\u0007H\u0087\bø\u0001\u0000\u001a·\u0001\u0010\u000f\u001a\u0002H\u0010\"\u0004\b\u0000\u0010\u0004\"\u0004\b\u0001\u0010\u0002\"\u0004\b\u0002\u0010\u0003\"\u0016\b\u0003\u0010\u0010*\u0010\u0012\u0006\b\u0000\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0011*\u000e\u0012\u0004\u0012\u0002H\u0004\u0012\u0004\u0012\u0002H\u00020\u00052\u0006\u0010\u0012\u001a\u0002H\u00102b\u0010\u0006\u001a^\u0012\u0013\u0012\u0011H\u0002¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\n\u0012\u0015\u0012\u0013\u0018\u0001H\u0003¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\u000b\u0012\u0013\u0012\u0011H\u0004¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\f\u0012\u0013\u0012\u00110\r¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\u000e\u0012\u0004\u0012\u0002H\u00030\u0007H\u0087\bø\u0001\u0000¢\u0006\u0002\u0010\u0013\u001aI\u0010\u0014\u001a\u0002H\u0010\"\u0004\b\u0000\u0010\u0004\"\u0004\b\u0001\u0010\u0002\"\u0016\b\u0002\u0010\u0010*\u0010\u0012\u0006\b\u0000\u0012\u0002H\u0002\u0012\u0004\u0012\u00020\u00150\u0011*\u000e\u0012\u0004\u0012\u0002H\u0004\u0012\u0004\u0012\u0002H\u00020\u00052\u0006\u0010\u0012\u001a\u0002H\u0010H\u0007¢\u0006\u0002\u0010\u0016\u001a¿\u0001\u0010\u0017\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0001\"\u0004\b\u0000\u0010\u0004\"\u0004\b\u0001\u0010\u0002\"\u0004\b\u0002\u0010\u0003*\u000e\u0012\u0004\u0012\u0002H\u0004\u0012\u0004\u0012\u0002H\u00020\u000526\u0010\u0018\u001a2\u0012\u0013\u0012\u0011H\u0002¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\n\u0012\u0013\u0012\u0011H\u0004¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\f\u0012\u0004\u0012\u0002H\u00030\u00192K\u0010\u0006\u001aG\u0012\u0013\u0012\u0011H\u0002¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\n\u0012\u0013\u0012\u0011H\u0003¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\u000b\u0012\u0013\u0012\u0011H\u0004¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\f\u0012\u0004\u0012\u0002H\u00030\u001aH\u0087\bø\u0001\u0000\u001a\u007f\u0010\u0017\u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0001\"\u0004\b\u0000\u0010\u0004\"\u0004\b\u0001\u0010\u0002\"\u0004\b\u0002\u0010\u0003*\u000e\u0012\u0004\u0012\u0002H\u0004\u0012\u0004\u0012\u0002H\u00020\u00052\u0006\u0010\u001b\u001a\u0002H\u000326\u0010\u0006\u001a2\u0012\u0013\u0012\u0011H\u0003¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\u000b\u0012\u0013\u0012\u0011H\u0004¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\f\u0012\u0004\u0012\u0002H\u00030\u0019H\u0087\bø\u0001\u0000¢\u0006\u0002\u0010\u001c\u001aØ\u0001\u0010\u001d\u001a\u0002H\u0010\"\u0004\b\u0000\u0010\u0004\"\u0004\b\u0001\u0010\u0002\"\u0004\b\u0002\u0010\u0003\"\u0016\b\u0003\u0010\u0010*\u0010\u0012\u0006\b\u0000\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0011*\u000e\u0012\u0004\u0012\u0002H\u0004\u0012\u0004\u0012\u0002H\u00020\u00052\u0006\u0010\u0012\u001a\u0002H\u001026\u0010\u0018\u001a2\u0012\u0013\u0012\u0011H\u0002¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\n\u0012\u0013\u0012\u0011H\u0004¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\f\u0012\u0004\u0012\u0002H\u00030\u00192K\u0010\u0006\u001aG\u0012\u0013\u0012\u0011H\u0002¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\n\u0012\u0013\u0012\u0011H\u0003¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\u000b\u0012\u0013\u0012\u0011H\u0004¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\f\u0012\u0004\u0012\u0002H\u00030\u001aH\u0087\bø\u0001\u0000¢\u0006\u0002\u0010\u001e\u001a\u0093\u0001\u0010\u001d\u001a\u0002H\u0010\"\u0004\b\u0000\u0010\u0004\"\u0004\b\u0001\u0010\u0002\"\u0004\b\u0002\u0010\u0003\"\u0016\b\u0003\u0010\u0010*\u0010\u0012\u0006\b\u0000\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00030\u0011*\u000e\u0012\u0004\u0012\u0002H\u0004\u0012\u0004\u0012\u0002H\u00020\u00052\u0006\u0010\u0012\u001a\u0002H\u00102\u0006\u0010\u001b\u001a\u0002H\u000326\u0010\u0006\u001a2\u0012\u0013\u0012\u0011H\u0003¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\u000b\u0012\u0013\u0012\u0011H\u0004¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\f\u0012\u0004\u0012\u0002H\u00030\u0019H\u0087\bø\u0001\u0000¢\u0006\u0002\u0010\u001f\u001a\u008b\u0001\u0010 \u001a\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H!0\u0001\"\u0004\b\u0000\u0010!\"\b\b\u0001\u0010\u0004*\u0002H!\"\u0004\b\u0002\u0010\u0002*\u000e\u0012\u0004\u0012\u0002H\u0004\u0012\u0004\u0012\u0002H\u00020\u00052K\u0010\u0006\u001aG\u0012\u0013\u0012\u0011H\u0002¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\n\u0012\u0013\u0012\u0011H!¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\u000b\u0012\u0013\u0012\u0011H\u0004¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\f\u0012\u0004\u0012\u0002H!0\u001aH\u0087\bø\u0001\u0000\u001a¤\u0001\u0010\"\u001a\u0002H\u0010\"\u0004\b\u0000\u0010!\"\b\b\u0001\u0010\u0004*\u0002H!\"\u0004\b\u0002\u0010\u0002\"\u0016\b\u0003\u0010\u0010*\u0010\u0012\u0006\b\u0000\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H!0\u0011*\u000e\u0012\u0004\u0012\u0002H\u0004\u0012\u0004\u0012\u0002H\u00020\u00052\u0006\u0010\u0012\u001a\u0002H\u00102K\u0010\u0006\u001aG\u0012\u0013\u0012\u0011H\u0002¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\n\u0012\u0013\u0012\u0011H!¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\u000b\u0012\u0013\u0012\u0011H\u0004¢\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\f\u0012\u0004\u0012\u0002H!0\u001aH\u0087\bø\u0001\u0000¢\u0006\u0002\u0010#\u0082\u0002\u0007\n\u0005\b\u009920\u0001¨\u0006$"
    }
    d2 = {
        "aggregate",
        "",
        "K",
        "R",
        "T",
        "Lkotlin/collections/Grouping;",
        "operation",
        "Lkotlin/Function4;",
        "Lkotlin/ParameterName;",
        "name",
        "key",
        "accumulator",
        "element",
        "",
        "first",
        "aggregateTo",
        "M",
        "",
        "destination",
        "(Lkotlin/collections/Grouping;Ljava/util/Map;Lkotlin/jvm/functions/Function4;)Ljava/util/Map;",
        "eachCountTo",
        "",
        "(Lkotlin/collections/Grouping;Ljava/util/Map;)Ljava/util/Map;",
        "fold",
        "initialValueSelector",
        "Lkotlin/Function2;",
        "Lkotlin/Function3;",
        "initialValue",
        "(Lkotlin/collections/Grouping;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)Ljava/util/Map;",
        "foldTo",
        "(Lkotlin/collections/Grouping;Ljava/util/Map;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function3;)Ljava/util/Map;",
        "(Lkotlin/collections/Grouping;Ljava/util/Map;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)Ljava/util/Map;",
        "reduce",
        "S",
        "reduceTo",
        "(Lkotlin/collections/Grouping;Ljava/util/Map;Lkotlin/jvm/functions/Function3;)Ljava/util/Map;",
        "kotlin-stdlib"
    }
    k = 0x5
    mv = {
        0x1,
        0x4,
        0x0
    }
    xi = 0x1
    xs = "kotlin/collections/GroupingKt"
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Lkotlin/collections/GroupingKt__GroupingJVMKt;-><init>()V

    return-void
.end method

.method public static final aggregate(Lkotlin/collections/Grouping;Lkotlin/jvm/functions/Function4;)Ljava/util/Map;
    .registers 11
    .param p0, "$this$aggregate"  # Lkotlin/collections/Grouping;
    .param p1, "operation"  # Lkotlin/jvm/functions/Function4;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            "K:",
            "Ljava/lang/Object;",
            "R:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlin/collections/Grouping<",
            "TT;+TK;>;",
            "Lkotlin/jvm/functions/Function4<",
            "-TK;-TR;-TT;-",
            "Ljava/lang/Boolean;",
            "+TR;>;)",
            "Ljava/util/Map<",
            "TK;TR;>;"
        }
    .end annotation

    const/4 v0, 0x0

    .local v0, "$i$f$aggregate":I
    const-string v1, "$this$aggregate"

    invoke-static {p0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "operation"

    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 53
    new-instance v1, Ljava/util/LinkedHashMap;

    invoke-direct {v1}, Ljava/util/LinkedHashMap;-><init>()V

    check-cast v1, Ljava/util/Map;

    .local v1, "destination$iv":Ljava/util/Map;
    move-object v2, p0

    .local v2, "$this$aggregateTo$iv":Lkotlin/collections/Grouping;
    const/4 v3, 0x0

    .line 292
    .local v3, "$i$f$aggregateTo":I
    invoke-interface {v2}, Lkotlin/collections/Grouping;->sourceIterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_18
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_41

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    .line 293
    .local v5, "e$iv":Ljava/lang/Object;
    invoke-interface {v2, v5}, Lkotlin/collections/Grouping;->keyOf(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    .line 294
    .local v6, "key$iv":Ljava/lang/Object;
    invoke-interface {v1, v6}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    .line 295
    .local v7, "accumulator$iv":Ljava/lang/Object;
    if-nez v7, :cond_34

    invoke-interface {v1, v6}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_34

    const/4 v8, 0x1

    goto :goto_35

    :cond_34
    const/4 v8, 0x0

    :goto_35
    invoke-static {v8}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v8

    invoke-interface {p1, v6, v7, v5, v8}, Lkotlin/jvm/functions/Function4;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    invoke-interface {v1, v6, v8}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 292
    .end local v5  # "e$iv":Ljava/lang/Object;
    .end local v6  # "key$iv":Ljava/lang/Object;
    .end local v7  # "accumulator$iv":Ljava/lang/Object;
    goto :goto_18

    .line 297
    :cond_41
    nop

    .line 53
    .end local v1  # "destination$iv":Ljava/util/Map;
    .end local v2  # "$this$aggregateTo$iv":Lkotlin/collections/Grouping;
    .end local v3  # "$i$f$aggregateTo":I
    return-object v1
.end method

.method public static final aggregateTo(Lkotlin/collections/Grouping;Ljava/util/Map;Lkotlin/jvm/functions/Function4;)Ljava/util/Map;
    .registers 9
    .param p0, "$this$aggregateTo"  # Lkotlin/collections/Grouping;
    .param p1, "destination"  # Ljava/util/Map;
    .param p2, "operation"  # Lkotlin/jvm/functions/Function4;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            "K:",
            "Ljava/lang/Object;",
            "R:",
            "Ljava/lang/Object;",
            "M::",
            "Ljava/util/Map<",
            "-TK;TR;>;>(",
            "Lkotlin/collections/Grouping<",
            "TT;+TK;>;TM;",
            "Lkotlin/jvm/functions/Function4<",
            "-TK;-TR;-TT;-",
            "Ljava/lang/Boolean;",
            "+TR;>;)TM;"
        }
    .end annotation

    const/4 v0, 0x0

    .local v0, "$i$f$aggregateTo":I
    const-string v1, "$this$aggregateTo"

    invoke-static {p0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "destination"

    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "operation"

    invoke-static {p2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 80
    invoke-interface {p0}, Lkotlin/collections/Grouping;->sourceIterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_14
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_3d

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    .line 81
    .local v2, "e":Ljava/lang/Object;
    invoke-interface {p0, v2}, Lkotlin/collections/Grouping;->keyOf(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    .line 82
    .local v3, "key":Ljava/lang/Object;
    invoke-interface {p1, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    .line 83
    .local v4, "accumulator":Ljava/lang/Object;
    if-nez v4, :cond_30

    invoke-interface {p1, v3}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_30

    const/4 v5, 0x1

    goto :goto_31

    :cond_30
    const/4 v5, 0x0

    :goto_31
    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v5

    invoke-interface {p2, v3, v4, v2, v5}, Lkotlin/jvm/functions/Function4;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    invoke-interface {p1, v3, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 80
    .end local v2  # "e":Ljava/lang/Object;
    .end local v3  # "key":Ljava/lang/Object;
    .end local v4  # "accumulator":Ljava/lang/Object;
    goto :goto_14

    .line 85
    :cond_3d
    return-object p1
.end method

.method public static final eachCountTo(Lkotlin/collections/Grouping;Ljava/util/Map;)Ljava/util/Map;
    .registers 23
    .param p0, "$this$eachCountTo"  # Lkotlin/collections/Grouping;
    .param p1, "destination"  # Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            "K:",
            "Ljava/lang/Object;",
            "M::",
            "Ljava/util/Map<",
            "-TK;",
            "Ljava/lang/Integer;",
            ">;>(",
            "Lkotlin/collections/Grouping<",
            "TT;+TK;>;TM;)TM;"
        }
    .end annotation

    move-object/from16 v0, p1

    const-string v1, "$this$eachCountTo"

    move-object/from16 v2, p0

    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "destination"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 257
    const/4 v1, 0x0

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    .local v3, "initialValue$iv":Ljava/lang/Object;
    move-object/from16 v4, p0

    .local v4, "$this$foldTo$iv":Lkotlin/collections/Grouping;
    const/4 v5, 0x0

    .line 337
    .local v5, "$i$f$foldTo":I
    nop

    .line 338
    move-object v6, v4

    .local v6, "$this$aggregateTo$iv$iv":Lkotlin/collections/Grouping;
    const/4 v7, 0x0

    .line 339
    .local v7, "$i$f$aggregateTo":I
    invoke-interface {v6}, Lkotlin/collections/Grouping;->sourceIterator()Ljava/util/Iterator;

    move-result-object v8

    :goto_1d
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_5c

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    .line 340
    .local v9, "e$iv$iv":Ljava/lang/Object;
    invoke-interface {v6, v9}, Lkotlin/collections/Grouping;->keyOf(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v10

    .line 341
    .local v10, "key$iv$iv":Ljava/lang/Object;
    invoke-interface {v0, v10}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v11

    .line 342
    .local v11, "accumulator$iv$iv":Ljava/lang/Object;
    const/4 v12, 0x1

    if-nez v11, :cond_3a

    invoke-interface {v0, v10}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_3a

    const/4 v13, 0x1

    goto :goto_3b

    :cond_3a
    const/4 v13, 0x0

    :goto_3b
    move-object v14, v10

    .local v14, "$noName_0$iv":Ljava/lang/Object;
    move-object v15, v9

    .local v15, "e$iv":Ljava/lang/Object;
    move-object/from16 v16, v11

    .local v13, "first$iv":Z
    .local v16, "acc$iv":Ljava/lang/Object;
    const/16 v17, 0x0

    .line 338
    .local v17, "$i$a$-aggregateTo-GroupingKt__GroupingKt$foldTo$2$iv":I
    if-eqz v13, :cond_46

    move-object/from16 v18, v3

    goto :goto_48

    :cond_46
    move-object/from16 v18, v16

    :goto_48
    check-cast v18, Ljava/lang/Number;

    invoke-virtual/range {v18 .. v18}, Ljava/lang/Number;->intValue()I

    move-result v18

    .local v18, "acc":I
    move-object/from16 v19, v15

    .local v19, "$noName_1":Ljava/lang/Object;
    const/16 v20, 0x0

    .line 257
    .local v20, "$i$a$-foldTo-GroupingKt__GroupingKt$eachCountTo$1":I
    add-int/lit8 v18, v18, 0x1

    .end local v18  # "acc":I
    .end local v19  # "$noName_1":Ljava/lang/Object;
    .end local v20  # "$i$a$-foldTo-GroupingKt__GroupingKt$eachCountTo$1":I
    invoke-static/range {v18 .. v18}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    .end local v13  # "first$iv":Z
    .end local v14  # "$noName_0$iv":Ljava/lang/Object;
    .end local v15  # "e$iv":Ljava/lang/Object;
    .end local v16  # "acc$iv":Ljava/lang/Object;
    .end local v17  # "$i$a$-aggregateTo-GroupingKt__GroupingKt$foldTo$2$iv":I
    invoke-interface {v0, v10, v12}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 339
    .end local v9  # "e$iv$iv":Ljava/lang/Object;
    .end local v10  # "key$iv$iv":Ljava/lang/Object;
    .end local v11  # "accumulator$iv$iv":Ljava/lang/Object;
    goto :goto_1d

    .line 344
    :cond_5c
    nop

    .line 338
    .end local v6  # "$this$aggregateTo$iv$iv":Lkotlin/collections/Grouping;
    .end local v7  # "$i$f$aggregateTo":I
    nop

    .line 257
    .end local v3  # "initialValue$iv":Ljava/lang/Object;
    .end local v4  # "$this$foldTo$iv":Lkotlin/collections/Grouping;
    .end local v5  # "$i$f$foldTo":I
    return-object v0
.end method

.method public static final fold(Lkotlin/collections/Grouping;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)Ljava/util/Map;
    .registers 21
    .param p0, "$this$fold"  # Lkotlin/collections/Grouping;
    .param p1, "initialValue"  # Ljava/lang/Object;
    .param p2, "operation"  # Lkotlin/jvm/functions/Function2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            "K:",
            "Ljava/lang/Object;",
            "R:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlin/collections/Grouping<",
            "TT;+TK;>;TR;",
            "Lkotlin/jvm/functions/Function2<",
            "-TR;-TT;+TR;>;)",
            "Ljava/util/Map<",
            "TK;TR;>;"
        }
    .end annotation

    move-object/from16 v0, p2

    const/4 v1, 0x0

    .local v1, "$i$f$fold":I
    const-string v2, "$this$fold"

    move-object/from16 v3, p0

    invoke-static {v3, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "operation"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 163
    nop

    .line 164
    move-object/from16 v2, p0

    .local v2, "$this$aggregate$iv":Lkotlin/collections/Grouping;
    const/4 v4, 0x0

    .line 311
    .local v4, "$i$f$aggregate":I
    new-instance v5, Ljava/util/LinkedHashMap;

    invoke-direct {v5}, Ljava/util/LinkedHashMap;-><init>()V

    check-cast v5, Ljava/util/Map;

    .local v5, "destination$iv$iv":Ljava/util/Map;
    move-object v6, v2

    .local v6, "$this$aggregateTo$iv$iv":Lkotlin/collections/Grouping;
    const/4 v7, 0x0

    .line 312
    .local v7, "$i$f$aggregateTo":I
    invoke-interface {v6}, Lkotlin/collections/Grouping;->sourceIterator()Ljava/util/Iterator;

    move-result-object v8

    :goto_20
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_54

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    .line 313
    .local v9, "e$iv$iv":Ljava/lang/Object;
    invoke-interface {v6, v9}, Lkotlin/collections/Grouping;->keyOf(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v10

    .line 314
    .local v10, "key$iv$iv":Ljava/lang/Object;
    invoke-interface {v5, v10}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v11

    .line 315
    .local v11, "accumulator$iv$iv":Ljava/lang/Object;
    if-nez v11, :cond_3c

    invoke-interface {v5, v10}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_3c

    const/4 v12, 0x1

    goto :goto_3d

    :cond_3c
    const/4 v12, 0x0

    :goto_3d
    move-object v13, v11

    .local v13, "acc":Ljava/lang/Object;
    move-object v14, v9

    .local v12, "first":Z
    .local v14, "e":Ljava/lang/Object;
    move-object v15, v10

    .local v15, "$noName_0":Ljava/lang/Object;
    const/16 v16, 0x0

    .line 164
    .local v16, "$i$a$-aggregate-GroupingKt__GroupingKt$fold$2":I
    move/from16 v17, v1

    if-eqz v12, :cond_49

    move-object/from16 v1, p1

    goto :goto_4a

    :cond_49
    move-object v1, v13

    .end local v1  # "$i$f$fold":I
    .local v17, "$i$f$fold":I
    :goto_4a
    invoke-interface {v0, v1, v14}, Lkotlin/jvm/functions/Function2;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    .end local v12  # "first":Z
    .end local v13  # "acc":Ljava/lang/Object;
    .end local v14  # "e":Ljava/lang/Object;
    .end local v15  # "$noName_0":Ljava/lang/Object;
    .end local v16  # "$i$a$-aggregate-GroupingKt__GroupingKt$fold$2":I
    invoke-interface {v5, v10, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 312
    .end local v9  # "e$iv$iv":Ljava/lang/Object;
    .end local v10  # "key$iv$iv":Ljava/lang/Object;
    .end local v11  # "accumulator$iv$iv":Ljava/lang/Object;
    move/from16 v1, v17

    goto :goto_20

    .line 317
    .end local v17  # "$i$f$fold":I
    .restart local v1  # "$i$f$fold":I
    :cond_54
    nop

    .line 311
    .end local v5  # "destination$iv$iv":Ljava/util/Map;
    .end local v6  # "$this$aggregateTo$iv$iv":Lkotlin/collections/Grouping;
    .end local v7  # "$i$f$aggregateTo":I
    nop

    .line 164
    .end local v2  # "$this$aggregate$iv":Lkotlin/collections/Grouping;
    .end local v4  # "$i$f$aggregate":I
    return-object v5
.end method

.method public static final fold(Lkotlin/collections/Grouping;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function3;)Ljava/util/Map;
    .registers 22
    .param p0, "$this$fold"  # Lkotlin/collections/Grouping;
    .param p1, "initialValueSelector"  # Lkotlin/jvm/functions/Function2;
    .param p2, "operation"  # Lkotlin/jvm/functions/Function3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            "K:",
            "Ljava/lang/Object;",
            "R:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlin/collections/Grouping<",
            "TT;+TK;>;",
            "Lkotlin/jvm/functions/Function2<",
            "-TK;-TT;+TR;>;",
            "Lkotlin/jvm/functions/Function3<",
            "-TK;-TR;-TT;+TR;>;)",
            "Ljava/util/Map<",
            "TK;TR;>;"
        }
    .end annotation

    move-object/from16 v0, p1

    move-object/from16 v1, p2

    const/4 v2, 0x0

    .local v2, "$i$f$fold":I
    const-string v3, "$this$fold"

    move-object/from16 v4, p0

    invoke-static {v4, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "initialValueSelector"

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "operation"

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 111
    nop

    .line 112
    move-object/from16 v3, p0

    .local v3, "$this$aggregate$iv":Lkotlin/collections/Grouping;
    const/4 v5, 0x0

    .line 298
    .local v5, "$i$f$aggregate":I
    new-instance v6, Ljava/util/LinkedHashMap;

    invoke-direct {v6}, Ljava/util/LinkedHashMap;-><init>()V

    check-cast v6, Ljava/util/Map;

    .local v6, "destination$iv$iv":Ljava/util/Map;
    move-object v7, v3

    .local v7, "$this$aggregateTo$iv$iv":Lkotlin/collections/Grouping;
    const/4 v8, 0x0

    .line 299
    .local v8, "$i$f$aggregateTo":I
    invoke-interface {v7}, Lkotlin/collections/Grouping;->sourceIterator()Ljava/util/Iterator;

    move-result-object v9

    :goto_27
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_68

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    .line 300
    .local v10, "e$iv$iv":Ljava/lang/Object;
    invoke-interface {v7, v10}, Lkotlin/collections/Grouping;->keyOf(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v11

    .line 301
    .local v11, "key$iv$iv":Ljava/lang/Object;
    invoke-interface {v6, v11}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v12

    .line 302
    .local v12, "accumulator$iv$iv":Ljava/lang/Object;
    if-nez v12, :cond_43

    invoke-interface {v6, v11}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_43

    const/4 v13, 0x1

    goto :goto_44

    :cond_43
    const/4 v13, 0x0

    :goto_44
    move-object v14, v12

    .local v14, "acc":Ljava/lang/Object;
    move-object v15, v10

    .local v13, "first":Z
    .local v15, "e":Ljava/lang/Object;
    move-object/from16 v16, v11

    .local v16, "key":Ljava/lang/Object;
    const/16 v17, 0x0

    .line 112
    .local v17, "$i$a$-aggregate-GroupingKt__GroupingKt$fold$1":I
    if-eqz v13, :cond_57

    move/from16 v18, v2

    move-object/from16 v2, v16

    .end local v16  # "key":Ljava/lang/Object;
    .local v2, "key":Ljava/lang/Object;
    .local v18, "$i$f$fold":I
    invoke-interface {v0, v2, v15}, Lkotlin/jvm/functions/Function2;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v16

    move-object/from16 v0, v16

    goto :goto_5c

    .end local v18  # "$i$f$fold":I
    .local v2, "$i$f$fold":I
    .restart local v16  # "key":Ljava/lang/Object;
    :cond_57
    move/from16 v18, v2

    move-object/from16 v2, v16

    .end local v16  # "key":Ljava/lang/Object;
    .local v2, "key":Ljava/lang/Object;
    .restart local v18  # "$i$f$fold":I
    move-object v0, v14

    :goto_5c
    invoke-interface {v1, v2, v0, v15}, Lkotlin/jvm/functions/Function3;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    .end local v2  # "key":Ljava/lang/Object;
    .end local v13  # "first":Z
    .end local v14  # "acc":Ljava/lang/Object;
    .end local v15  # "e":Ljava/lang/Object;
    .end local v17  # "$i$a$-aggregate-GroupingKt__GroupingKt$fold$1":I
    invoke-interface {v6, v11, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 299
    .end local v10  # "e$iv$iv":Ljava/lang/Object;
    .end local v11  # "key$iv$iv":Ljava/lang/Object;
    .end local v12  # "accumulator$iv$iv":Ljava/lang/Object;
    move-object/from16 v0, p1

    move/from16 v2, v18

    goto :goto_27

    .line 304
    .end local v18  # "$i$f$fold":I
    .local v2, "$i$f$fold":I
    :cond_68
    nop

    .line 298
    .end local v6  # "destination$iv$iv":Ljava/util/Map;
    .end local v7  # "$this$aggregateTo$iv$iv":Lkotlin/collections/Grouping;
    .end local v8  # "$i$f$aggregateTo":I
    nop

    .line 112
    .end local v3  # "$this$aggregate$iv":Lkotlin/collections/Grouping;
    .end local v5  # "$i$f$aggregate":I
    return-object v6
.end method

.method public static final foldTo(Lkotlin/collections/Grouping;Ljava/util/Map;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)Ljava/util/Map;
    .registers 20
    .param p0, "$this$foldTo"  # Lkotlin/collections/Grouping;
    .param p1, "destination"  # Ljava/util/Map;
    .param p2, "initialValue"  # Ljava/lang/Object;
    .param p3, "operation"  # Lkotlin/jvm/functions/Function2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            "K:",
            "Ljava/lang/Object;",
            "R:",
            "Ljava/lang/Object;",
            "M::",
            "Ljava/util/Map<",
            "-TK;TR;>;>(",
            "Lkotlin/collections/Grouping<",
            "TT;+TK;>;TM;TR;",
            "Lkotlin/jvm/functions/Function2<",
            "-TR;-TT;+TR;>;)TM;"
        }
    .end annotation

    move-object/from16 v0, p1

    move-object/from16 v1, p3

    const/4 v2, 0x0

    .local v2, "$i$f$foldTo":I
    const-string v3, "$this$foldTo"

    move-object/from16 v4, p0

    invoke-static {v4, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "destination"

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "operation"

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 188
    nop

    .line 189
    move-object/from16 v3, p0

    .local v3, "$this$aggregateTo$iv":Lkotlin/collections/Grouping;
    const/4 v5, 0x0

    .line 318
    .local v5, "$i$f$aggregateTo":I
    invoke-interface {v3}, Lkotlin/collections/Grouping;->sourceIterator()Ljava/util/Iterator;

    move-result-object v6

    :goto_1e
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_4d

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    .line 319
    .local v7, "e$iv":Ljava/lang/Object;
    invoke-interface {v3, v7}, Lkotlin/collections/Grouping;->keyOf(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    .line 320
    .local v8, "key$iv":Ljava/lang/Object;
    invoke-interface {v0, v8}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v9

    .line 321
    .local v9, "accumulator$iv":Ljava/lang/Object;
    if-nez v9, :cond_3a

    invoke-interface {v0, v8}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_3a

    const/4 v10, 0x1

    goto :goto_3b

    :cond_3a
    const/4 v10, 0x0

    :goto_3b
    move-object v11, v8

    .local v11, "$noName_0":Ljava/lang/Object;
    move-object v12, v7

    .local v12, "e":Ljava/lang/Object;
    move-object v13, v9

    .local v10, "first":Z
    .local v13, "acc":Ljava/lang/Object;
    const/4 v14, 0x0

    .line 189
    .local v14, "$i$a$-aggregateTo-GroupingKt__GroupingKt$foldTo$2":I
    if-eqz v10, :cond_44

    move-object/from16 v15, p2

    goto :goto_45

    :cond_44
    move-object v15, v13

    :goto_45
    invoke-interface {v1, v15, v12}, Lkotlin/jvm/functions/Function2;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v10

    .end local v10  # "first":Z
    .end local v11  # "$noName_0":Ljava/lang/Object;
    .end local v12  # "e":Ljava/lang/Object;
    .end local v13  # "acc":Ljava/lang/Object;
    .end local v14  # "$i$a$-aggregateTo-GroupingKt__GroupingKt$foldTo$2":I
    invoke-interface {v0, v8, v10}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 318
    .end local v7  # "e$iv":Ljava/lang/Object;
    .end local v8  # "key$iv":Ljava/lang/Object;
    .end local v9  # "accumulator$iv":Ljava/lang/Object;
    goto :goto_1e

    .line 323
    :cond_4d
    nop

    .line 189
    .end local v3  # "$this$aggregateTo$iv":Lkotlin/collections/Grouping;
    .end local v5  # "$i$f$aggregateTo":I
    return-object v0
.end method

.method public static final foldTo(Lkotlin/collections/Grouping;Ljava/util/Map;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function3;)Ljava/util/Map;
    .registers 21
    .param p0, "$this$foldTo"  # Lkotlin/collections/Grouping;
    .param p1, "destination"  # Ljava/util/Map;
    .param p2, "initialValueSelector"  # Lkotlin/jvm/functions/Function2;
    .param p3, "operation"  # Lkotlin/jvm/functions/Function3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            "K:",
            "Ljava/lang/Object;",
            "R:",
            "Ljava/lang/Object;",
            "M::",
            "Ljava/util/Map<",
            "-TK;TR;>;>(",
            "Lkotlin/collections/Grouping<",
            "TT;+TK;>;TM;",
            "Lkotlin/jvm/functions/Function2<",
            "-TK;-TT;+TR;>;",
            "Lkotlin/jvm/functions/Function3<",
            "-TK;-TR;-TT;+TR;>;)TM;"
        }
    .end annotation

    move-object/from16 v0, p1

    move-object/from16 v1, p2

    move-object/from16 v2, p3

    const/4 v3, 0x0

    .local v3, "$i$f$foldTo":I
    const-string v4, "$this$foldTo"

    move-object/from16 v5, p0

    invoke-static {v5, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, "destination"

    invoke-static {v0, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, "initialValueSelector"

    invoke-static {v1, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, "operation"

    invoke-static {v2, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 142
    nop

    .line 143
    move-object/from16 v4, p0

    .local v4, "$this$aggregateTo$iv":Lkotlin/collections/Grouping;
    const/4 v6, 0x0

    .line 305
    .local v6, "$i$f$aggregateTo":I
    invoke-interface {v4}, Lkotlin/collections/Grouping;->sourceIterator()Ljava/util/Iterator;

    move-result-object v7

    :goto_25
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_5a

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    .line 306
    .local v8, "e$iv":Ljava/lang/Object;
    invoke-interface {v4, v8}, Lkotlin/collections/Grouping;->keyOf(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v9

    .line 307
    .local v9, "key$iv":Ljava/lang/Object;
    invoke-interface {v0, v9}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v10

    .line 308
    .local v10, "accumulator$iv":Ljava/lang/Object;
    if-nez v10, :cond_41

    invoke-interface {v0, v9}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v11

    if-nez v11, :cond_41

    const/4 v11, 0x1

    goto :goto_42

    :cond_41
    const/4 v11, 0x0

    :goto_42
    move-object v12, v9

    .local v12, "key":Ljava/lang/Object;
    move-object v13, v8

    .local v13, "e":Ljava/lang/Object;
    move-object v14, v10

    .local v11, "first":Z
    .local v14, "acc":Ljava/lang/Object;
    const/4 v15, 0x0

    .line 143
    .local v15, "$i$a$-aggregateTo-GroupingKt__GroupingKt$foldTo$1":I
    if-eqz v11, :cond_4f

    invoke-interface {v1, v12, v13}, Lkotlin/jvm/functions/Function2;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v16

    move-object/from16 v1, v16

    goto :goto_50

    :cond_4f
    move-object v1, v14

    :goto_50
    invoke-interface {v2, v12, v1, v13}, Lkotlin/jvm/functions/Function3;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    .end local v11  # "first":Z
    .end local v12  # "key":Ljava/lang/Object;
    .end local v13  # "e":Ljava/lang/Object;
    .end local v14  # "acc":Ljava/lang/Object;
    .end local v15  # "$i$a$-aggregateTo-GroupingKt__GroupingKt$foldTo$1":I
    invoke-interface {v0, v9, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 305
    .end local v8  # "e$iv":Ljava/lang/Object;
    .end local v9  # "key$iv":Ljava/lang/Object;
    .end local v10  # "accumulator$iv":Ljava/lang/Object;
    move-object/from16 v1, p2

    goto :goto_25

    .line 310
    :cond_5a
    nop

    .line 143
    .end local v4  # "$this$aggregateTo$iv":Lkotlin/collections/Grouping;
    .end local v6  # "$i$f$aggregateTo":I
    return-object v0
.end method

.method public static final reduce(Lkotlin/collections/Grouping;Lkotlin/jvm/functions/Function3;)Ljava/util/Map;
    .registers 20
    .param p0, "$this$reduce"  # Lkotlin/collections/Grouping;
    .param p1, "operation"  # Lkotlin/jvm/functions/Function3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<S:",
            "Ljava/lang/Object;",
            "T::TS;K:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlin/collections/Grouping<",
            "TT;+TK;>;",
            "Lkotlin/jvm/functions/Function3<",
            "-TK;-TS;-TT;+TS;>;)",
            "Ljava/util/Map<",
            "TK;TS;>;"
        }
    .end annotation

    move-object/from16 v0, p1

    const/4 v1, 0x0

    .local v1, "$i$f$reduce":I
    const-string v2, "$this$reduce"

    move-object/from16 v3, p0

    invoke-static {v3, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "operation"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 211
    move-object/from16 v2, p0

    .local v2, "$this$aggregate$iv":Lkotlin/collections/Grouping;
    const/4 v4, 0x0

    .line 324
    .local v4, "$i$f$aggregate":I
    new-instance v5, Ljava/util/LinkedHashMap;

    invoke-direct {v5}, Ljava/util/LinkedHashMap;-><init>()V

    check-cast v5, Ljava/util/Map;

    .local v5, "destination$iv$iv":Ljava/util/Map;
    move-object v6, v2

    .local v6, "$this$aggregateTo$iv$iv":Lkotlin/collections/Grouping;
    const/4 v7, 0x0

    .line 325
    .local v7, "$i$f$aggregateTo":I
    invoke-interface {v6}, Lkotlin/collections/Grouping;->sourceIterator()Ljava/util/Iterator;

    move-result-object v8

    :goto_1f
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_4f

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    .line 326
    .local v9, "e$iv$iv":Ljava/lang/Object;
    invoke-interface {v6, v9}, Lkotlin/collections/Grouping;->keyOf(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v10

    .line 327
    .local v10, "key$iv$iv":Ljava/lang/Object;
    invoke-interface {v5, v10}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v11

    .line 328
    .local v11, "accumulator$iv$iv":Ljava/lang/Object;
    if-nez v11, :cond_3b

    invoke-interface {v5, v10}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_3b

    const/4 v12, 0x1

    goto :goto_3c

    :cond_3b
    const/4 v12, 0x0

    :goto_3c
    move-object v13, v10

    .local v13, "key":Ljava/lang/Object;
    move-object v14, v11

    .local v12, "first":Z
    .local v14, "acc":Ljava/lang/Object;
    move-object v15, v9

    .local v15, "e":Ljava/lang/Object;
    const/16 v16, 0x0

    .line 212
    .local v16, "$i$a$-aggregate-GroupingKt__GroupingKt$reduce$1":I
    nop

    .line 213
    if-eqz v12, :cond_45

    goto :goto_4b

    :cond_45
    invoke-interface {v0, v13, v14, v15}, Lkotlin/jvm/functions/Function3;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v17

    move-object/from16 v15, v17

    .end local v12  # "first":Z
    .end local v13  # "key":Ljava/lang/Object;
    .end local v14  # "acc":Ljava/lang/Object;
    .end local v15  # "e":Ljava/lang/Object;
    .end local v16  # "$i$a$-aggregate-GroupingKt__GroupingKt$reduce$1":I
    :goto_4b
    invoke-interface {v5, v10, v15}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 325
    .end local v9  # "e$iv$iv":Ljava/lang/Object;
    .end local v10  # "key$iv$iv":Ljava/lang/Object;
    .end local v11  # "accumulator$iv$iv":Ljava/lang/Object;
    goto :goto_1f

    .line 330
    :cond_4f
    nop

    .line 324
    .end local v5  # "destination$iv$iv":Ljava/util/Map;
    .end local v6  # "$this$aggregateTo$iv$iv":Lkotlin/collections/Grouping;
    .end local v7  # "$i$f$aggregateTo":I
    nop

    .line 214
    .end local v2  # "$this$aggregate$iv":Lkotlin/collections/Grouping;
    .end local v4  # "$i$f$aggregate":I
    return-object v5
.end method

.method public static final reduceTo(Lkotlin/collections/Grouping;Ljava/util/Map;Lkotlin/jvm/functions/Function3;)Ljava/util/Map;
    .registers 16
    .param p0, "$this$reduceTo"  # Lkotlin/collections/Grouping;
    .param p1, "destination"  # Ljava/util/Map;
    .param p2, "operation"  # Lkotlin/jvm/functions/Function3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<S:",
            "Ljava/lang/Object;",
            "T::TS;K:",
            "Ljava/lang/Object;",
            "M::",
            "Ljava/util/Map<",
            "-TK;TS;>;>(",
            "Lkotlin/collections/Grouping<",
            "TT;+TK;>;TM;",
            "Lkotlin/jvm/functions/Function3<",
            "-TK;-TS;-TT;+TS;>;)TM;"
        }
    .end annotation

    const/4 v0, 0x0

    .local v0, "$i$f$reduceTo":I
    const-string v1, "$this$reduceTo"

    invoke-static {p0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "destination"

    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "operation"

    invoke-static {p2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 239
    move-object v1, p0

    .local v1, "$this$aggregateTo$iv":Lkotlin/collections/Grouping;
    const/4 v2, 0x0

    .line 331
    .local v2, "$i$f$aggregateTo":I
    invoke-interface {v1}, Lkotlin/collections/Grouping;->sourceIterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_16
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_44

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    .line 332
    .local v4, "e$iv":Ljava/lang/Object;
    invoke-interface {v1, v4}, Lkotlin/collections/Grouping;->keyOf(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    .line 333
    .local v5, "key$iv":Ljava/lang/Object;
    invoke-interface {p1, v5}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    .line 334
    .local v6, "accumulator$iv":Ljava/lang/Object;
    if-nez v6, :cond_32

    invoke-interface {p1, v5}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_32

    const/4 v7, 0x1

    goto :goto_33

    :cond_32
    const/4 v7, 0x0

    :goto_33
    move-object v8, v6

    .local v8, "acc":Ljava/lang/Object;
    move-object v9, v5

    .local v9, "key":Ljava/lang/Object;
    move-object v10, v4

    .local v7, "first":Z
    .local v10, "e":Ljava/lang/Object;
    const/4 v11, 0x0

    .line 240
    .local v11, "$i$a$-aggregateTo-GroupingKt__GroupingKt$reduceTo$1":I
    nop

    .line 241
    if-eqz v7, :cond_3b

    goto :goto_40

    :cond_3b
    invoke-interface {p2, v9, v8, v10}, Lkotlin/jvm/functions/Function3;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v12

    move-object v10, v12

    .end local v7  # "first":Z
    .end local v8  # "acc":Ljava/lang/Object;
    .end local v9  # "key":Ljava/lang/Object;
    .end local v10  # "e":Ljava/lang/Object;
    .end local v11  # "$i$a$-aggregateTo-GroupingKt__GroupingKt$reduceTo$1":I
    :goto_40
    invoke-interface {p1, v5, v10}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 331
    .end local v4  # "e$iv":Ljava/lang/Object;
    .end local v5  # "key$iv":Ljava/lang/Object;
    .end local v6  # "accumulator$iv":Ljava/lang/Object;
    goto :goto_16

    .line 336
    :cond_44
    nop

    .line 242
    .end local v1  # "$this$aggregateTo$iv":Lkotlin/collections/Grouping;
    .end local v2  # "$i$f$aggregateTo":I
    return-object p1
.end method
