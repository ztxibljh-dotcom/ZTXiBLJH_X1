.class public final Lkotlin/collections/TypeAliasesKt;
.super Ljava/lang/Object;
.source "TypeAliases.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    bv = {
        0x1,
        0x0,
        0x3
    }
    d1 = {
        "\u0000.\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000*,\b\u0007\u0010\u0000\u001a\u0004\b\u0000\u0010\u0001\"\b\u0012\u0004\u0012\u0002H\u00010\u00022\b\u0012\u0004\u0012\u0002H\u00010\u0002B\f\b\u0003\u0012\b\b\u0004\u0012\u0004\b\b(\u0005*>\b\u0007\u0010\u0006\u001a\u0004\b\u0000\u0010\u0007\u001a\u0004\b\u0001\u0010\b\"\u000e\u0012\u0004\u0012\u0002H\u0007\u0012\u0004\u0012\u0002H\b0\t2\u000e\u0012\u0004\u0012\u0002H\u0007\u0012\u0004\u0012\u0002H\b0\tB\f\b\u0003\u0012\b\b\u0004\u0012\u0004\b\b(\u0005*,\b\u0007\u0010\n\u001a\u0004\b\u0000\u0010\u0001\"\b\u0012\u0004\u0012\u0002H\u00010\u000b2\b\u0012\u0004\u0012\u0002H\u00010\u000bB\f\b\u0003\u0012\b\b\u0004\u0012\u0004\b\b(\u0005*>\b\u0007\u0010\f\u001a\u0004\b\u0000\u0010\u0007\u001a\u0004\b\u0001\u0010\b\"\u000e\u0012\u0004\u0012\u0002H\u0007\u0012\u0004\u0012\u0002H\b0\r2\u000e\u0012\u0004\u0012\u0002H\u0007\u0012\u0004\u0012\u0002H\b0\rB\f\b\u0003\u0012\b\b\u0004\u0012\u0004\b\b(\u0005*,\b\u0007\u0010\u000e\u001a\u0004\b\u0000\u0010\u0001\"\b\u0012\u0004\u0012\u0002H\u00010\u000f2\b\u0012\u0004\u0012\u0002H\u00010\u000fB\f\b\u0003\u0012\b\b\u0004\u0012\u0004\b\b(\u0005*\u001a\b\u0007\u0010\u0010\"\u00020\u00112\u00020\u0011B\f\b\u0003\u0012\b\b\u0004\u0012\u0004\b\b(\u0005¨\u0006\u0012"
    }
    d2 = {
        "ArrayList",
        "E",
        "Ljava/util/ArrayList;",
        "Lkotlin/SinceKotlin;",
        "version",
        "1.1",
        "HashMap",
        "K",
        "V",
        "Ljava/util/HashMap;",
        "HashSet",
        "Ljava/util/HashSet;",
        "LinkedHashMap",
        "Ljava/util/LinkedHashMap;",
        "LinkedHashSet",
        "Ljava/util/LinkedHashSet;",
        "RandomAccess",
        "Ljava/util/RandomAccess;",
        "kotlin-stdlib"
    }
    k = 0x2
    mv = {
        0x1,
        0x4,
        0x0
    }
.end annotation


# direct methods
.method public static synthetic ArrayList$annotations()V
    .registers 0

    return-void
.end method

.method public static synthetic HashMap$annotations()V
    .registers 0

    return-void
.end method

.method public static synthetic HashSet$annotations()V
    .registers 0

    return-void
.end method

.method public static synthetic LinkedHashMap$annotations()V
    .registers 0

    return-void
.end method

.method public static synthetic LinkedHashSet$annotations()V
    .registers 0

    return-void
.end method

.method public static synthetic RandomAccess$annotations()V
    .registers 0

    return-void
.end method
