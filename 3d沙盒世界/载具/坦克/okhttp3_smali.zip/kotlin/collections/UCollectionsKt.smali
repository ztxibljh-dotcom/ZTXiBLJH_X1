.class public final Lkotlin/collections/UCollectionsKt;
.super Lkotlin/collections/UCollectionsKt___UCollectionsKt;
.source "_UCollections.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    bv = {
        0x1,
        0x0,
        0x3
    }
    d1 = {
        "kotlin/collections/UCollectionsKt___UCollectionsKt"
    }
    k = 0x4
    mv = {
        0x1,
        0x4,
        0x0
    }
    xi = 0x1
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Lkotlin/collections/UCollectionsKt___UCollectionsKt;-><init>()V

    return-void
.end method
