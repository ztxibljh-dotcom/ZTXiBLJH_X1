.class Lkotlin/comparisons/UComparisonsKt___UComparisonsKt;
.super Ljava/lang/Object;
.source "_UComparisons.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    bv = {
        0x1,
        0x0,
        0x3
    }
    d1 = {
        "\u0000B\n\u0000\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0010\u001a\"\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00012\u0006\u0010\u0003\u001a\u00020\u0001H\u0007ø\u0001\u0000¢\u0006\u0004\b\u0004\u0010\u0005\u001a+\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00012\u0006\u0010\u0003\u001a\u00020\u00012\u0006\u0010\u0006\u001a\u00020\u0001H\u0087\bø\u0001\u0000¢\u0006\u0004\b\u0007\u0010\b\u001a&\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00012\n\u0010\t\u001a\u00020\n\"\u00020\u0001H\u0007ø\u0001\u0000¢\u0006\u0004\b\u000b\u0010\f\u001a\"\u0010\u0000\u001a\u00020\r2\u0006\u0010\u0002\u001a\u00020\r2\u0006\u0010\u0003\u001a\u00020\rH\u0007ø\u0001\u0000¢\u0006\u0004\b\u000e\u0010\u000f\u001a+\u0010\u0000\u001a\u00020\r2\u0006\u0010\u0002\u001a\u00020\r2\u0006\u0010\u0003\u001a\u00020\r2\u0006\u0010\u0006\u001a\u00020\rH\u0087\bø\u0001\u0000¢\u0006\u0004\b\u0010\u0010\u0011\u001a&\u0010\u0000\u001a\u00020\r2\u0006\u0010\u0002\u001a\u00020\r2\n\u0010\t\u001a\u00020\u0012\"\u00020\rH\u0007ø\u0001\u0000¢\u0006\u0004\b\u0013\u0010\u0014\u001a\"\u0010\u0000\u001a\u00020\u00152\u0006\u0010\u0002\u001a\u00020\u00152\u0006\u0010\u0003\u001a\u00020\u0015H\u0007ø\u0001\u0000¢\u0006\u0004\b\u0016\u0010\u0017\u001a+\u0010\u0000\u001a\u00020\u00152\u0006\u0010\u0002\u001a\u00020\u00152\u0006\u0010\u0003\u001a\u00020\u00152\u0006\u0010\u0006\u001a\u00020\u0015H\u0087\bø\u0001\u0000¢\u0006\u0004\b\u0018\u0010\u0019\u001a&\u0010\u0000\u001a\u00020\u00152\u0006\u0010\u0002\u001a\u00020\u00152\n\u0010\t\u001a\u00020\u001a\"\u00020\u0015H\u0007ø\u0001\u0000¢\u0006\u0004\b\u001b\u0010\u001c\u001a\"\u0010\u0000\u001a\u00020\u001d2\u0006\u0010\u0002\u001a\u00020\u001d2\u0006\u0010\u0003\u001a\u00020\u001dH\u0007ø\u0001\u0000¢\u0006\u0004\b\u001e\u0010\u001f\u001a+\u0010\u0000\u001a\u00020\u001d2\u0006\u0010\u0002\u001a\u00020\u001d2\u0006\u0010\u0003\u001a\u00020\u001d2\u0006\u0010\u0006\u001a\u00020\u001dH\u0087\bø\u0001\u0000¢\u0006\u0004\b \u0010!\u001a&\u0010\u0000\u001a\u00020\u001d2\u0006\u0010\u0002\u001a\u00020\u001d2\n\u0010\t\u001a\u00020\"\"\u00020\u001dH\u0007ø\u0001\u0000¢\u0006\u0004\b#\u0010$\u001a\"\u0010%\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00012\u0006\u0010\u0003\u001a\u00020\u0001H\u0007ø\u0001\u0000¢\u0006\u0004\b&\u0010\u0005\u001a+\u0010%\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00012\u0006\u0010\u0003\u001a\u00020\u00012\u0006\u0010\u0006\u001a\u00020\u0001H\u0087\bø\u0001\u0000¢\u0006\u0004\b\'\u0010\b\u001a&\u0010%\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00012\n\u0010\t\u001a\u00020\n\"\u00020\u0001H\u0007ø\u0001\u0000¢\u0006\u0004\b(\u0010\f\u001a\"\u0010%\u001a\u00020\r2\u0006\u0010\u0002\u001a\u00020\r2\u0006\u0010\u0003\u001a\u00020\rH\u0007ø\u0001\u0000¢\u0006\u0004\b)\u0010\u000f\u001a+\u0010%\u001a\u00020\r2\u0006\u0010\u0002\u001a\u00020\r2\u0006\u0010\u0003\u001a\u00020\r2\u0006\u0010\u0006\u001a\u00020\rH\u0087\bø\u0001\u0000¢\u0006\u0004\b*\u0010\u0011\u001a&\u0010%\u001a\u00020\r2\u0006\u0010\u0002\u001a\u00020\r2\n\u0010\t\u001a\u00020\u0012\"\u00020\rH\u0007ø\u0001\u0000¢\u0006\u0004\b+\u0010\u0014\u001a\"\u0010%\u001a\u00020\u00152\u0006\u0010\u0002\u001a\u00020\u00152\u0006\u0010\u0003\u001a\u00020\u0015H\u0007ø\u0001\u0000¢\u0006\u0004\b,\u0010\u0017\u001a+\u0010%\u001a\u00020\u00152\u0006\u0010\u0002\u001a\u00020\u00152\u0006\u0010\u0003\u001a\u00020\u00152\u0006\u0010\u0006\u001a\u00020\u0015H\u0087\bø\u0001\u0000¢\u0006\u0004\b-\u0010\u0019\u001a&\u0010%\u001a\u00020\u00152\u0006\u0010\u0002\u001a\u00020\u00152\n\u0010\t\u001a\u00020\u001a\"\u00020\u0015H\u0007ø\u0001\u0000¢\u0006\u0004\b.\u0010\u001c\u001a\"\u0010%\u001a\u00020\u001d2\u0006\u0010\u0002\u001a\u00020\u001d2\u0006\u0010\u0003\u001a\u00020\u001dH\u0007ø\u0001\u0000¢\u0006\u0004\b/\u0010\u001f\u001a+\u0010%\u001a\u00020\u001d2\u0006\u0010\u0002\u001a\u00020\u001d2\u0006\u0010\u0003\u001a\u00020\u001d2\u0006\u0010\u0006\u001a\u00020\u001dH\u0087\bø\u0001\u0000¢\u0006\u0004\b0\u0010!\u001a&\u0010%\u001a\u00020\u001d2\u0006\u0010\u0002\u001a\u00020\u001d2\n\u0010\t\u001a\u00020\"\"\u00020\u001dH\u0007ø\u0001\u0000¢\u0006\u0004\b1\u0010$\u0082\u0002\u0004\n\u0002\b\u0019¨\u00062"
    }
    d2 = {
        "maxOf",
        "Lkotlin/UByte;",
        "a",
        "b",
        "maxOf-Kr8caGY",
        "(BB)B",
        "c",
        "maxOf-b33U2AM",
        "(BBB)B",
        "other",
        "Lkotlin/UByteArray;",
        "maxOf-Wr6uiD8",
        "(B[B)B",
        "Lkotlin/UInt;",
        "maxOf-J1ME1BU",
        "(II)I",
        "maxOf-WZ9TVnA",
        "(III)I",
        "Lkotlin/UIntArray;",
        "maxOf-Md2H83M",
        "(I[I)I",
        "Lkotlin/ULong;",
        "maxOf-eb3DHEI",
        "(JJ)J",
        "maxOf-sambcqE",
        "(JJJ)J",
        "Lkotlin/ULongArray;",
        "maxOf-R03FKyM",
        "(J[J)J",
        "Lkotlin/UShort;",
        "maxOf-5PvTz6A",
        "(SS)S",
        "maxOf-VKSA0NQ",
        "(SSS)S",
        "Lkotlin/UShortArray;",
        "maxOf-t1qELG4",
        "(S[S)S",
        "minOf",
        "minOf-Kr8caGY",
        "minOf-b33U2AM",
        "minOf-Wr6uiD8",
        "minOf-J1ME1BU",
        "minOf-WZ9TVnA",
        "minOf-Md2H83M",
        "minOf-eb3DHEI",
        "minOf-sambcqE",
        "minOf-R03FKyM",
        "minOf-5PvTz6A",
        "minOf-VKSA0NQ",
        "minOf-t1qELG4",
        "kotlin-stdlib"
    }
    k = 0x5
    mv = {
        0x1,
        0x4,
        0x0
    }
    xi = 0x1
    xs = "kotlin/comparisons/UComparisonsKt"
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static final maxOf-5PvTz6A(SS)S
    .registers 4
    .param p0, "a"  # S
    .param p1, "b"  # S

    .line 51
    const v0, 0xffff

    and-int v1, p0, v0

    and-int/2addr v0, p1

    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->compare(II)I

    move-result v0

    if-ltz v0, :cond_e

    move v0, p0

    goto :goto_f

    :cond_e
    move v0, p1

    :goto_f
    return v0
.end method

.method public static final maxOf-J1ME1BU(II)I
    .registers 3
    .param p0, "a"  # I
    .param p1, "b"  # I

    .line 24
    invoke-static {p0, p1}, Lkotlin/UnsignedKt;->uintCompare(II)I

    move-result v0

    if-ltz v0, :cond_8

    move v0, p0

    goto :goto_9

    :cond_8
    move v0, p1

    :goto_9
    return v0
.end method

.method public static final maxOf-Kr8caGY(BB)B
    .registers 4
    .param p0, "a"  # B
    .param p1, "b"  # B

    .line 42
    and-int/lit16 v0, p0, 0xff

    and-int/lit16 v1, p1, 0xff

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->compare(II)I

    move-result v0

    if-ltz v0, :cond_c

    move v0, p0

    goto :goto_d

    :cond_c
    move v0, p1

    :goto_d
    return v0
.end method

.method public static final varargs maxOf-Md2H83M(I[I)I
    .registers 6
    .param p0, "a"  # I
    .param p1, "other"  # [I

    const-string v0, "other"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 100
    move v0, p0

    .line 101
    .local v0, "max":I
    array-length v1, p1

    const/4 v2, 0x0

    :goto_8
    if-ge v2, v1, :cond_13

    aget v3, p1, v2

    .local v3, "e":I
    invoke-static {v0, v3}, Lkotlin/comparisons/UComparisonsKt;->maxOf-J1ME1BU(II)I

    move-result v0

    .end local v3  # "e":I
    add-int/lit8 v2, v2, 0x1

    goto :goto_8

    .line 102
    :cond_13
    return v0
.end method

.method public static final varargs maxOf-R03FKyM(J[J)J
    .registers 9
    .param p0, "a"  # J
    .param p2, "other"  # [J

    const-string v0, "other"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 111
    move-wide v0, p0

    .line 112
    .local v0, "max":J
    array-length v2, p2

    const/4 v3, 0x0

    :goto_8
    if-ge v3, v2, :cond_13

    aget-wide v4, p2, v3

    .local v4, "e":J
    invoke-static {v0, v1, v4, v5}, Lkotlin/comparisons/UComparisonsKt;->maxOf-eb3DHEI(JJ)J

    move-result-wide v0

    .end local v4  # "e":J
    add-int/lit8 v3, v3, 0x1

    goto :goto_8

    .line 113
    :cond_13
    return-wide v0
.end method

.method private static final maxOf-VKSA0NQ(SSS)S
    .registers 5
    .param p0, "a"  # S
    .param p1, "b"  # S
    .param p2, "c"  # S

    const/4 v0, 0x0

    .line 91
    .local v0, "$i$f$maxOf-VKSA0NQ":I
    invoke-static {p1, p2}, Lkotlin/comparisons/UComparisonsKt;->maxOf-5PvTz6A(SS)S

    move-result v1

    invoke-static {p0, v1}, Lkotlin/comparisons/UComparisonsKt;->maxOf-5PvTz6A(SS)S

    move-result v1

    return v1
.end method

.method private static final maxOf-WZ9TVnA(III)I
    .registers 5
    .param p0, "a"  # I
    .param p1, "b"  # I
    .param p2, "c"  # I

    const/4 v0, 0x0

    .line 61
    .local v0, "$i$f$maxOf-WZ9TVnA":I
    invoke-static {p1, p2}, Lkotlin/comparisons/UComparisonsKt;->maxOf-J1ME1BU(II)I

    move-result v1

    invoke-static {p0, v1}, Lkotlin/comparisons/UComparisonsKt;->maxOf-J1ME1BU(II)I

    move-result v1

    return v1
.end method

.method public static final varargs maxOf-Wr6uiD8(B[B)B
    .registers 6
    .param p0, "a"  # B
    .param p1, "other"  # [B

    const-string v0, "other"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 122
    move v0, p0

    .line 123
    .local v0, "max":B
    array-length v1, p1

    const/4 v2, 0x0

    :goto_8
    if-ge v2, v1, :cond_13

    aget-byte v3, p1, v2

    .local v3, "e":B
    invoke-static {v0, v3}, Lkotlin/comparisons/UComparisonsKt;->maxOf-Kr8caGY(BB)B

    move-result v0

    .end local v3  # "e":B
    add-int/lit8 v2, v2, 0x1

    goto :goto_8

    .line 124
    :cond_13
    return v0
.end method

.method private static final maxOf-b33U2AM(BBB)B
    .registers 5
    .param p0, "a"  # B
    .param p1, "b"  # B
    .param p2, "c"  # B

    const/4 v0, 0x0

    .line 81
    .local v0, "$i$f$maxOf-b33U2AM":I
    invoke-static {p1, p2}, Lkotlin/comparisons/UComparisonsKt;->maxOf-Kr8caGY(BB)B

    move-result v1

    invoke-static {p0, v1}, Lkotlin/comparisons/UComparisonsKt;->maxOf-Kr8caGY(BB)B

    move-result v1

    return v1
.end method

.method public static final maxOf-eb3DHEI(JJ)J
    .registers 6
    .param p0, "a"  # J
    .param p2, "b"  # J

    .line 33
    invoke-static {p0, p1, p2, p3}, Lkotlin/UnsignedKt;->ulongCompare(JJ)I

    move-result v0

    if-ltz v0, :cond_8

    move-wide v0, p0

    goto :goto_9

    :cond_8
    move-wide v0, p2

    :goto_9
    return-wide v0
.end method

.method private static final maxOf-sambcqE(JJJ)J
    .registers 9
    .param p0, "a"  # J
    .param p2, "b"  # J
    .param p4, "c"  # J

    const/4 v0, 0x0

    .line 71
    .local v0, "$i$f$maxOf-sambcqE":I
    invoke-static {p2, p3, p4, p5}, Lkotlin/comparisons/UComparisonsKt;->maxOf-eb3DHEI(JJ)J

    move-result-wide v1

    invoke-static {p0, p1, v1, v2}, Lkotlin/comparisons/UComparisonsKt;->maxOf-eb3DHEI(JJ)J

    move-result-wide v1

    return-wide v1
.end method

.method public static final varargs maxOf-t1qELG4(S[S)S
    .registers 6
    .param p0, "a"  # S
    .param p1, "other"  # [S

    const-string v0, "other"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 133
    move v0, p0

    .line 134
    .local v0, "max":S
    array-length v1, p1

    const/4 v2, 0x0

    :goto_8
    if-ge v2, v1, :cond_13

    aget-short v3, p1, v2

    .local v3, "e":S
    invoke-static {v0, v3}, Lkotlin/comparisons/UComparisonsKt;->maxOf-5PvTz6A(SS)S

    move-result v0

    .end local v3  # "e":S
    add-int/lit8 v2, v2, 0x1

    goto :goto_8

    .line 135
    :cond_13
    return v0
.end method

.method public static final minOf-5PvTz6A(SS)S
    .registers 4
    .param p0, "a"  # S
    .param p1, "b"  # S

    .line 171
    const v0, 0xffff

    and-int v1, p0, v0

    and-int/2addr v0, p1

    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->compare(II)I

    move-result v0

    if-gtz v0, :cond_e

    move v0, p0

    goto :goto_f

    :cond_e
    move v0, p1

    :goto_f
    return v0
.end method

.method public static final minOf-J1ME1BU(II)I
    .registers 3
    .param p0, "a"  # I
    .param p1, "b"  # I

    .line 144
    invoke-static {p0, p1}, Lkotlin/UnsignedKt;->uintCompare(II)I

    move-result v0

    if-gtz v0, :cond_8

    move v0, p0

    goto :goto_9

    :cond_8
    move v0, p1

    :goto_9
    return v0
.end method

.method public static final minOf-Kr8caGY(BB)B
    .registers 4
    .param p0, "a"  # B
    .param p1, "b"  # B

    .line 162
    and-int/lit16 v0, p0, 0xff

    and-int/lit16 v1, p1, 0xff

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->compare(II)I

    move-result v0

    if-gtz v0, :cond_c

    move v0, p0

    goto :goto_d

    :cond_c
    move v0, p1

    :goto_d
    return v0
.end method

.method public static final varargs minOf-Md2H83M(I[I)I
    .registers 6
    .param p0, "a"  # I
    .param p1, "other"  # [I

    const-string v0, "other"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 220
    move v0, p0

    .line 221
    .local v0, "min":I
    array-length v1, p1

    const/4 v2, 0x0

    :goto_8
    if-ge v2, v1, :cond_13

    aget v3, p1, v2

    .local v3, "e":I
    invoke-static {v0, v3}, Lkotlin/comparisons/UComparisonsKt;->minOf-J1ME1BU(II)I

    move-result v0

    .end local v3  # "e":I
    add-int/lit8 v2, v2, 0x1

    goto :goto_8

    .line 222
    :cond_13
    return v0
.end method

.method public static final varargs minOf-R03FKyM(J[J)J
    .registers 9
    .param p0, "a"  # J
    .param p2, "other"  # [J

    const-string v0, "other"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 231
    move-wide v0, p0

    .line 232
    .local v0, "min":J
    array-length v2, p2

    const/4 v3, 0x0

    :goto_8
    if-ge v3, v2, :cond_13

    aget-wide v4, p2, v3

    .local v4, "e":J
    invoke-static {v0, v1, v4, v5}, Lkotlin/comparisons/UComparisonsKt;->minOf-eb3DHEI(JJ)J

    move-result-wide v0

    .end local v4  # "e":J
    add-int/lit8 v3, v3, 0x1

    goto :goto_8

    .line 233
    :cond_13
    return-wide v0
.end method

.method private static final minOf-VKSA0NQ(SSS)S
    .registers 5
    .param p0, "a"  # S
    .param p1, "b"  # S
    .param p2, "c"  # S

    const/4 v0, 0x0

    .line 211
    .local v0, "$i$f$minOf-VKSA0NQ":I
    invoke-static {p1, p2}, Lkotlin/comparisons/UComparisonsKt;->minOf-5PvTz6A(SS)S

    move-result v1

    invoke-static {p0, v1}, Lkotlin/comparisons/UComparisonsKt;->minOf-5PvTz6A(SS)S

    move-result v1

    return v1
.end method

.method private static final minOf-WZ9TVnA(III)I
    .registers 5
    .param p0, "a"  # I
    .param p1, "b"  # I
    .param p2, "c"  # I

    const/4 v0, 0x0

    .line 181
    .local v0, "$i$f$minOf-WZ9TVnA":I
    invoke-static {p1, p2}, Lkotlin/comparisons/UComparisonsKt;->minOf-J1ME1BU(II)I

    move-result v1

    invoke-static {p0, v1}, Lkotlin/comparisons/UComparisonsKt;->minOf-J1ME1BU(II)I

    move-result v1

    return v1
.end method

.method public static final varargs minOf-Wr6uiD8(B[B)B
    .registers 6
    .param p0, "a"  # B
    .param p1, "other"  # [B

    const-string v0, "other"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 242
    move v0, p0

    .line 243
    .local v0, "min":B
    array-length v1, p1

    const/4 v2, 0x0

    :goto_8
    if-ge v2, v1, :cond_13

    aget-byte v3, p1, v2

    .local v3, "e":B
    invoke-static {v0, v3}, Lkotlin/comparisons/UComparisonsKt;->minOf-Kr8caGY(BB)B

    move-result v0

    .end local v3  # "e":B
    add-int/lit8 v2, v2, 0x1

    goto :goto_8

    .line 244
    :cond_13
    return v0
.end method

.method private static final minOf-b33U2AM(BBB)B
    .registers 5
    .param p0, "a"  # B
    .param p1, "b"  # B
    .param p2, "c"  # B

    const/4 v0, 0x0

    .line 201
    .local v0, "$i$f$minOf-b33U2AM":I
    invoke-static {p1, p2}, Lkotlin/comparisons/UComparisonsKt;->minOf-Kr8caGY(BB)B

    move-result v1

    invoke-static {p0, v1}, Lkotlin/comparisons/UComparisonsKt;->minOf-Kr8caGY(BB)B

    move-result v1

    return v1
.end method

.method public static final minOf-eb3DHEI(JJ)J
    .registers 6
    .param p0, "a"  # J
    .param p2, "b"  # J

    .line 153
    invoke-static {p0, p1, p2, p3}, Lkotlin/UnsignedKt;->ulongCompare(JJ)I

    move-result v0

    if-gtz v0, :cond_8

    move-wide v0, p0

    goto :goto_9

    :cond_8
    move-wide v0, p2

    :goto_9
    return-wide v0
.end method

.method private static final minOf-sambcqE(JJJ)J
    .registers 9
    .param p0, "a"  # J
    .param p2, "b"  # J
    .param p4, "c"  # J

    const/4 v0, 0x0

    .line 191
    .local v0, "$i$f$minOf-sambcqE":I
    invoke-static {p2, p3, p4, p5}, Lkotlin/comparisons/UComparisonsKt;->minOf-eb3DHEI(JJ)J

    move-result-wide v1

    invoke-static {p0, p1, v1, v2}, Lkotlin/comparisons/UComparisonsKt;->minOf-eb3DHEI(JJ)J

    move-result-wide v1

    return-wide v1
.end method

.method public static final varargs minOf-t1qELG4(S[S)S
    .registers 6
    .param p0, "a"  # S
    .param p1, "other"  # [S

    const-string v0, "other"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 253
    move v0, p0

    .line 254
    .local v0, "min":S
    array-length v1, p1

    const/4 v2, 0x0

    :goto_8
    if-ge v2, v1, :cond_13

    aget-short v3, p1, v2

    .local v3, "e":S
    invoke-static {v0, v3}, Lkotlin/comparisons/UComparisonsKt;->minOf-5PvTz6A(SS)S

    move-result v0

    .end local v3  # "e":S
    add-int/lit8 v2, v2, 0x1

    goto :goto_8

    .line 255
    :cond_13
    return v0
.end method
