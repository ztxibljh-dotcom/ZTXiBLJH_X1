.class public interface abstract Lkotlin/contracts/Returns;
.super Ljava/lang/Object;
.source "Effect.kt"

# interfaces
.implements Lkotlin/contracts/SimpleEffect;


# annotations
.annotation runtime Lkotlin/Metadata;
    bv = {
        0x1,
        0x0,
        0x3
    }
    d1 = {
        "\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\bg\u0018\u00002\u00020\u0001¨\u0006\u0002"
    }
    d2 = {
        "Lkotlin/contracts/Returns;",
        "Lkotlin/contracts/SimpleEffect;",
        "kotlin-stdlib"
    }
    k = 0x1
    mv = {
        0x1,
        0x4,
        0x0
    }
.end annotation
