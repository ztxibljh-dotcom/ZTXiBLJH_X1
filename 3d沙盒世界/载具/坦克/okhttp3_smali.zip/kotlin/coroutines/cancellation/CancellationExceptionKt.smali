.class public final Lkotlin/coroutines/cancellation/CancellationExceptionKt;
.super Ljava/lang/Object;
.source "CancellationException.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nCancellationException.kt\nKotlin\n*S Kotlin\n*F\n+ 1 CancellationException.kt\nkotlin/coroutines/cancellation/CancellationExceptionKt\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,25:1\n1#2:26\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    bv = {
        0x1,
        0x0,
        0x3
    }
    d1 = {
        "\u0000\"\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\u001a!\u0010\u0000\u001a\u00060\u0001j\u0002`\u00022\b\u0010\u0003\u001a\u0004\u0018\u00010\u00042\b\u0010\u0005\u001a\u0004\u0018\u00010\u0006H\u0087\b\u001a\u0017\u0010\u0000\u001a\u00060\u0001j\u0002`\u00022\b\u0010\u0005\u001a\u0004\u0018\u00010\u0006H\u0087\b*\u001e\b\u0007\u0010\u0000\"\u00020\u00012\u00020\u0001B\u0002\b\u0007B\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\n¨\u0006\u000b"
    }
    d2 = {
        "CancellationException",
        "Ljava/util/concurrent/CancellationException;",
        "Lkotlin/coroutines/cancellation/CancellationException;",
        "message",
        "",
        "cause",
        "",
        "Lkotlin/ExperimentalStdlibApi;",
        "Lkotlin/SinceKotlin;",
        "version",
        "1.4",
        "kotlin-stdlib"
    }
    k = 0x2
    mv = {
        0x1,
        0x4,
        0x0
    }
.end annotation


# direct methods
.method private static final CancellationException(Ljava/lang/String;Ljava/lang/Throwable;)Ljava/util/concurrent/CancellationException;
    .registers 6
    .param p0, "message"  # Ljava/lang/String;
    .param p1, "cause"  # Ljava/lang/Throwable;

    const/4 v0, 0x0

    .line 18
    .local v0, "$i$f$CancellationException":I
    new-instance v1, Ljava/util/concurrent/CancellationException;

    invoke-direct {v1, p0}, Ljava/util/concurrent/CancellationException;-><init>(Ljava/lang/String;)V

    move-object v2, v1

    .line 26
    .local v2, "it":Ljava/util/concurrent/CancellationException;
    const/4 v3, 0x0

    .line 18
    .local v3, "$i$a$-also-CancellationExceptionKt$CancellationException$1":I
    invoke-virtual {v2, p1}, Ljava/util/concurrent/CancellationException;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    .end local v2  # "it":Ljava/util/concurrent/CancellationException;
    .end local v3  # "$i$a$-also-CancellationExceptionKt$CancellationException$1":I
    return-object v1
.end method

.method private static final CancellationException(Ljava/lang/Throwable;)Ljava/util/concurrent/CancellationException;
    .registers 5
    .param p0, "cause"  # Ljava/lang/Throwable;

    const/4 v0, 0x0

    .line 24
    .local v0, "$i$f$CancellationException":I
    new-instance v1, Ljava/util/concurrent/CancellationException;

    if-eqz p0, :cond_a

    invoke-virtual {p0}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object v2

    goto :goto_b

    :cond_a
    const/4 v2, 0x0

    :goto_b
    invoke-direct {v1, v2}, Ljava/util/concurrent/CancellationException;-><init>(Ljava/lang/String;)V

    move-object v2, v1

    .line 26
    .local v2, "it":Ljava/util/concurrent/CancellationException;
    const/4 v3, 0x0

    .line 24
    .local v3, "$i$a$-also-CancellationExceptionKt$CancellationException$2":I
    invoke-virtual {v2, p0}, Ljava/util/concurrent/CancellationException;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    .end local v2  # "it":Ljava/util/concurrent/CancellationException;
    .end local v3  # "$i$a$-also-CancellationExceptionKt$CancellationException$2":I
    return-object v1
.end method

.method public static synthetic CancellationException$annotations()V
    .registers 0

    return-void
.end method
