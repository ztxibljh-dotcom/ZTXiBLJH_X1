.class public final Lkotlin/io/CloseableKt;
.super Ljava/lang/Object;
.source "Closeable.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    bv = {
        0x1,
        0x0,
        0x3
    }
    d1 = {
        "\u0000\u001c\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0003\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\u001a\u0018\u0010\u0000\u001a\u00020\u0001*\u0004\u0018\u00010\u00022\b\u0010\u0003\u001a\u0004\u0018\u00010\u0004H\u0001\u001aK\u0010\u0005\u001a\u0002H\u0006\"\n\b\u0000\u0010\u0007*\u0004\u0018\u00010\u0002\"\u0004\b\u0001\u0010\u0006*\u0002H\u00072\u0012\u0010\b\u001a\u000e\u0012\u0004\u0012\u0002H\u0007\u0012\u0004\u0012\u0002H\u00060\tH\u0087\bø\u0001\u0000ø\u0001\u0001\u0082\u0002\n\n\b\b\u0001\u0012\u0002\u0010\u0001 \u0001¢\u0006\u0002\u0010\u000b\u0082\u0002\u000f\n\u0006\b\u0011(\n0\u0001\n\u0005\b\u009920\u0001¨\u0006\f"
    }
    d2 = {
        "closeFinally",
        "",
        "Ljava/io/Closeable;",
        "cause",
        "",
        "use",
        "R",
        "T",
        "block",
        "Lkotlin/Function1;",
        "Requires newer compiler version to be inlined correctly.",
        "(Ljava/io/Closeable;Lkotlin/jvm/functions/Function1;)Ljava/lang/Object;",
        "kotlin-stdlib"
    }
    k = 0x2
    mv = {
        0x1,
        0x4,
        0x0
    }
.end annotation


# direct methods
.method public static final closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    .registers 3
    .param p0, "$this$closeFinally"  # Ljava/io/Closeable;
    .param p1, "cause"  # Ljava/lang/Throwable;

    .line 55
    nop

    .line 56
    if-nez p0, :cond_4

    goto :goto_13

    .line 57
    :cond_4
    if-nez p1, :cond_a

    invoke-interface {p0}, Ljava/io/Closeable;->close()V

    goto :goto_13

    .line 59
    :cond_a
    nop

    .line 60
    :try_start_b
    invoke-interface {p0}, Ljava/io/Closeable;->close()V
    :try_end_e
    .catchall {:try_start_b .. :try_end_e} :catchall_f

    goto :goto_13

    .line 61
    :catchall_f
    move-exception v0

    .line 62
    .local v0, "closeException":Ljava/lang/Throwable;
    invoke-static {p1, v0}, Lkotlin/ExceptionsKt;->addSuppressed(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    .line 63
    .end local v0  # "closeException":Ljava/lang/Throwable;
    :goto_13
    nop

    .line 64
    return-void
.end method

.method private static final use(Ljava/io/Closeable;Lkotlin/jvm/functions/Function1;)Ljava/lang/Object;
    .registers 7
    .param p0, "$this$use"  # Ljava/io/Closeable;
    .param p1, "block"  # Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T::",
            "Ljava/io/Closeable;",
            "R:",
            "Ljava/lang/Object;",
            ">(TT;",
            "Lkotlin/jvm/functions/Function1<",
            "-TT;+TR;>;)TR;"
        }
    .end annotation

    const/4 v0, 0x0

    .line 23
    .local v0, "$i$f$use":I
    nop

    .line 26
    const/4 v1, 0x0

    check-cast v1, Ljava/lang/Throwable;

    .line 27
    .local v1, "exception":Ljava/lang/Throwable;
    nop

    .line 28
    const/4 v2, 0x0

    const/4 v3, 0x1

    :try_start_8
    invoke-interface {p1, p0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4
    :try_end_c
    .catchall {:try_start_8 .. :try_end_c} :catchall_25

    invoke-static {v3}, Lkotlin/jvm/internal/InlineMarker;->finallyStart(I)V

    .line 33
    nop

    .line 34
    invoke-static {v3, v3, v2}, Lkotlin/internal/PlatformImplementationsKt;->apiVersionIsAtLeast(III)Z

    move-result v2

    if-eqz v2, :cond_1a

    invoke-static {p0, v1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    goto :goto_20

    .line 35
    :cond_1a
    if-nez p0, :cond_1d

    goto :goto_20

    .line 36
    :cond_1d
    invoke-interface {p0}, Ljava/io/Closeable;->close()V

    .line 42
    :goto_20
    nop

    .line 43
    invoke-static {v3}, Lkotlin/jvm/internal/InlineMarker;->finallyEnd(I)V

    .line 28
    return-object v4

    .line 42
    :catchall_25
    move-exception v4

    .line 29
    nop

    .line 30
    .local v4, "e":Ljava/lang/Throwable;
    move-object v1, v4

    .line 31
    nop

    .end local v0  # "$i$f$use":I
    .end local v1  # "exception":Ljava/lang/Throwable;
    .end local p0  # "$this$use":Ljava/io/Closeable;
    .end local p1  # "block":Lkotlin/jvm/functions/Function1;
    :try_start_29
    throw v4
    :try_end_2a
    .catchall {:try_start_29 .. :try_end_2a} :catchall_2a

    .line 42
    .end local v4  # "e":Ljava/lang/Throwable;
    .restart local v0  # "$i$f$use":I
    .restart local v1  # "exception":Ljava/lang/Throwable;
    .restart local p0  # "$this$use":Ljava/io/Closeable;
    .restart local p1  # "block":Lkotlin/jvm/functions/Function1;
    :catchall_2a
    move-exception v4

    .line 44
    invoke-static {v3}, Lkotlin/jvm/internal/InlineMarker;->finallyStart(I)V

    .line 33
    nop

    .line 34
    invoke-static {v3, v3, v2}, Lkotlin/internal/PlatformImplementationsKt;->apiVersionIsAtLeast(III)Z

    move-result v2

    if-nez v2, :cond_3f

    .line 35
    if-eqz p0, :cond_42

    .line 36
    nop

    .line 38
    nop

    .line 39
    :try_start_39
    invoke-interface {p0}, Ljava/io/Closeable;->close()V
    :try_end_3c
    .catchall {:try_start_39 .. :try_end_3c} :catchall_3d

    goto :goto_42

    .line 40
    :catchall_3d
    move-exception v2

    goto :goto_42

    .line 34
    :cond_3f
    invoke-static {p0, v1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 42
    :cond_42
    :goto_42
    nop

    .line 43
    invoke-static {v3}, Lkotlin/jvm/internal/InlineMarker;->finallyEnd(I)V

    throw v4
.end method
