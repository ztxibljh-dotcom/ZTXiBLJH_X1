.class Lkotlin/io/FilesKt__FileReadWriteKt;
.super Lkotlin/io/FilesKt__FilePathComponentsKt;
.source "FileReadWrite.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nFileReadWrite.kt\nKotlin\n*S Kotlin\n*F\n+ 1 FileReadWrite.kt\nkotlin/io/FilesKt__FileReadWriteKt\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,233:1\n1#2:234\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    bv = {
        0x1,
        0x0,
        0x3
    }
    d1 = {
        "\u0000z\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0012\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\u001a\u0012\u0010\u0000\u001a\u00020\u0001*\u00020\u00022\u0006\u0010\u0003\u001a\u00020\u0004\u001a\u001c\u0010\u0005\u001a\u00020\u0001*\u00020\u00022\u0006\u0010\u0006\u001a\u00020\u00072\b\b\u0002\u0010\b\u001a\u00020\t\u001a!\u0010\n\u001a\u00020\u000b*\u00020\u00022\b\b\u0002\u0010\b\u001a\u00020\t2\b\b\u0002\u0010\f\u001a\u00020\rH\u0087\b\u001a!\u0010\u000e\u001a\u00020\u000f*\u00020\u00022\b\b\u0002\u0010\b\u001a\u00020\t2\b\b\u0002\u0010\f\u001a\u00020\rH\u0087\b\u001aB\u0010\u0010\u001a\u00020\u0001*\u00020\u000226\u0010\u0011\u001a2\u0012\u0013\u0012\u00110\u0004¢\u0006\f\b\u0013\u0012\b\b\u0014\u0012\u0004\b\b(\u0015\u0012\u0013\u0012\u00110\r¢\u0006\f\b\u0013\u0012\b\b\u0014\u0012\u0004\b\b(\u0016\u0012\u0004\u0012\u00020\u00010\u0012\u001aJ\u0010\u0010\u001a\u00020\u0001*\u00020\u00022\u0006\u0010\u0017\u001a\u00020\r26\u0010\u0011\u001a2\u0012\u0013\u0012\u00110\u0004¢\u0006\f\b\u0013\u0012\b\b\u0014\u0012\u0004\b\b(\u0015\u0012\u0013\u0012\u00110\r¢\u0006\f\b\u0013\u0012\b\b\u0014\u0012\u0004\b\b(\u0016\u0012\u0004\u0012\u00020\u00010\u0012\u001a7\u0010\u0018\u001a\u00020\u0001*\u00020\u00022\b\b\u0002\u0010\b\u001a\u00020\t2!\u0010\u0011\u001a\u001d\u0012\u0013\u0012\u00110\u0007¢\u0006\f\b\u0013\u0012\b\b\u0014\u0012\u0004\b\b(\u001a\u0012\u0004\u0012\u00020\u00010\u0019\u001a\r\u0010\u001b\u001a\u00020\u001c*\u00020\u0002H\u0087\b\u001a\r\u0010\u001d\u001a\u00020\u001e*\u00020\u0002H\u0087\b\u001a\u0017\u0010\u001f\u001a\u00020 *\u00020\u00022\b\b\u0002\u0010\b\u001a\u00020\tH\u0087\b\u001a\n\u0010!\u001a\u00020\u0004*\u00020\u0002\u001a\u001a\u0010\"\u001a\b\u0012\u0004\u0012\u00020\u00070#*\u00020\u00022\b\b\u0002\u0010\b\u001a\u00020\t\u001a\u0014\u0010$\u001a\u00020\u0007*\u00020\u00022\b\b\u0002\u0010\b\u001a\u00020\t\u001a\u0017\u0010%\u001a\u00020&*\u00020\u00022\b\b\u0002\u0010\b\u001a\u00020\tH\u0087\b\u001aB\u0010\'\u001a\u0002H(\"\u0004\b\u0000\u0010(*\u00020\u00022\b\b\u0002\u0010\b\u001a\u00020\t2\u0018\u0010)\u001a\u0014\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00070*\u0012\u0004\u0012\u0002H(0\u0019H\u0086\bø\u0001\u0000ø\u0001\u0001¢\u0006\u0002\u0010,\u001a\u0012\u0010-\u001a\u00020\u0001*\u00020\u00022\u0006\u0010\u0003\u001a\u00020\u0004\u001a\u001c\u0010.\u001a\u00020\u0001*\u00020\u00022\u0006\u0010\u0006\u001a\u00020\u00072\b\b\u0002\u0010\b\u001a\u00020\t\u001a\u0017\u0010/\u001a\u000200*\u00020\u00022\b\b\u0002\u0010\b\u001a\u00020\tH\u0087\b\u0082\u0002\u000f\n\u0006\b\u0011(+0\u0001\n\u0005\b\u009920\u0001¨\u00061"
    }
    d2 = {
        "appendBytes",
        "",
        "Ljava/io/File;",
        "array",
        "",
        "appendText",
        "text",
        "",
        "charset",
        "Ljava/nio/charset/Charset;",
        "bufferedReader",
        "Ljava/io/BufferedReader;",
        "bufferSize",
        "",
        "bufferedWriter",
        "Ljava/io/BufferedWriter;",
        "forEachBlock",
        "action",
        "Lkotlin/Function2;",
        "Lkotlin/ParameterName;",
        "name",
        "buffer",
        "bytesRead",
        "blockSize",
        "forEachLine",
        "Lkotlin/Function1;",
        "line",
        "inputStream",
        "Ljava/io/FileInputStream;",
        "outputStream",
        "Ljava/io/FileOutputStream;",
        "printWriter",
        "Ljava/io/PrintWriter;",
        "readBytes",
        "readLines",
        "",
        "readText",
        "reader",
        "Ljava/io/InputStreamReader;",
        "useLines",
        "T",
        "block",
        "Lkotlin/sequences/Sequence;",
        "Requires newer compiler version to be inlined correctly.",
        "(Ljava/io/File;Ljava/nio/charset/Charset;Lkotlin/jvm/functions/Function1;)Ljava/lang/Object;",
        "writeBytes",
        "writeText",
        "writer",
        "Ljava/io/OutputStreamWriter;",
        "kotlin-stdlib"
    }
    k = 0x5
    mv = {
        0x1,
        0x4,
        0x0
    }
    xi = 0x1
    xs = "kotlin/io/FilesKt"
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Lkotlin/io/FilesKt__FilePathComponentsKt;-><init>()V

    return-void
.end method

.method public static final appendBytes(Ljava/io/File;[B)V
    .registers 6
    .param p0, "$this$appendBytes"  # Ljava/io/File;
    .param p1, "array"  # [B

    const-string v0, "$this$appendBytes"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "array"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 115
    new-instance v0, Ljava/io/FileOutputStream;

    const/4 v1, 0x1

    invoke-direct {v0, p0, v1}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;Z)V

    check-cast v0, Ljava/io/Closeable;

    const/4 v1, 0x0

    move-object v2, v1

    check-cast v2, Ljava/lang/Throwable;

    :try_start_16
    move-object v2, v0

    check-cast v2, Ljava/io/FileOutputStream;

    .line 234
    .local v2, "it":Ljava/io/FileOutputStream;
    const/4 v3, 0x0

    .line 115
    .local v3, "$i$a$-use-FilesKt__FileReadWriteKt$appendBytes$1":I
    invoke-virtual {v2, p1}, Ljava/io/FileOutputStream;->write([B)V

    .end local v2  # "it":Ljava/io/FileOutputStream;
    .end local v3  # "$i$a$-use-FilesKt__FileReadWriteKt$appendBytes$1":I
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_1f
    .catchall {:try_start_16 .. :try_end_1f} :catchall_23

    invoke-static {v0, v1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    return-void

    :catchall_23
    move-exception v1

    .end local p0  # "$this$appendBytes":Ljava/io/File;
    .end local p1  # "array":[B
    :try_start_24
    throw v1
    :try_end_25
    .catchall {:try_start_24 .. :try_end_25} :catchall_25

    .restart local p0  # "$this$appendBytes":Ljava/io/File;
    .restart local p1  # "array":[B
    :catchall_25
    move-exception v2

    invoke-static {v0, v1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v2
.end method

.method public static final appendText(Ljava/io/File;Ljava/lang/String;Ljava/nio/charset/Charset;)V
    .registers 5
    .param p0, "$this$appendText"  # Ljava/io/File;
    .param p1, "text"  # Ljava/lang/String;
    .param p2, "charset"  # Ljava/nio/charset/Charset;

    const-string v0, "$this$appendText"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "text"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "charset"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 142
    invoke-virtual {p1, p2}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v0

    const-string v1, "(this as java.lang.String).getBytes(charset)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p0, v0}, Lkotlin/io/FilesKt;->appendBytes(Ljava/io/File;[B)V

    return-void
.end method

.method public static synthetic appendText$default(Ljava/io/File;Ljava/lang/String;Ljava/nio/charset/Charset;ILjava/lang/Object;)V
    .registers 5

    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_6

    .line 142
    sget-object p2, Lkotlin/text/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    :cond_6
    invoke-static {p0, p1, p2}, Lkotlin/io/FilesKt;->appendText(Ljava/io/File;Ljava/lang/String;Ljava/nio/charset/Charset;)V

    return-void
.end method

.method private static final bufferedReader(Ljava/io/File;Ljava/nio/charset/Charset;I)Ljava/io/BufferedReader;
    .registers 6
    .param p0, "$this$bufferedReader"  # Ljava/io/File;
    .param p1, "charset"  # Ljava/nio/charset/Charset;
    .param p2, "bufferSize"  # I

    const/4 v0, 0x0

    .line 31
    .local v0, "$i$f$bufferedReader":I
    new-instance v1, Ljava/io/FileInputStream;

    invoke-direct {v1, p0}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    check-cast v1, Ljava/io/InputStream;

    new-instance v2, Ljava/io/InputStreamReader;

    invoke-direct {v2, v1, p1}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;Ljava/nio/charset/Charset;)V

    check-cast v2, Ljava/io/Reader;

    instance-of v1, v2, Ljava/io/BufferedReader;

    if-eqz v1, :cond_16

    check-cast v2, Ljava/io/BufferedReader;

    goto :goto_1c

    :cond_16
    new-instance v1, Ljava/io/BufferedReader;

    invoke-direct {v1, v2, p2}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;I)V

    move-object v2, v1

    :goto_1c
    return-object v2
.end method

.method static synthetic bufferedReader$default(Ljava/io/File;Ljava/nio/charset/Charset;IILjava/lang/Object;)Ljava/io/BufferedReader;
    .registers 6
    .param p0, "$this$bufferedReader"  # Ljava/io/File;
    .param p1, "charset"  # Ljava/nio/charset/Charset;
    .param p2, "bufferSize"  # I

    and-int/lit8 p4, p3, 0x1

    if-eqz p4, :cond_6

    .line 30
    sget-object p1, Lkotlin/text/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    :cond_6
    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_c

    const/16 p2, 0x2000

    :cond_c
    const/4 p3, 0x0

    .line 31
    .local p3, "$i$f$bufferedReader":I
    new-instance p4, Ljava/io/FileInputStream;

    invoke-direct {p4, p0}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    check-cast p4, Ljava/io/InputStream;

    new-instance v0, Ljava/io/InputStreamReader;

    invoke-direct {v0, p4, p1}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;Ljava/nio/charset/Charset;)V

    check-cast v0, Ljava/io/Reader;

    instance-of p4, v0, Ljava/io/BufferedReader;

    if-eqz p4, :cond_22

    check-cast v0, Ljava/io/BufferedReader;

    goto :goto_28

    :cond_22
    new-instance p4, Ljava/io/BufferedReader;

    invoke-direct {p4, v0, p2}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;I)V

    move-object v0, p4

    :goto_28
    return-object v0
.end method

.method private static final bufferedWriter(Ljava/io/File;Ljava/nio/charset/Charset;I)Ljava/io/BufferedWriter;
    .registers 6
    .param p0, "$this$bufferedWriter"  # Ljava/io/File;
    .param p1, "charset"  # Ljava/nio/charset/Charset;
    .param p2, "bufferSize"  # I

    const/4 v0, 0x0

    .line 47
    .local v0, "$i$f$bufferedWriter":I
    new-instance v1, Ljava/io/FileOutputStream;

    invoke-direct {v1, p0}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    check-cast v1, Ljava/io/OutputStream;

    new-instance v2, Ljava/io/OutputStreamWriter;

    invoke-direct {v2, v1, p1}, Ljava/io/OutputStreamWriter;-><init>(Ljava/io/OutputStream;Ljava/nio/charset/Charset;)V

    check-cast v2, Ljava/io/Writer;

    instance-of v1, v2, Ljava/io/BufferedWriter;

    if-eqz v1, :cond_16

    check-cast v2, Ljava/io/BufferedWriter;

    goto :goto_1c

    :cond_16
    new-instance v1, Ljava/io/BufferedWriter;

    invoke-direct {v1, v2, p2}, Ljava/io/BufferedWriter;-><init>(Ljava/io/Writer;I)V

    move-object v2, v1

    :goto_1c
    return-object v2
.end method

.method static synthetic bufferedWriter$default(Ljava/io/File;Ljava/nio/charset/Charset;IILjava/lang/Object;)Ljava/io/BufferedWriter;
    .registers 6
    .param p0, "$this$bufferedWriter"  # Ljava/io/File;
    .param p1, "charset"  # Ljava/nio/charset/Charset;
    .param p2, "bufferSize"  # I

    and-int/lit8 p4, p3, 0x1

    if-eqz p4, :cond_6

    .line 46
    sget-object p1, Lkotlin/text/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    :cond_6
    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_c

    const/16 p2, 0x2000

    :cond_c
    const/4 p3, 0x0

    .line 47
    .local p3, "$i$f$bufferedWriter":I
    new-instance p4, Ljava/io/FileOutputStream;

    invoke-direct {p4, p0}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    check-cast p4, Ljava/io/OutputStream;

    new-instance v0, Ljava/io/OutputStreamWriter;

    invoke-direct {v0, p4, p1}, Ljava/io/OutputStreamWriter;-><init>(Ljava/io/OutputStream;Ljava/nio/charset/Charset;)V

    check-cast v0, Ljava/io/Writer;

    instance-of p4, v0, Ljava/io/BufferedWriter;

    if-eqz p4, :cond_22

    check-cast v0, Ljava/io/BufferedWriter;

    goto :goto_28

    :cond_22
    new-instance p4, Ljava/io/BufferedWriter;

    invoke-direct {p4, v0, p2}, Ljava/io/BufferedWriter;-><init>(Ljava/io/Writer;I)V

    move-object v0, p4

    :goto_28
    return-object v0
.end method

.method public static final forEachBlock(Ljava/io/File;ILkotlin/jvm/functions/Function2;)V
    .registers 10
    .param p0, "$this$forEachBlock"  # Ljava/io/File;
    .param p1, "blockSize"  # I
    .param p2, "action"  # Lkotlin/jvm/functions/Function2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/io/File;",
            "I",
            "Lkotlin/jvm/functions/Function2<",
            "-[B-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    const-string v0, "$this$forEachBlock"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "action"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 165
    const/16 v0, 0x200

    invoke-static {p1, v0}, Lkotlin/ranges/RangesKt;->coerceAtLeast(II)I

    move-result v0

    new-array v0, v0, [B

    .line 167
    .local v0, "arr":[B
    new-instance v1, Ljava/io/FileInputStream;

    invoke-direct {v1, p0}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    check-cast v1, Ljava/io/Closeable;

    const/4 v2, 0x0

    move-object v3, v2

    check-cast v3, Ljava/lang/Throwable;

    :try_start_1d
    move-object v3, v1

    check-cast v3, Ljava/io/FileInputStream;

    .local v3, "input":Ljava/io/FileInputStream;
    const/4 v4, 0x0

    .line 168
    .local v4, "$i$a$-use-FilesKt__FileReadWriteKt$forEachBlock$1":I
    :goto_21
    nop

    .line 169
    invoke-virtual {v3, v0}, Ljava/io/FileInputStream;->read([B)I

    move-result v5

    .line 170
    .local v5, "size":I
    if-gtz v5, :cond_30

    .line 171
    nop

    .line 176
    .end local v5  # "size":I
    nop

    .end local v3  # "input":Ljava/io/FileInputStream;
    .end local v4  # "$i$a$-use-FilesKt__FileReadWriteKt$forEachBlock$1":I
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_2c
    .catchall {:try_start_1d .. :try_end_2c} :catchall_39

    .line 167
    invoke-static {v1, v2}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 177
    return-void

    .line 173
    .restart local v3  # "input":Ljava/io/FileInputStream;
    .restart local v4  # "$i$a$-use-FilesKt__FileReadWriteKt$forEachBlock$1":I
    .restart local v5  # "size":I
    :cond_30
    :try_start_30
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-interface {p2, v0, v6}, Lkotlin/jvm/functions/Function2;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_37
    .catchall {:try_start_30 .. :try_end_37} :catchall_39

    .line 174
    nop

    .line 175
    goto :goto_21

    .line 167
    .end local v3  # "input":Ljava/io/FileInputStream;
    .end local v4  # "$i$a$-use-FilesKt__FileReadWriteKt$forEachBlock$1":I
    .end local v5  # "size":I
    :catchall_39
    move-exception v2

    .end local v0  # "arr":[B
    .end local p0  # "$this$forEachBlock":Ljava/io/File;
    .end local p1  # "blockSize":I
    .end local p2  # "action":Lkotlin/jvm/functions/Function2;
    :try_start_3a
    throw v2
    :try_end_3b
    .catchall {:try_start_3a .. :try_end_3b} :catchall_3b

    .restart local v0  # "arr":[B
    .restart local p0  # "$this$forEachBlock":Ljava/io/File;
    .restart local p1  # "blockSize":I
    .restart local p2  # "action":Lkotlin/jvm/functions/Function2;
    :catchall_3b
    move-exception v3

    invoke-static {v1, v2}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v3
.end method

.method public static final forEachBlock(Ljava/io/File;Lkotlin/jvm/functions/Function2;)V
    .registers 3
    .param p0, "$this$forEachBlock"  # Ljava/io/File;
    .param p1, "action"  # Lkotlin/jvm/functions/Function2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/io/File;",
            "Lkotlin/jvm/functions/Function2<",
            "-[B-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    const-string v0, "$this$forEachBlock"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "action"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 153
    const/16 v0, 0x1000

    invoke-static {p0, v0, p1}, Lkotlin/io/FilesKt;->forEachBlock(Ljava/io/File;ILkotlin/jvm/functions/Function2;)V

    return-void
.end method

.method public static final forEachLine(Ljava/io/File;Ljava/nio/charset/Charset;Lkotlin/jvm/functions/Function1;)V
    .registers 6
    .param p0, "$this$forEachLine"  # Ljava/io/File;
    .param p1, "charset"  # Ljava/nio/charset/Charset;
    .param p2, "action"  # Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/io/File;",
            "Ljava/nio/charset/Charset;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    const-string v0, "$this$forEachLine"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "charset"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "action"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 190
    new-instance v0, Ljava/io/BufferedReader;

    new-instance v1, Ljava/io/InputStreamReader;

    new-instance v2, Ljava/io/FileInputStream;

    invoke-direct {v2, p0}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    check-cast v2, Ljava/io/InputStream;

    invoke-direct {v1, v2, p1}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;Ljava/nio/charset/Charset;)V

    check-cast v1, Ljava/io/Reader;

    invoke-direct {v0, v1}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    check-cast v0, Ljava/io/Reader;

    invoke-static {v0, p2}, Lkotlin/io/TextStreamsKt;->forEachLine(Ljava/io/Reader;Lkotlin/jvm/functions/Function1;)V

    .line 191
    return-void
.end method

.method public static synthetic forEachLine$default(Ljava/io/File;Ljava/nio/charset/Charset;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)V
    .registers 5

    and-int/lit8 p3, p3, 0x1

    if-eqz p3, :cond_6

    .line 188
    sget-object p1, Lkotlin/text/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    :cond_6
    invoke-static {p0, p1, p2}, Lkotlin/io/FilesKt;->forEachLine(Ljava/io/File;Ljava/nio/charset/Charset;Lkotlin/jvm/functions/Function1;)V

    return-void
.end method

.method private static final inputStream(Ljava/io/File;)Ljava/io/FileInputStream;
    .registers 3
    .param p0, "$this$inputStream"  # Ljava/io/File;

    const/4 v0, 0x0

    .line 198
    .local v0, "$i$f$inputStream":I
    new-instance v1, Ljava/io/FileInputStream;

    invoke-direct {v1, p0}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    return-object v1
.end method

.method private static final outputStream(Ljava/io/File;)Ljava/io/FileOutputStream;
    .registers 3
    .param p0, "$this$outputStream"  # Ljava/io/File;

    const/4 v0, 0x0

    .line 206
    .local v0, "$i$f$outputStream":I
    new-instance v1, Ljava/io/FileOutputStream;

    invoke-direct {v1, p0}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    return-object v1
.end method

.method private static final printWriter(Ljava/io/File;Ljava/nio/charset/Charset;)Ljava/io/PrintWriter;
    .registers 7
    .param p0, "$this$printWriter"  # Ljava/io/File;
    .param p1, "charset"  # Ljava/nio/charset/Charset;

    const/4 v0, 0x0

    .line 54
    .local v0, "$i$f$printWriter":I
    new-instance v1, Ljava/io/PrintWriter;

    new-instance v2, Ljava/io/FileOutputStream;

    invoke-direct {v2, p0}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    check-cast v2, Ljava/io/OutputStream;

    new-instance v3, Ljava/io/OutputStreamWriter;

    invoke-direct {v3, v2, p1}, Ljava/io/OutputStreamWriter;-><init>(Ljava/io/OutputStream;Ljava/nio/charset/Charset;)V

    check-cast v3, Ljava/io/Writer;

    instance-of v2, v3, Ljava/io/BufferedWriter;

    if-eqz v2, :cond_18

    check-cast v3, Ljava/io/BufferedWriter;

    goto :goto_20

    :cond_18
    new-instance v2, Ljava/io/BufferedWriter;

    const/16 v4, 0x2000

    invoke-direct {v2, v3, v4}, Ljava/io/BufferedWriter;-><init>(Ljava/io/Writer;I)V

    move-object v3, v2

    :goto_20
    check-cast v3, Ljava/io/Writer;

    invoke-direct {v1, v3}, Ljava/io/PrintWriter;-><init>(Ljava/io/Writer;)V

    return-object v1
.end method

.method static synthetic printWriter$default(Ljava/io/File;Ljava/nio/charset/Charset;ILjava/lang/Object;)Ljava/io/PrintWriter;
    .registers 7
    .param p0, "$this$printWriter"  # Ljava/io/File;
    .param p1, "charset"  # Ljava/nio/charset/Charset;

    and-int/lit8 p2, p2, 0x1

    if-eqz p2, :cond_6

    .line 53
    sget-object p1, Lkotlin/text/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    :cond_6
    const/4 p2, 0x0

    .line 54
    .local p2, "$i$f$printWriter":I
    new-instance p3, Ljava/io/PrintWriter;

    new-instance v0, Ljava/io/FileOutputStream;

    invoke-direct {v0, p0}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    check-cast v0, Ljava/io/OutputStream;

    new-instance v1, Ljava/io/OutputStreamWriter;

    invoke-direct {v1, v0, p1}, Ljava/io/OutputStreamWriter;-><init>(Ljava/io/OutputStream;Ljava/nio/charset/Charset;)V

    check-cast v1, Ljava/io/Writer;

    instance-of v0, v1, Ljava/io/BufferedWriter;

    if-eqz v0, :cond_1e

    check-cast v1, Ljava/io/BufferedWriter;

    goto :goto_26

    :cond_1e
    new-instance v0, Ljava/io/BufferedWriter;

    const/16 v2, 0x2000

    invoke-direct {v0, v1, v2}, Ljava/io/BufferedWriter;-><init>(Ljava/io/Writer;I)V

    move-object v1, v0

    :goto_26
    check-cast v1, Ljava/io/Writer;

    invoke-direct {p3, v1}, Ljava/io/PrintWriter;-><init>(Ljava/io/Writer;)V

    return-object p3
.end method

.method public static final readBytes(Ljava/io/File;)[B
    .registers 16
    .param p0, "$this$readBytes"  # Ljava/io/File;

    const-string v0, "$this$readBytes"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 63
    new-instance v0, Ljava/io/FileInputStream;

    invoke-direct {v0, p0}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    check-cast v0, Ljava/io/Closeable;

    const/4 v1, 0x0

    move-object v2, v1

    check-cast v2, Ljava/lang/Throwable;

    :try_start_10
    move-object v2, v0

    check-cast v2, Ljava/io/FileInputStream;

    .local v2, "input":Ljava/io/FileInputStream;
    const/4 v3, 0x0

    .line 64
    .local v3, "$i$a$-use-FilesKt__FileReadWriteKt$readBytes$1":I
    const/4 v4, 0x0

    .line 65
    .local v4, "offset":I
    nop

    .line 67
    nop

    .line 65
    invoke-virtual {p0}, Ljava/io/File;->length()J

    move-result-wide v5
    :try_end_1b
    .catchall {:try_start_10 .. :try_end_1b} :catchall_cc

    move-wide v7, v5

    .local v7, "length":J
    const/4 v9, 0x0

    .line 66
    .local v9, "$i$a$-also-FilesKt__FileReadWriteKt$readBytes$1$remaining$1":I
    const v10, 0x7fffffff

    int-to-long v10, v10

    const-string v12, "File "

    cmp-long v13, v7, v10

    if-gtz v13, :cond_a3

    .line 67
    nop

    .line 65
    .end local v7  # "length":J
    .end local v9  # "$i$a$-also-FilesKt__FileReadWriteKt$readBytes$1$remaining$1":I
    nop

    .line 67
    long-to-int v6, v5

    .line 65
    move v5, v6

    .line 68
    .local v5, "remaining":I
    :try_start_2b
    new-array v6, v5, [B

    .line 69
    .local v6, "result":[B
    :goto_2d
    if-lez v5, :cond_39

    .line 70
    invoke-virtual {v2, v6, v4, v5}, Ljava/io/FileInputStream;->read([BII)I

    move-result v7
    :try_end_33
    .catchall {:try_start_2b .. :try_end_33} :catchall_cc

    .line 71
    .local v7, "read":I
    if-gez v7, :cond_36

    goto :goto_39

    .line 72
    :cond_36
    sub-int/2addr v5, v7

    .line 73
    add-int/2addr v4, v7

    .line 69
    .end local v7  # "read":I
    goto :goto_2d

    .line 75
    :cond_39
    :goto_39
    const-string v7, "java.util.Arrays.copyOf(this, newSize)"

    if-lez v5, :cond_46

    :try_start_3d
    invoke-static {v6, v4}, Ljava/util/Arrays;->copyOf([BI)[B

    move-result-object v8

    invoke-static {v8, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v6, v8

    goto :goto_80

    .line 77
    :cond_46
    invoke-virtual {v2}, Ljava/io/FileInputStream;->read()I

    move-result v8

    .line 78
    .local v8, "extraByte":I
    const/4 v9, -0x1

    if-ne v8, v9, :cond_4e

    goto :goto_80

    .line 84
    :cond_4e
    new-instance v9, Lkotlin/io/ExposingBufferByteArrayOutputStream;

    const/16 v10, 0x2001

    invoke-direct {v9, v10}, Lkotlin/io/ExposingBufferByteArrayOutputStream;-><init>(I)V

    .line 85
    .local v9, "extra":Lkotlin/io/ExposingBufferByteArrayOutputStream;
    invoke-virtual {v9, v8}, Lkotlin/io/ExposingBufferByteArrayOutputStream;->write(I)V

    .line 86
    move-object v10, v2

    check-cast v10, Ljava/io/InputStream;

    move-object v11, v9

    check-cast v11, Ljava/io/OutputStream;

    const/4 v13, 0x2

    const/4 v14, 0x0

    invoke-static {v10, v11, v14, v13, v1}, Lkotlin/io/ByteStreamsKt;->copyTo$default(Ljava/io/InputStream;Ljava/io/OutputStream;IILjava/lang/Object;)J

    .line 88
    array-length v10, v6

    invoke-virtual {v9}, Lkotlin/io/ExposingBufferByteArrayOutputStream;->size()I

    move-result v11

    add-int/2addr v10, v11

    .line 89
    .local v10, "resultingSize":I
    if-ltz v10, :cond_84

    .line 91
    invoke-virtual {v9}, Lkotlin/io/ExposingBufferByteArrayOutputStream;->getBuffer()[B

    move-result-object v11

    .line 92
    invoke-static {v6, v10}, Ljava/util/Arrays;->copyOf([BI)[B

    move-result-object v12

    invoke-static {v12, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 93
    array-length v7, v6

    .line 94
    invoke-virtual {v9}, Lkotlin/io/ExposingBufferByteArrayOutputStream;->size()I

    move-result v13

    .line 91
    invoke-static {v11, v12, v7, v14, v13}, Lkotlin/collections/ArraysKt;->copyInto([B[BIII)[B

    move-result-object v7
    :try_end_7f
    .catchall {:try_start_3d .. :try_end_7f} :catchall_cc

    move-object v6, v7

    .line 63
    .end local v2  # "input":Ljava/io/FileInputStream;
    .end local v3  # "$i$a$-use-FilesKt__FileReadWriteKt$readBytes$1":I
    .end local v4  # "offset":I
    .end local v5  # "remaining":I
    .end local v6  # "result":[B
    .end local v8  # "extraByte":I
    .end local v9  # "extra":Lkotlin/io/ExposingBufferByteArrayOutputStream;
    .end local v10  # "resultingSize":I
    :goto_80
    invoke-static {v0, v1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 96
    return-object v6

    .line 89
    .restart local v2  # "input":Ljava/io/FileInputStream;
    .restart local v3  # "$i$a$-use-FilesKt__FileReadWriteKt$readBytes$1":I
    .restart local v4  # "offset":I
    .restart local v5  # "remaining":I
    .restart local v6  # "result":[B
    .restart local v8  # "extraByte":I
    .restart local v9  # "extra":Lkotlin/io/ExposingBufferByteArrayOutputStream;
    .restart local v10  # "resultingSize":I
    :cond_84
    :try_start_84
    new-instance v1, Ljava/lang/OutOfMemoryError;

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v11, " is too big to fit in memory."

    invoke-virtual {v7, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-direct {v1, v7}, Ljava/lang/OutOfMemoryError;-><init>(Ljava/lang/String;)V

    check-cast v1, Ljava/lang/Throwable;

    .end local p0  # "$this$readBytes":Ljava/io/File;
    throw v1

    .line 66
    .end local v5  # "remaining":I
    .end local v6  # "result":[B
    .end local v8  # "extraByte":I
    .end local v10  # "resultingSize":I
    .local v7, "length":J
    .local v9, "$i$a$-also-FilesKt__FileReadWriteKt$readBytes$1$remaining$1":I
    .restart local p0  # "$this$readBytes":Ljava/io/File;
    :cond_a3
    new-instance v1, Ljava/lang/OutOfMemoryError;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, " is too big ("

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v7, v8}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, " bytes) to fit in memory."

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v1, v5}, Ljava/lang/OutOfMemoryError;-><init>(Ljava/lang/String;)V

    check-cast v1, Ljava/lang/Throwable;

    .end local p0  # "$this$readBytes":Ljava/io/File;
    throw v1
    :try_end_cc
    .catchall {:try_start_84 .. :try_end_cc} :catchall_cc

    .line 63
    .end local v2  # "input":Ljava/io/FileInputStream;
    .end local v3  # "$i$a$-use-FilesKt__FileReadWriteKt$readBytes$1":I
    .end local v4  # "offset":I
    .end local v7  # "length":J
    .end local v9  # "$i$a$-also-FilesKt__FileReadWriteKt$readBytes$1$remaining$1":I
    .restart local p0  # "$this$readBytes":Ljava/io/File;
    :catchall_cc
    move-exception v1

    .end local p0  # "$this$readBytes":Ljava/io/File;
    :try_start_cd
    throw v1
    :try_end_ce
    .catchall {:try_start_cd .. :try_end_ce} :catchall_ce

    .restart local p0  # "$this$readBytes":Ljava/io/File;
    :catchall_ce
    move-exception v2

    invoke-static {v0, v1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v2
.end method

.method public static final readLines(Ljava/io/File;Ljava/nio/charset/Charset;)Ljava/util/List;
    .registers 4
    .param p0, "$this$readLines"  # Ljava/io/File;
    .param p1, "charset"  # Ljava/nio/charset/Charset;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/io/File;",
            "Ljava/nio/charset/Charset;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const-string v0, "$this$readLines"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "charset"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 218
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 219
    .local v0, "result":Ljava/util/ArrayList;
    new-instance v1, Lkotlin/io/FilesKt__FileReadWriteKt$readLines$1;

    invoke-direct {v1, v0}, Lkotlin/io/FilesKt__FileReadWriteKt$readLines$1;-><init>(Ljava/util/ArrayList;)V

    check-cast v1, Lkotlin/jvm/functions/Function1;

    invoke-static {p0, p1, v1}, Lkotlin/io/FilesKt;->forEachLine(Ljava/io/File;Ljava/nio/charset/Charset;Lkotlin/jvm/functions/Function1;)V

    .line 220
    move-object v1, v0

    check-cast v1, Ljava/util/List;

    return-object v1
.end method

.method public static synthetic readLines$default(Ljava/io/File;Ljava/nio/charset/Charset;ILjava/lang/Object;)Ljava/util/List;
    .registers 4

    and-int/lit8 p2, p2, 0x1

    if-eqz p2, :cond_6

    .line 217
    sget-object p1, Lkotlin/text/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    :cond_6
    invoke-static {p0, p1}, Lkotlin/io/FilesKt;->readLines(Ljava/io/File;Ljava/nio/charset/Charset;)Ljava/util/List;

    move-result-object p0

    return-object p0
.end method

.method public static final readText(Ljava/io/File;Ljava/nio/charset/Charset;)Ljava/lang/String;
    .registers 7
    .param p0, "$this$readText"  # Ljava/io/File;
    .param p1, "charset"  # Ljava/nio/charset/Charset;

    const-string v0, "$this$readText"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "charset"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 125
    new-instance v0, Ljava/io/FileInputStream;

    invoke-direct {v0, p0}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    check-cast v0, Ljava/io/InputStream;

    new-instance v1, Ljava/io/InputStreamReader;

    invoke-direct {v1, v0, p1}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;Ljava/nio/charset/Charset;)V

    check-cast v1, Ljava/io/Closeable;

    const/4 v0, 0x0

    move-object v2, v0

    check-cast v2, Ljava/lang/Throwable;

    :try_start_1c
    move-object v2, v1

    check-cast v2, Ljava/io/InputStreamReader;

    .line 234
    .local v2, "it":Ljava/io/InputStreamReader;
    const/4 v3, 0x0

    .line 125
    .local v3, "$i$a$-use-FilesKt__FileReadWriteKt$readText$1":I
    move-object v4, v2

    check-cast v4, Ljava/io/Reader;

    invoke-static {v4}, Lkotlin/io/TextStreamsKt;->readText(Ljava/io/Reader;)Ljava/lang/String;

    move-result-object v4
    :try_end_27
    .catchall {:try_start_1c .. :try_end_27} :catchall_2b

    .end local v2  # "it":Ljava/io/InputStreamReader;
    .end local v3  # "$i$a$-use-FilesKt__FileReadWriteKt$readText$1":I
    invoke-static {v1, v0}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    return-object v4

    :catchall_2b
    move-exception v0

    .end local p0  # "$this$readText":Ljava/io/File;
    .end local p1  # "charset":Ljava/nio/charset/Charset;
    :try_start_2c
    throw v0
    :try_end_2d
    .catchall {:try_start_2c .. :try_end_2d} :catchall_2d

    .restart local p0  # "$this$readText":Ljava/io/File;
    .restart local p1  # "charset":Ljava/nio/charset/Charset;
    :catchall_2d
    move-exception v2

    invoke-static {v1, v0}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v2
.end method

.method public static synthetic readText$default(Ljava/io/File;Ljava/nio/charset/Charset;ILjava/lang/Object;)Ljava/lang/String;
    .registers 4

    and-int/lit8 p2, p2, 0x1

    if-eqz p2, :cond_6

    .line 125
    sget-object p1, Lkotlin/text/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    :cond_6
    invoke-static {p0, p1}, Lkotlin/io/FilesKt;->readText(Ljava/io/File;Ljava/nio/charset/Charset;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method private static final reader(Ljava/io/File;Ljava/nio/charset/Charset;)Ljava/io/InputStreamReader;
    .registers 5
    .param p0, "$this$reader"  # Ljava/io/File;
    .param p1, "charset"  # Ljava/nio/charset/Charset;

    const/4 v0, 0x0

    .line 22
    .local v0, "$i$f$reader":I
    new-instance v1, Ljava/io/FileInputStream;

    invoke-direct {v1, p0}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    check-cast v1, Ljava/io/InputStream;

    new-instance v2, Ljava/io/InputStreamReader;

    invoke-direct {v2, v1, p1}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;Ljava/nio/charset/Charset;)V

    return-object v2
.end method

.method static synthetic reader$default(Ljava/io/File;Ljava/nio/charset/Charset;ILjava/lang/Object;)Ljava/io/InputStreamReader;
    .registers 5
    .param p0, "$this$reader"  # Ljava/io/File;
    .param p1, "charset"  # Ljava/nio/charset/Charset;

    and-int/lit8 p2, p2, 0x1

    if-eqz p2, :cond_6

    .line 21
    sget-object p1, Lkotlin/text/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    :cond_6
    const/4 p2, 0x0

    .line 22
    .local p2, "$i$f$reader":I
    new-instance p3, Ljava/io/FileInputStream;

    invoke-direct {p3, p0}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    check-cast p3, Ljava/io/InputStream;

    new-instance v0, Ljava/io/InputStreamReader;

    invoke-direct {v0, p3, p1}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;Ljava/nio/charset/Charset;)V

    return-object v0
.end method

.method public static final useLines(Ljava/io/File;Ljava/nio/charset/Charset;Lkotlin/jvm/functions/Function1;)Ljava/lang/Object;
    .registers 11
    .param p0, "$this$useLines"  # Ljava/io/File;
    .param p1, "charset"  # Ljava/nio/charset/Charset;
    .param p2, "block"  # Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/io/File;",
            "Ljava/nio/charset/Charset;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Lkotlin/sequences/Sequence<",
            "Ljava/lang/String;",
            ">;+TT;>;)TT;"
        }
    .end annotation

    const/4 v0, 0x0

    .local v0, "$i$f$useLines":I
    const-string v1, "$this$useLines"

    invoke-static {p0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "charset"

    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "block"

    invoke-static {p2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 232
    new-instance v1, Ljava/io/FileInputStream;

    invoke-direct {v1, p0}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    check-cast v1, Ljava/io/InputStream;

    new-instance v2, Ljava/io/InputStreamReader;

    invoke-direct {v2, v1, p1}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;Ljava/nio/charset/Charset;)V

    check-cast v2, Ljava/io/Reader;

    instance-of v1, v2, Ljava/io/BufferedReader;

    if-eqz v1, :cond_25

    check-cast v2, Ljava/io/BufferedReader;

    goto :goto_2d

    :cond_25
    new-instance v1, Ljava/io/BufferedReader;

    const/16 v3, 0x2000

    invoke-direct {v1, v2, v3}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;I)V

    move-object v2, v1

    :goto_2d
    check-cast v2, Ljava/io/Closeable;

    const/4 v1, 0x0

    move-object v3, v1

    check-cast v3, Ljava/lang/Throwable;

    const/4 v3, 0x0

    const/4 v4, 0x1

    :try_start_35
    move-object v5, v2

    check-cast v5, Ljava/io/BufferedReader;

    .line 234
    .local v5, "it":Ljava/io/BufferedReader;
    const/4 v6, 0x0

    .line 232
    .local v6, "$i$a$-use-FilesKt__FileReadWriteKt$useLines$1":I
    invoke-static {v5}, Lkotlin/io/TextStreamsKt;->lineSequence(Ljava/io/BufferedReader;)Lkotlin/sequences/Sequence;

    move-result-object v7

    invoke-interface {p2, v7}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7
    :try_end_41
    .catchall {:try_start_35 .. :try_end_41} :catchall_55

    .end local v5  # "it":Ljava/io/BufferedReader;
    .end local v6  # "$i$a$-use-FilesKt__FileReadWriteKt$useLines$1":I
    invoke-static {v4}, Lkotlin/jvm/internal/InlineMarker;->finallyStart(I)V

    invoke-static {v4, v4, v3}, Lkotlin/internal/PlatformImplementationsKt;->apiVersionIsAtLeast(III)Z

    move-result v3

    if-eqz v3, :cond_4e

    invoke-static {v2, v1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    goto :goto_51

    :cond_4e
    invoke-interface {v2}, Ljava/io/Closeable;->close()V

    :goto_51
    invoke-static {v4}, Lkotlin/jvm/internal/InlineMarker;->finallyEnd(I)V

    return-object v7

    :catchall_55
    move-exception v1

    .end local v0  # "$i$f$useLines":I
    .end local p0  # "$this$useLines":Ljava/io/File;
    .end local p1  # "charset":Ljava/nio/charset/Charset;
    .end local p2  # "block":Lkotlin/jvm/functions/Function1;
    :try_start_56
    throw v1
    :try_end_57
    .catchall {:try_start_56 .. :try_end_57} :catchall_57

    .restart local v0  # "$i$f$useLines":I
    .restart local p0  # "$this$useLines":Ljava/io/File;
    .restart local p1  # "charset":Ljava/nio/charset/Charset;
    .restart local p2  # "block":Lkotlin/jvm/functions/Function1;
    :catchall_57
    move-exception v5

    invoke-static {v4}, Lkotlin/jvm/internal/InlineMarker;->finallyStart(I)V

    invoke-static {v4, v4, v3}, Lkotlin/internal/PlatformImplementationsKt;->apiVersionIsAtLeast(III)Z

    move-result v3

    if-nez v3, :cond_67

    :try_start_61
    invoke-interface {v2}, Ljava/io/Closeable;->close()V
    :try_end_64
    .catchall {:try_start_61 .. :try_end_64} :catchall_65

    goto :goto_6a

    :catchall_65
    move-exception v1

    goto :goto_6a

    :cond_67
    invoke-static {v2, v1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    :goto_6a
    invoke-static {v4}, Lkotlin/jvm/internal/InlineMarker;->finallyEnd(I)V

    throw v5
.end method

.method public static synthetic useLines$default(Ljava/io/File;Ljava/nio/charset/Charset;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/Object;
    .registers 11
    .param p0, "$this$useLines"  # Ljava/io/File;
    .param p1, "charset"  # Ljava/nio/charset/Charset;
    .param p2, "block"  # Lkotlin/jvm/functions/Function1;

    const/4 p4, 0x1

    and-int/2addr p3, p4

    if-eqz p3, :cond_6

    .line 231
    sget-object p1, Lkotlin/text/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    :cond_6
    const/4 p3, 0x0

    .local p3, "$i$f$useLines":I
    const-string v0, "$this$useLines"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "charset"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "block"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 232
    new-instance v0, Ljava/io/FileInputStream;

    invoke-direct {v0, p0}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    check-cast v0, Ljava/io/InputStream;

    new-instance v1, Ljava/io/InputStreamReader;

    invoke-direct {v1, v0, p1}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;Ljava/nio/charset/Charset;)V

    check-cast v1, Ljava/io/Reader;

    instance-of v0, v1, Ljava/io/BufferedReader;

    if-eqz v0, :cond_2b

    check-cast v1, Ljava/io/BufferedReader;

    goto :goto_33

    :cond_2b
    new-instance v0, Ljava/io/BufferedReader;

    const/16 v2, 0x2000

    invoke-direct {v0, v1, v2}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;I)V

    move-object v1, v0

    :goto_33
    check-cast v1, Ljava/io/Closeable;

    const/4 v0, 0x0

    move-object v2, v0

    check-cast v2, Ljava/lang/Throwable;

    const/4 v2, 0x0

    :try_start_3a
    move-object v3, v1

    check-cast v3, Ljava/io/BufferedReader;

    .line 234
    .local v3, "it":Ljava/io/BufferedReader;
    const/4 v4, 0x0

    .line 232
    .local v4, "$i$a$-use-FilesKt__FileReadWriteKt$useLines$1":I
    invoke-static {v3}, Lkotlin/io/TextStreamsKt;->lineSequence(Ljava/io/BufferedReader;)Lkotlin/sequences/Sequence;

    move-result-object v5

    invoke-interface {p2, v5}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5
    :try_end_46
    .catchall {:try_start_3a .. :try_end_46} :catchall_5a

    .end local v3  # "it":Ljava/io/BufferedReader;
    .end local v4  # "$i$a$-use-FilesKt__FileReadWriteKt$useLines$1":I
    invoke-static {p4}, Lkotlin/jvm/internal/InlineMarker;->finallyStart(I)V

    invoke-static {p4, p4, v2}, Lkotlin/internal/PlatformImplementationsKt;->apiVersionIsAtLeast(III)Z

    move-result v2

    if-eqz v2, :cond_53

    invoke-static {v1, v0}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    goto :goto_56

    :cond_53
    invoke-interface {v1}, Ljava/io/Closeable;->close()V

    :goto_56
    invoke-static {p4}, Lkotlin/jvm/internal/InlineMarker;->finallyEnd(I)V

    return-object v5

    :catchall_5a
    move-exception v0

    .end local p0  # "$this$useLines":Ljava/io/File;
    .end local p1  # "charset":Ljava/nio/charset/Charset;
    .end local p2  # "block":Lkotlin/jvm/functions/Function1;
    .end local p3  # "$i$f$useLines":I
    :try_start_5b
    throw v0
    :try_end_5c
    .catchall {:try_start_5b .. :try_end_5c} :catchall_5c

    .restart local p0  # "$this$useLines":Ljava/io/File;
    .restart local p1  # "charset":Ljava/nio/charset/Charset;
    .restart local p2  # "block":Lkotlin/jvm/functions/Function1;
    .restart local p3  # "$i$f$useLines":I
    :catchall_5c
    move-exception v3

    invoke-static {p4}, Lkotlin/jvm/internal/InlineMarker;->finallyStart(I)V

    invoke-static {p4, p4, v2}, Lkotlin/internal/PlatformImplementationsKt;->apiVersionIsAtLeast(III)Z

    move-result v2

    if-nez v2, :cond_6c

    :try_start_66
    invoke-interface {v1}, Ljava/io/Closeable;->close()V
    :try_end_69
    .catchall {:try_start_66 .. :try_end_69} :catchall_6a

    goto :goto_6f

    :catchall_6a
    move-exception v0

    goto :goto_6f

    :cond_6c
    invoke-static {v1, v0}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    :goto_6f
    invoke-static {p4}, Lkotlin/jvm/internal/InlineMarker;->finallyEnd(I)V

    throw v3
.end method

.method public static final writeBytes(Ljava/io/File;[B)V
    .registers 6
    .param p0, "$this$writeBytes"  # Ljava/io/File;
    .param p1, "array"  # [B

    const-string v0, "$this$writeBytes"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "array"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 108
    new-instance v0, Ljava/io/FileOutputStream;

    invoke-direct {v0, p0}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    check-cast v0, Ljava/io/Closeable;

    const/4 v1, 0x0

    move-object v2, v1

    check-cast v2, Ljava/lang/Throwable;

    :try_start_15
    move-object v2, v0

    check-cast v2, Ljava/io/FileOutputStream;

    .line 234
    .local v2, "it":Ljava/io/FileOutputStream;
    const/4 v3, 0x0

    .line 108
    .local v3, "$i$a$-use-FilesKt__FileReadWriteKt$writeBytes$1":I
    invoke-virtual {v2, p1}, Ljava/io/FileOutputStream;->write([B)V

    .end local v2  # "it":Ljava/io/FileOutputStream;
    .end local v3  # "$i$a$-use-FilesKt__FileReadWriteKt$writeBytes$1":I
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_1e
    .catchall {:try_start_15 .. :try_end_1e} :catchall_22

    invoke-static {v0, v1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    return-void

    :catchall_22
    move-exception v1

    .end local p0  # "$this$writeBytes":Ljava/io/File;
    .end local p1  # "array":[B
    :try_start_23
    throw v1
    :try_end_24
    .catchall {:try_start_23 .. :try_end_24} :catchall_24

    .restart local p0  # "$this$writeBytes":Ljava/io/File;
    .restart local p1  # "array":[B
    :catchall_24
    move-exception v2

    invoke-static {v0, v1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v2
.end method

.method public static final writeText(Ljava/io/File;Ljava/lang/String;Ljava/nio/charset/Charset;)V
    .registers 5
    .param p0, "$this$writeText"  # Ljava/io/File;
    .param p1, "text"  # Ljava/lang/String;
    .param p2, "charset"  # Ljava/nio/charset/Charset;

    const-string v0, "$this$writeText"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "text"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "charset"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 134
    invoke-virtual {p1, p2}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v0

    const-string v1, "(this as java.lang.String).getBytes(charset)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p0, v0}, Lkotlin/io/FilesKt;->writeBytes(Ljava/io/File;[B)V

    return-void
.end method

.method public static synthetic writeText$default(Ljava/io/File;Ljava/lang/String;Ljava/nio/charset/Charset;ILjava/lang/Object;)V
    .registers 5

    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_6

    .line 134
    sget-object p2, Lkotlin/text/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    :cond_6
    invoke-static {p0, p1, p2}, Lkotlin/io/FilesKt;->writeText(Ljava/io/File;Ljava/lang/String;Ljava/nio/charset/Charset;)V

    return-void
.end method

.method private static final writer(Ljava/io/File;Ljava/nio/charset/Charset;)Ljava/io/OutputStreamWriter;
    .registers 5
    .param p0, "$this$writer"  # Ljava/io/File;
    .param p1, "charset"  # Ljava/nio/charset/Charset;

    const/4 v0, 0x0

    .line 38
    .local v0, "$i$f$writer":I
    new-instance v1, Ljava/io/FileOutputStream;

    invoke-direct {v1, p0}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    check-cast v1, Ljava/io/OutputStream;

    new-instance v2, Ljava/io/OutputStreamWriter;

    invoke-direct {v2, v1, p1}, Ljava/io/OutputStreamWriter;-><init>(Ljava/io/OutputStream;Ljava/nio/charset/Charset;)V

    return-object v2
.end method

.method static synthetic writer$default(Ljava/io/File;Ljava/nio/charset/Charset;ILjava/lang/Object;)Ljava/io/OutputStreamWriter;
    .registers 5
    .param p0, "$this$writer"  # Ljava/io/File;
    .param p1, "charset"  # Ljava/nio/charset/Charset;

    and-int/lit8 p2, p2, 0x1

    if-eqz p2, :cond_6

    .line 37
    sget-object p1, Lkotlin/text/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    :cond_6
    const/4 p2, 0x0

    .line 38
    .local p2, "$i$f$writer":I
    new-instance p3, Ljava/io/FileOutputStream;

    invoke-direct {p3, p0}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    check-cast p3, Ljava/io/OutputStream;

    new-instance v0, Ljava/io/OutputStreamWriter;

    invoke-direct {v0, p3, p1}, Ljava/io/OutputStreamWriter;-><init>(Ljava/io/OutputStream;Ljava/nio/charset/Charset;)V

    return-object v0
.end method
