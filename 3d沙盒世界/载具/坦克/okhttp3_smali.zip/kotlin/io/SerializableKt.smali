.class public final Lkotlin/io/SerializableKt;
.super Ljava/lang/Object;
.source "Serializable.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    bv = {
        0x1,
        0x0,
        0x3
    }
    d1 = {
        "\u0000\b\n\u0000\n\u0002\u0018\u0002\n\u0000*\f\b\u0000\u0010\u0000\"\u00020\u00012\u00020\u0001¨\u0006\u0002"
    }
    d2 = {
        "Serializable",
        "Ljava/io/Serializable;",
        "kotlin-stdlib"
    }
    k = 0x2
    mv = {
        0x1,
        0x4,
        0x0
    }
.end annotation


# direct methods
.method public static synthetic Serializable$annotations()V
    .registers 0

    return-void
.end method
